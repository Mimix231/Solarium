import { memo, useId } from 'react';
import type { AnimeAppearance, Expression, SparkAvatar } from '../domain/types';
import { defaultAnime } from '../domain/defaults';

interface Props { avatar: SparkAvatar; size?: number; active?: boolean; className?: string }
/** Original, fully editable vector-anime bust. Rendered locally: no remote images or LLM required. */
export const AnimeAvatar = memo(function AnimeAvatar({ avatar, size = 100, active, className = '' }: Props) {
  const a: AnimeAppearance = { ...defaultAnime, ...avatar.anime };
  const localId = useId().replaceAll(':', '');
  const expr: Expression = avatar.expression;
  const isHappy = expr === 'happy';
  const isFocused = expr === 'focused';
  const rx = a.face === 'round' ? 41 : a.face === 'sharp' ? 37 : 39;
  const faceBottom = a.face === 'sharp' ? 153 : a.face === 'round' ? 149 : 152;
  const hairPath = a.hairstyle === 'pixie'
    ? 'M57 102Q45 69 66 40Q83 17 117 28Q151 32 149 87L137 100 130 71 72 71Z'
    : a.hairstyle === 'bob'
      ? 'M49 100Q36 59 68 32Q91 17 120 28Q154 39 150 100L151 145Q138 159 123 146L130 86 70 86 75 145Q57 157 47 139Z'
      : a.hairstyle === 'hime'
        ? 'M51 105Q36 54 67 28Q109 6 141 42Q158 64 150 115L156 195 133 195 131 79 69 79 66 195 42 195Z'
        : a.hairstyle === 'messy'
          ? 'M41 103L28 82 46 79 40 55 64 59 60 29 83 39 94 18 111 35 134 24 130 52 159 46 151 68 171 83 150 96 142 132 128 123 126 75 70 77 70 132 56 124Z'
          : 'M48 102Q30 47 69 28Q106 9 139 36Q164 64 147 112L157 204 134 204 132 86 69 86 62 204 40 204Z';
  const eyePaths = a.eyeShape === 'sharp'
    ? ['M65 108Q78 97 92 107Q80 116 65 108Z', 'M109 107Q124 97 138 105Q126 116 109 107Z']
    : a.eyeShape === 'sleepy'
      ? ['M65 108Q78 104 92 108Q80 114 65 108Z', 'M109 108Q123 104 138 106Q126 114 109 108Z']
      : ['M64 108Q76 90 92 107Q81 125 64 108Z', 'M109 107Q125 90 140 107Q128 125 109 107Z'];
  const irisR = (a.eyeScale / 100) * (a.eyeShape === 'sleepy' ? 4 : 7.5);
  const clipId = `${localId}-clip`;
  const gradientId = `${localId}-gradient`;
  const hairId = `${localId}-hair`;
  return <svg className={`spark-avatar anime-avatar ${active && avatar.animate ? 'avatar-active' : ''} ${className}`} width={size} height={size} viewBox="0 0 200 200" role="img" aria-label="Editable anime Spark portrait">
    <defs>
      <clipPath id={clipId}><rect width="200" height="200" rx="25" /></clipPath>
      <linearGradient id={gradientId} x1="0" y1="0" x2="1" y2="1"><stop stopColor={a.background}/><stop offset="1" stopColor={avatar.secondary}/></linearGradient>
      <linearGradient id={hairId} x1="0" x2=".85" y1="0" y2="1"><stop stopColor={a.hairAccent}/><stop offset=".45" stopColor={a.hairColor}/><stop offset="1" stopColor={a.hairColor}/></linearGradient>
    </defs>
    <g clipPath={`url(#${clipId})`}>
      <rect width="200" height="200" fill={`url(#${gradientId})`}/>
      <circle cx="168" cy="30" r="64" fill={avatar.color} opacity=".19"/>
      <circle cx="18" cy="188" r="63" fill={a.outfitAccent} opacity=".10"/>
      <g transform={`translate(${a.offsetX} ${a.offsetY}) translate(100 100) scale(${a.zoom / 100}) translate(-100 -100)`}>
        {/* Rear hair and independent ponytail/twin-tail layers */}
        <path d={hairPath} fill={`url(#${hairId})`} stroke={a.hairColor} strokeWidth="2" strokeLinejoin="round" />
        {a.hairstyle === 'twin-tails' && <g fill={`url(#${hairId})`} stroke={a.hairColor} strokeWidth="2">
          <path d="M53 67Q18 55 27 112Q34 140 20 196L47 196Q70 123 62 76Z" />
          <path d="M148 67Q182 55 174 112Q168 145 185 196L156 196Q131 125 140 76Z" />
        </g>}
        {a.hairstyle === 'ponytail' && <path d="M140 53Q183 43 168 95Q160 133 172 183Q140 148 147 93Z" fill={a.hairColor} stroke={a.hairAccent} strokeWidth="2"/>}
        {/* Outfit layers and collar */}
        <path d="M19 214Q21 171 51 163L78 151 121 151 149 163Q179 172 184 214Z" fill={a.outfitColor} stroke={a.outfitAccent} strokeWidth="2" />
        {a.outfit === 'hoodie' && <><path d="M60 164Q94 188 140 164L157 208 42 208Z" fill={a.outfitColor}/><path d="M72 161L65 189 82 196 M127 160L134 189 118 196" stroke={a.outfitAccent} strokeWidth="3" fill="none" strokeLinecap="round"/><path d="M66 193Q100 187 135 193" stroke={a.outfitAccent} fill="none" opacity=".65" /></>}
        {a.outfit === 'uniform' && <><path d="M68 159L99 194 131 159 138 178 99 209 59 178Z" fill={a.outfitAccent}/><path d="M75 161L100 188 125 161 116 174 100 193 84 173Z" fill="#ffffff" opacity=".82"/><path d="M99 190L91 214 107 214Z" fill={avatar.color}/></>}
        {a.outfit === 'dress' && <><path d="M62 162Q99 186 137 162L145 213H55Z" fill={a.outfitAccent} opacity=".45"/><path d="M85 163Q100 180 114 163" fill="none" stroke="#fff" strokeWidth="3"/><circle cx="100" cy="190" r="5" fill={avatar.color}/></>}
        {a.outfit === 'jacket' && <><path d="M65 164L98 186 84 207 59 178Z M136 164L102 186 119 207 145 178Z" fill={a.outfitAccent}/><path d="M101 183L101 212" stroke="white" strokeWidth="2"/></>}
        {/* Neck and face */}
        <path d="M86 136L84 163Q100 179 116 163L114 136Z" fill={a.skin} stroke="#9e6868" strokeWidth="1.4" />
        <path d={`M${100-rx} 82 Q${100-rx-3} 119 81 140 Q99 ${faceBottom+4} 119 140 Q${100+rx+3} 117 ${100+rx} 82 Q137 48 100 50 Q63 48 ${100-rx} 82Z`} fill={a.skin} stroke="#bc8992" strokeWidth="1.6" />
        <path d="M70 96Q77 86 88 94 M111 94Q124 86 133 97" fill="none" stroke={a.hairColor} strokeWidth={isFocused ? 3.8 : 2.5} strokeLinecap="round"/>
        {/* Eyes and irises */}
        <g fill={isHappy ? "none" : '#fff'} stroke={a.hairColor} strokeWidth="2.1" strokeLinejoin="round">
          {isHappy ? <><path d="M65 106Q78 94 92 106"/><path d="M109 106Q123 94 138 106"/></> : eyePaths.map((d,i) => <path d={d} key={i} />)}
        </g>
        {!isHappy && <g>
          {[78,124].map((x) => <g key={x} transform={`translate(${x} 108)`}>
            <ellipse rx={irisR * .87} ry={irisR * 1.3} fill={a.eyeColor} stroke={a.hairColor} strokeWidth="1" />
            <ellipse cy="1.5" rx={irisR * .45} ry={irisR * .75} fill="#20233d"/>
            <circle cx="-2" cy="-3" r={Math.max(1.5,irisR*.35)} fill="white" opacity=".95"/>
            <circle cx="3" cy="3" r="1.3" fill="white" opacity=".8"/>
          </g>)}
        </g>}
        {/* cheeks, nose and expression */}
        <g opacity={a.blush / 125} fill="#ef749a"><ellipse cx="67" cy="124" rx="13" ry="5"/><ellipse cx="132" cy="124" rx="13" ry="5"/></g>
        <path d="M100 117L98 122 101 124" fill="none" stroke="#bc8992" strokeWidth="1.4"/>
        <path d={isHappy ? 'M88 134Q100 149 113 134Q100 141 88 134Z' : expr === 'curious' ? 'M95 137Q100 141 106 137' : isFocused ? 'M94 138L105 138' : 'M92 136Q100 140 108 136'} fill={isHappy ? '#b95776' : 'none'} stroke="#a75f78" strokeWidth="2" strokeLinecap="round"/>
        {/* Foreground anime bangs; distinct selectable cut paths */}
        <g fill={`url(#${hairId})`} stroke={a.hairColor} strokeWidth="1.8" strokeLinejoin="round">
          {a.bangs === 'curtain' && <><path d="M57 94Q45 45 91 41Q86 68 68 92L72 73Z"/><path d="M88 41Q146 37 144 90L127 75Q121 91 109 94Q110 64 88 41Z"/></>}
          {a.bangs === 'straight' && <path d="M57 93Q53 50 97 37Q144 47 143 94L133 86 122 96 113 85 101 97 90 86 79 97 69 85Z" />}
          {a.bangs === 'swept' && <path d="M53 100Q48 52 98 35Q143 35 145 80Q108 88 81 91Q105 77 117 59Q88 77 53 100Z" />}
          {a.hairstyle === 'hime' && <><path d="M56 93L68 88 68 148 51 154Z"/><path d="M133 88L146 94 148 155 133 148Z"/></>}
        </g>
        <path d="M71 57Q101 35 129 53" fill="none" stroke={a.hairAccent} strokeWidth="2.2" opacity=".55" strokeLinecap="round" />
        {/* Interchangeable anime accessories */}
        {a.accessory === 'ribbon' && <g transform="translate(135 56)"><path d="M0 0L-17 -10Q-23 5 -17 11Z M0 0L17 -10Q22 5 17 11Z" fill={a.outfitAccent} stroke={a.outfitColor} strokeWidth="1.3"/><circle r="4" fill={avatar.color}/></g>}
        {a.accessory === 'glasses' && <g stroke={a.outfitAccent} fill="none" strokeWidth="2"><rect x="61" y="99" width="35" height="22" rx="8"/><rect x="106" y="99" width="35" height="22" rx="8"/><path d="M96 104Q101 100 106 104"/></g>}
        {a.accessory === 'earrings' && <g fill={a.outfitAccent}><circle cx="58" cy="125" r="3"/><circle cx="142" cy="125" r="3"/><path d="M58 128l-4 11 4 4 4-4Z M142 128l-4 11 4 4 4-4Z"/></g>}
        {a.accessory === 'cat-ears' && <g fill={a.hairColor} stroke={a.hairAccent} strokeWidth="2"><path d="M64 48L55 11 90 37Z"/><path d="M111 37L148 11 139 52Z"/></g>}
        {a.accessory === 'halo' && <ellipse cx="101" cy="18" rx="33" ry="8" fill="none" stroke={a.outfitAccent} strokeWidth="5" />}
      </g>
    </g>
  </svg>;
});
