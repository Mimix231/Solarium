import { useShallow } from 'zustand/react/shallow';
import { useEffect, useRef, useState, type KeyboardEvent } from 'react';
import { Alert, Box, Button, Chip, CircularProgress, Dialog, DialogActions, DialogContent, DialogTitle, FormControl, IconButton, MenuItem, ListSubheader, Select, Stack, TextField, Tooltip, Typography } from '@mui/material';
import SendRounded from '@mui/icons-material/SendRounded';
import StopRounded from '@mui/icons-material/StopRounded';
import AddRounded from '@mui/icons-material/AddRounded';
import AutoAwesomeRounded from '@mui/icons-material/AutoAwesomeRounded';
import InsightsRounded from '@mui/icons-material/InsightsRounded';
import CloseRounded from '@mui/icons-material/CloseRounded';
import SmartToyOutlined from '@mui/icons-material/SmartToyOutlined';
import { AvatarView } from '../components/AvatarView';
import { useSolarium } from '../state/useSolarium';
import { now, uid, type GenerationMetrics, type SparkMode } from '../domain/types';
import { runAgent } from '../engine/agent';
import { AgentEventEmitter } from '../engine/activity';
import { activateGGUFModel, scanGGUFDirectory } from '../engine/desktop';
import { catalogToModels } from '../engine/catalog';

const modes: SparkMode[] = ['conversation', 'work', 'research', 'creative'];
type Decision = 'allow' | 'deny';
function ActivityPanel() {
  const events = useSolarium((s) => s.events);
  const close = useSolarium((s) => s.updatePreferences);
  return <aside className="activity-panel"><Stack direction="row" justifyContent="space-between" alignItems="center" px={1.8} py={1.5}><Box><Typography fontWeight={750} fontSize={12}>Live activity</Typography><Typography color="text.secondary" fontSize={10}>Actual model and tool events</Typography></Box><IconButton aria-label="Close activity" onClick={() => close({ showActivity: false })}><CloseRounded fontSize="small" /></IconButton></Stack>
    <Box className="activity-feed">{events.map((event) => <Box key={event.id} className={`activity-event ${event.kind}`}>
      <Stack direction="row" justifyContent="space-between" alignItems="center"><Typography fontWeight={700} fontSize={10.5} textTransform="capitalize">{event.kind === 'phase' ? event.phase : event.kind.replaceAll('_', ' ')}</Typography><Typography fontSize={9} color="text.secondary">{event.sequence}</Typography></Stack>
      <Typography fontSize={11} color="text.secondary" sx={{ whiteSpace: 'pre-wrap', overflowWrap: 'anywhere' }}>{event.text || event.status || event.tool}</Typography>
      {event.tool && <Chip size="small" label={event.tool} sx={{ mt: .5 }} />}
    </Box>)}{!events.length && <Typography fontSize={11} color="text.secondary">Activity will appear when a model runs. No simulated thinking cards.</Typography>}</Box>
  </aside>;
}
export function Chat() {
  const { workspace, createSession, appendMessage, updateSession, setSessionMode, updateSpark, updatePreferences, pushEvent, clearEvents, setView } = useSolarium(useShallow((state) => ({ workspace: state.workspace, createSession: state.createSession, appendMessage: state.appendMessage, updateSession: state.updateSession, setSessionMode: state.setSessionMode, updateSpark: state.updateSpark, updatePreferences: state.updatePreferences, pushEvent: state.pushEvent, clearEvents: state.clearEvents, setView: state.setView })));
  const spark = workspace.sparks.find((s) => s.id === workspace.selectedSparkId) ?? workspace.sparks[0]!;
  const session = workspace.sessions.find((s) => s.id === workspace.activeSessionId);
  const modelId = session?.modelId ?? spark.preferredModelId ?? workspace.models[0]?.id ?? '';
  const model = workspace.models.find((m) => m.id === modelId);
  const [input, setInput] = useState('');
  const [metrics, setMetrics] = useState<GenerationMetrics | null>(null);
  const [draft, setDraft] = useState('');
  const [busy, setBusy] = useState(false);
  const [modelBusy, setModelBusy] = useState(false);
  const [loadedModel, setLoadedModel] = useState('');
  const [error, setError] = useState('');
  const [approval, setApproval] = useState<{ name: string; args: Record<string, unknown> } | null>(null);
  const approvalRef = useRef<((value: Decision) => void) | null>(null);
  const controller = useRef<AbortController | null>(null);
  const bottom = useRef<HTMLDivElement>(null);
  useEffect(() => { bottom.current?.scrollIntoView({ behavior: 'smooth', block: 'end' }); }, [draft, session?.messages.length]);
  useEffect(() => () => { controller.current?.abort(); approvalRef.current?.('deny'); approvalRef.current = null; }, []);
  useEffect(() => {
    const folder = workspace.preferences.ggufDirectory;
    if (!folder || !('__TAURI_INTERNALS__' in window)) return;
    let cancelled = false;
    void scanGGUFDirectory(folder).then((files) => {
      if (!cancelled) useSolarium.getState().syncCatalog(catalogToModels(files, useSolarium.getState().workspace.preferences.serverPort), folder);
    }).catch((error: unknown) => { if (!cancelled) setError(`Could not scan your GGUF folder: ${String(error)}`); });
    return () => { cancelled = true; };
  }, [workspace.preferences.ggufDirectory, workspace.preferences.serverPort]);
  async function ensureGGUF(modelToLoad: NonNullable<typeof model>): Promise<NonNullable<typeof model>> {
    if (!modelToLoad.ggufPath) return modelToLoad;
    const preferences = useSolarium.getState().workspace.preferences;
    if (!preferences.llamaExecutable) throw Error('Install llama.cpp first in Models → Inference Engines.');
    const result = await activateGGUFModel({ executable: preferences.llamaExecutable, gguf: modelToLoad.ggufPath,
      port: preferences.serverPort, context: modelToLoad.contextSize, gpuLayers: 20 });
    const ready = { ...modelToLoad, endpoint: `http://127.0.0.1:${preferences.serverPort}`, modelId: result.modelId };
    useSolarium.getState().upsertModel(ready);
    setLoadedModel(result.detail);
    return ready;
  }
  async function changeModel(id: string) {
    if (busy || modelBusy) return;
    const selected = useSolarium.getState().workspace.models.find((m) => m.id === id);
    if (!selected) return;
    const target = useSolarium.getState().workspace.activeSessionId ?? useSolarium.getState().createSession();
    useSolarium.getState().updateSession(target, { modelId: selected.id });
    setLoadedModel(''); setError('');
    if (selected.ggufPath) {
      setModelBusy(true);
      try { await ensureGGUF(selected); }
      catch (error) { setError(`Model loading failed: ${String(error)}`); }
      finally { setModelBusy(false); }
    }
  }
  function answerApproval(value: Decision) {
    approvalRef.current?.(value); approvalRef.current = null; setApproval(null);
  }
  function requestApproval(name: string, args: Record<string, unknown>, signal: AbortSignal): Promise<Decision> {
    if (signal.aborted) return Promise.resolve('deny');
    return new Promise((resolve) => {
      const done = (value: Decision) => { signal.removeEventListener('abort', abort); resolve(value); };
      const abort = () => { approvalRef.current = null; setApproval(null); done('deny'); };
      signal.addEventListener('abort', abort, { once: true });
      approvalRef.current = done; setApproval({ name, args });
    });
  }
  async function send() {
    const text = input.trim();
    if (!text || busy || modelBusy) return;
    if (!model) { setError('Select a GGUF model or connect a model in the Models workspace before chatting.'); return; }
    setBusy(true);
    try { await ensureGGUF(model); } catch (error) { setError(`Cannot load model: ${String(error)}`); setBusy(false); return; }
    const current = useSolarium.getState();
    const targetId = current.workspace.activeSessionId ?? current.createSession();
    current.appendMessage(targetId, { id: uid(), role: 'user', content: text, createdAt: now() });
    const updated = useSolarium.getState().workspace;
    const chat = updated.sessions.find((s) => s.id === targetId);
    if (!chat) return;
    const activeSpark = updated.sparks.find((s) => s.id === chat.sparkId) ?? spark;
    const activeModel = updated.models.find((m) => m.id === (chat.modelId ?? activeSpark.preferredModelId ?? updated.models[0]?.id)) ?? model;
    const abort = new AbortController();
    controller.current = abort; setMetrics(null); setInput(''); setDraft(''); setError(''); clearEvents();
    const events = new AgentEventEmitter(pushEvent);
    let completed = '';
    try {
      completed = await runAgent({
        spark: activeSpark, model: activeModel, session: chat,
        memories: updated.memories, preferences: updated.preferences, events, signal: abort.signal,
        onMetrics: setMetrics,
        onAnswer: (delta) => setDraft((prev) => { completed = prev + delta; return completed; }),
        onApproval: (name, args) => requestApproval(name, args, abort.signal),
      });
    } catch (e) {
      if (!abort.signal.aborted) { events.emit('error', String(e)); setError(String(e)); }
    } finally {
      if (completed.trim()) appendMessage(targetId, { id: uid(), role: 'assistant', content: completed, sparkId: activeSpark.id, createdAt: now() });
      controller.current = null; setBusy(false); setDraft(''); setApproval(null);
    }
  }
  function keydown(e: KeyboardEvent<HTMLDivElement>) { if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) { e.preventDefault(); void send(); } }
  return <div className="chat-layout">
    <section className="chat-primary">
      <div className="chat-header">
        <Stack direction="row" alignItems="center" gap={1} minWidth={0}><AvatarView avatar={spark.avatar} size={31} active={busy} /><Stack minWidth={0}><Typography fontSize={12.5} fontWeight={750} noWrap>{spark.name}</Typography><Typography color="text.secondary" fontSize={10} noWrap>{model ? `${model.name} · ${model.backend ?? 'llama.cpp'}` : 'No model connected'}</Typography></Stack><span className={`status-dot ${model ? 'ready-dot' : ''}`} /></Stack>
        <Stack direction="row" alignItems="center" gap={.8}>
          <FormControl size="small" className="mode-select"><Select aria-label="Conversation mode" disabled={busy} value={session?.mode ?? 'conversation'} onChange={(e) => { if (session) setSessionMode(session.id, e.target.value as SparkMode); else setSessionMode(createSession(), e.target.value as SparkMode); }} sx={{ fontSize: 11 }}>{modes.map((mode) => <MenuItem key={mode} value={mode}>{mode[0]?.toUpperCase()}{mode.slice(1)}</MenuItem>)}</Select></FormControl>
          {metrics && <Tooltip title={`First token ${metrics.firstTokenMs?.toFixed(0) ?? '—'} ms · ${metrics.completionTokens === null ? 'estimated' : 'reported'} output tokens`}><Chip size="small" variant="outlined" label={`${metrics.tokensPerSecond ?? '—'} tok/s${metrics.completionTokens === null ? ' ≈' : ''}`} /></Tooltip>}
          <Tooltip title="Activity"><IconButton aria-label="Toggle activity" onClick={() => updatePreferences({ showActivity: !workspace.preferences.showActivity })}><InsightsRounded fontSize="small" /></IconButton></Tooltip>
          <Tooltip title="New conversation"><IconButton aria-label="New conversation" disabled={busy} onClick={() => createSession()}><AddRounded fontSize="small" /></IconButton></Tooltip>
        </Stack>
      </div>
      <div className="message-list" role="log" aria-live="polite">
        {!session?.messages.length && <div className="welcome">
          <div className="welcome-orbit"><AvatarView avatar={spark.avatar} size={94} /></div>
          <span className="eyebrow">YOUR AI COMPANION</span>
          <Typography variant="h5" mt={1}>A universe of possibilities.</Typography>
          <Typography color="text.secondary" mt={1} fontSize={13} maxWidth={440} textAlign="center">{spark.greeting}</Typography>
          <Stack direction="row" gap={1} justifyContent="center" flexWrap="wrap" mt={3}>
            {['Explore an idea', 'Help me write code', 'Brainstorm something new'].map((prompt) => <button key={prompt} className="prompt-chip" onClick={() => setInput(prompt)}>{prompt} ↗</button>)}
          </Stack>
          <Stack direction="row" gap={1} mt={3} flexWrap="wrap" justifyContent="center">
            <Button onClick={() => setView('sparks')} startIcon={<AutoAwesomeRounded />}>Customize Spark</Button>
            {!model && <Button onClick={() => setView('models')} startIcon={<SmartToyOutlined />} variant="contained">Connect a model</Button>}
          </Stack>
        </div>}
        {session?.messages.map((message) => <div className={`message-row ${message.role}`} key={message.id}>
          {message.role === 'assistant' && <AvatarView avatar={workspace.sparks.find((s) => s.id === message.sparkId)?.avatar ?? spark.avatar} size={26} />}
          <div className="message-content"><Typography fontWeight={700} fontSize={11} color="text.secondary" mb={.45}>{message.role === 'user' ? 'You' : (workspace.sparks.find((s) => s.id === message.sparkId)?.name ?? spark.name)}</Typography><div className="message-text">{message.content}</div></div>
        </div>)}
        {busy && <div className="message-row assistant"><AvatarView avatar={spark.avatar} size={26} active /><div className="message-content"><Typography fontSize={11} fontWeight={700} mb={.6}>{spark.name} <CircularProgress size={10} sx={{ ml: .8 }} /></Typography><div className="message-text">{draft || 'Generating locally…'}</div></div></div>}
        <div ref={bottom} />
      </div>
      <div className="composer-wrap">
        {error && <Alert severity="warning" onClose={() => setError('')} sx={{ mb: 1 }}>{error}</Alert>}
        <div className="composer-model-row">
          <FormControl size="small" sx={{ minWidth: 225, maxWidth: '85%' }}>
            <Select variant="standard" disableUnderline size="small" aria-label="Choose GGUF or connected model" disabled={busy || modelBusy}
              displayEmpty value={modelId} onChange={(e) => void changeModel(e.target.value)} sx={{ fontSize: 11 }}>
              {!workspace.models.length && <MenuItem value="" disabled>Set a GGUF folder in Settings</MenuItem>}
              {workspace.models.some((m) => m.ggufPath) && <ListSubheader>GGUF models in your folder</ListSubheader>}
              {workspace.models.filter((m) => m.ggufPath).map((m) => <MenuItem key={m.id} value={m.id}>{m.name}</MenuItem>)}
              {workspace.models.some((m) => !m.ggufPath) && <ListSubheader>Other local servers</ListSubheader>}
              {workspace.models.filter((m) => !m.ggufPath).map((m) => <MenuItem key={m.id} value={m.id}>{m.name} · {m.backend ?? 'llama.cpp'}</MenuItem>)}
            </Select>
          </FormControl>
          {modelBusy ? <Stack direction="row" gap={.7} alignItems="center"><CircularProgress size={11}/><Typography fontSize={10}>Loading GGUF…</Typography></Stack> : <Typography color="text.secondary" fontSize={10} noWrap>{loadedModel || (model?.ggufPath ? 'Select to load · local GGUF' : (model ? model.backend : 'No GGUF folder configured'))}</Typography>}
          <Button size="small" onClick={() => setView('settings')} sx={{ ml: 'auto' }}>Library settings</Button>
        </div>
        <div className="composer glass"><TextField placeholder={`Message ${spark.name}…`} variant="standard" fullWidth multiline maxRows={8} value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={keydown} disabled={busy || modelBusy} slotProps={{ input: { disableUnderline: true } }} />
          {busy ? <Tooltip title="Stop generation"><IconButton aria-label="Stop generation" className="send-button" onClick={() => { controller.current?.abort(); answerApproval('deny'); }}><StopRounded /></IconButton></Tooltip> : <Tooltip title="Send (Enter)"><span><IconButton aria-label="Send message" className="send-button" disabled={!input.trim() || modelBusy} onClick={() => void send()}><SendRounded /></IconButton></span></Tooltip>}
        </div>
        <Typography color="text.secondary" textAlign="center" fontSize={10} mt={.7}>Your Sparks run on local models. Verify important information.</Typography>

      </div>
    </section>
    {workspace.preferences.showActivity && <ActivityPanel />}
    <Dialog open={Boolean(approval)} onClose={() => answerApproval('deny')} fullWidth maxWidth="xs"><DialogTitle fontSize={15}>Allow local tool?</DialogTitle><DialogContent><Typography mb={1} fontWeight={700}>{approval?.name}</Typography><Typography color="text.secondary" fontSize={12} sx={{ overflowWrap: 'anywhere', whiteSpace: 'pre-wrap' }}>{JSON.stringify(approval?.args ?? {}, null, 2)}</Typography><Typography color="text.secondary" fontSize={11} mt={2}>This tool will run only if you approve it.</Typography></DialogContent><DialogActions><Button onClick={() => answerApproval('deny')}>Deny</Button><Button variant="contained" onClick={() => answerApproval('allow')}>Allow once</Button></DialogActions></Dialog>
  </div>;
}
