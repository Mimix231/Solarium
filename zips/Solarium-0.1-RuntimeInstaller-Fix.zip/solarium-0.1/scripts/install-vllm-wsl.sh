#!/usr/bin/env bash
# Executes inside WSL2. The first argument is Solarium's Windows ./runtime
# mapped to a /mnt/<drive>/... path using `wslpath`; no global vLLM install.
set -euo pipefail
if [ "$#" -ne 1 ] || [[ "$1" != /* ]]; then
  echo 'Expected the absolute Solarium runtime path from the Windows launcher.' >&2
  exit 2
fi
runtime="${1%/}"
if [ "$(id -u)" -eq 0 ]; then echo 'Install vLLM as a normal WSL user, not root.' >&2; exit 1; fi
if ! command -v nvidia-smi >/dev/null 2>&1; then
  echo 'NVIDIA GPU passthrough in WSL2 is unavailable; update the Windows NVIDIA driver.' >&2; exit 1
fi
if ! command -v python3 >/dev/null 2>&1; then
  echo 'Install Python 3.10+ and python3-venv in your WSL2 distro first.' >&2; exit 1
fi
if ! python3 -c 'import sys; assert sys.version_info >= (3, 10)' 2>/dev/null; then
  echo 'vLLM requires Python 3.10 or newer in WSL2.' >&2; exit 1
fi
# These directories live in the project or executable-adjacent ./runtime folder.
mkdir -p "$runtime/vllm" "$runtime/cache" "$runtime/cache/cuda" "$runtime/cache/triton" "$runtime/tmp" "$runtime/huggingface"
export XDG_CACHE_HOME="$runtime/cache"
export HF_HOME="$runtime/huggingface"
export VLLM_CACHE_ROOT="$runtime/cache/vllm"
export CUDA_CACHE_PATH="$runtime/cache/cuda"
export TRITON_CACHE_DIR="$runtime/cache/triton"
export TMPDIR="$runtime/tmp"
venv="$runtime/vllm/venv"
if [ ! -x "$venv/bin/python" ]; then python3 -m venv --copies "$venv"; fi
"$venv/bin/python" -m pip install --no-cache-dir --upgrade pip
"$venv/bin/python" -m pip install --no-cache-dir vllm
printf 'vLLM installed at: %s\n' "$venv/bin/vllm"
