use serde::Deserialize;
use sha2::{Digest, Sha256};
use std::fs::{self, File};
use std::io::{self, Read, Write};
use std::path::{Path, PathBuf};
use std::process::{Child, Command, Stdio};
use std::sync::Mutex;
use std::time::Duration;
use tauri::State;

mod runtime;
use runtime::{ensure_runtime_dir, runtime_dir, wsl_runtime_path};

#[derive(Default)]
struct EngineProcesses {
    llama: Mutex<Option<Child>>,
    vllm: Mutex<Option<Child>>,
}

impl Drop for EngineProcesses {
    fn drop(&mut self) {
        for slot in [&self.llama, &self.vllm] {
            if let Ok(mut guard) = slot.lock() {
                if let Some(mut process) = guard.take() {
                    let _ = process.kill();
                    let _ = process.wait();
                }
            }
        }
    }
}

fn start_managed(slot: &Mutex<Option<Child>>, command: &mut Command, label: &str, log_path: &Path) -> Result<String, String> {
    let mut guard = slot.lock().map_err(|_| "Engine lock unavailable")?;
    if let Some(child) = guard.as_mut() {
        if child.try_wait().map_err(|e| e.to_string())?.is_none() {
            return Err(format!("A Solarium-managed {label} server is already running."));
        }
    }
    if let Some(folder) = log_path.parent() { fs::create_dir_all(folder).map_err(|e| e.to_string())?; }
    let stdout = File::create(log_path).map_err(|e| e.to_string())?;
    let stderr = stdout.try_clone().map_err(|e| e.to_string())?;
    let process = command.stdin(Stdio::null()).stdout(Stdio::from(stdout)).stderr(Stdio::from(stderr))
        .spawn().map_err(|e| format!("Unable to start {label}: {e}"))?;
    let pid = process.id();
    *guard = Some(process);
    Ok(format!("Started {label} (PID {pid}). Check the endpoint after model loading completes. Log: {}", log_path.display()))
}

fn stop_managed(slot: &Mutex<Option<Child>>, label: &str) -> Result<String, String> {
    let mut guard = slot.lock().map_err(|_| "Engine lock unavailable")?;
    match guard.take() {
        Some(mut process) => {
            let _ = process.kill();
            let _ = process.wait();
            Ok(format!("Stopped Solarium-managed {label} process."))
        }
        None => Err(format!("No Solarium-managed {label} process is running.")),
    }
}

#[tauri::command]
fn start_llama_server(
    state: State<'_, EngineProcesses>, executable: String, gguf: String,
    port: u16, context: u32, gpu_layers: i32,
) -> Result<String, String> {
    let path = Path::new(&executable);
    let model = Path::new(&gguf);
    if !path.is_file() { return Err("llama-server executable does not exist.".into()); }
    if !model.is_file() || !model.extension().and_then(|x| x.to_str()).is_some_and(|x| x.eq_ignore_ascii_case("gguf")) {
        return Err("Select an existing GGUF model file.".into());
    }
    let filename = path.file_stem().and_then(|s| s.to_str()).unwrap_or("").to_lowercase();
    if filename != "llama-server" { return Err("Only an executable named llama-server may be launched.".into()); }
    if port < 1024 || context < 256 || context > 262_144 || !(-1..=999).contains(&gpu_layers) {
        return Err("Invalid port, GPU layers, or context length.".into());
    }
    let mut command = Command::new(path);
    command.args(["-m", &gguf, "--host", "127.0.0.1", "--port", &port.to_string(),
        "-c", &context.to_string(), "--n-gpu-layers", &gpu_layers.to_string(), "--no-webui"]);
    if let Some(folder) = path.parent() { command.current_dir(folder); }
    let log = ensure_runtime_dir()?.join("logs/llama.log");
    start_managed(&state.llama, &mut command, "llama.cpp", &log)
}

#[tauri::command]
fn stop_llama_server(state: State<'_, EngineProcesses>) -> Result<String, String> {
    stop_managed(&state.llama, "llama.cpp")
}

#[tauri::command]
fn start_vllm_server(
    state: State<'_, EngineProcesses>, distro: String, model: String,
    port: u16, context: u32, gpu_memory_utilization: f32,
) -> Result<String, String> {
    if !cfg!(target_os = "windows") { return Err("WSL2 launch is currently supported on Windows hosts only. On Linux, start vLLM manually and register its endpoint.".into()); }
    if distro.is_empty() || !distro.chars().all(|c| c.is_ascii_alphanumeric() || "._-".contains(c)) {
        return Err("Invalid WSL distribution name.".into());
    }
    if model.is_empty() || model.len() > 400 || model.starts_with('-') || model.chars().any(char::is_control) {
        return Err("Enter a valid Hugging Face model ID or Linux model path.".into());
    }
    if !(1024..=65535).contains(&port) || !(512..=65_536).contains(&context) ||
        !gpu_memory_utilization.is_finite() || !(0.2..=0.7).contains(&gpu_memory_utilization) {
        return Err("Invalid port, context size, or GPU memory fraction.".into());
    }
    // Explicit arguments rather than a shell: model names and paths are not executed as code.
    let linux_runtime = wsl_runtime_path(&distro)?;
    let venv_binary = format!("{linux_runtime}/vllm/venv/bin/vllm");
    let installed = Command::new("wsl.exe").args(["-d", &distro, "--", "test", "-x", &venv_binary])
        .status().is_ok_and(|status| status.success());
    if !installed {
        return Err(format!("vLLM is not installed in {linux_runtime}/vllm/venv. Run Install vLLM in WSL2 first."));
    }
    // WSL receives separate arguments. No shell interpolation of model IDs or Windows paths.
    let mut command = Command::new("wsl.exe");
    command.args(["-d", &distro, "--", "env"])
        .arg(format!("HF_HOME={linux_runtime}/huggingface"))
        .arg(format!("XDG_CACHE_HOME={linux_runtime}/cache"))
        .arg(format!("VLLM_CACHE_ROOT={linux_runtime}/cache/vllm"))
        .arg(format!("CUDA_CACHE_PATH={linux_runtime}/cache/cuda"))
        .arg(format!("TRITON_CACHE_DIR={linux_runtime}/cache/triton"))
        .arg(format!("TMPDIR={linux_runtime}/tmp"))
        .arg(&venv_binary)
        .args(["serve", &model, "--host", "127.0.0.1", "--port", &port.to_string(),
            "--max-model-len", &context.to_string(),
            "--gpu-memory-utilization", &gpu_memory_utilization.to_string()]);
    let log = ensure_runtime_dir()?.join("logs/vllm.log");
    start_managed(&state.vllm, &mut command, "vLLM (WSL2)", &log)
}

#[tauri::command]
fn stop_vllm_server(state: State<'_, EngineProcesses>) -> Result<String, String> {
    stop_managed(&state.vllm, "vLLM (WSL2)")
}

fn install_vllm_into_wsl(distro: String) -> Result<String, String> {
    if !cfg!(target_os = "windows") { return Err("WSL installer is available on Windows only.".into()); }
    if distro.is_empty() || !distro.chars().all(|c| c.is_ascii_alphanumeric() || "._-".contains(c)) {
        return Err("Invalid WSL distribution name.".into());
    }
    let linux_runtime = wsl_runtime_path(&distro)?;
    let mut child = Command::new("wsl.exe").args(["-d", &distro, "--", "bash", "-s", "--", &linux_runtime])
        .stdin(Stdio::piped()).stdout(Stdio::piped()).stderr(Stdio::piped())
        .spawn().map_err(|e| format!("Unable to reach WSL2: {e}"))?;
    let script = include_bytes!("../../scripts/install-vllm-wsl.sh");
    child.stdin.take().ok_or("Unable to send installer script")?.write_all(script).map_err(|e| e.to_string())?;
    let output = child.wait_with_output().map_err(|e| e.to_string())?;
    if !output.status.success() {
        // pip frequently writes the useful failure to stdout, not stderr.
        let stdout = String::from_utf8_lossy(&output.stdout);
        let stderr = String::from_utf8_lossy(&output.stderr);
        let stdout_tail: String = stdout.chars().rev().take(1000).collect::<String>().chars().rev().collect();
        let stderr_tail: String = stderr.chars().rev().take(1600).collect::<String>().chars().rev().collect();
        return Err(format!("vLLM installation failed (exit {}): {} {}", output.status, stderr_tail, stdout_tail));
    }
    Ok(format!("vLLM installed under ./runtime/vllm/venv ({linux_runtime}/vllm/venv). You can now launch it through Solarium."))
}

#[tauri::command]
async fn install_vllm_wsl(distro: String) -> Result<String, String> {
    tauri::async_runtime::spawn_blocking(move || install_vllm_into_wsl(distro))
        .await.map_err(|e| e.to_string())?
}

#[tauri::command]
fn nvidia_gpu_status() -> Result<String, String> {
    let output = Command::new("nvidia-smi")
        .args(["--query-gpu=name,memory.total,memory.used,memory.free", "--format=csv,noheader,nounits"])
        .output().map_err(|_| "nvidia-smi is unavailable. Check that NVIDIA drivers are installed.".to_owned())?;
    if !output.status.success() { return Err("nvidia-smi was unable to read GPU memory.".into()); }
    Ok(String::from_utf8_lossy(&output.stdout).trim().to_string())
}

#[tauri::command]
fn read_engine_log(engine: String) -> Result<String, String> {
    let filename = match engine.as_str() {
        "llama.cpp" => "llama.log",
        "vllm" => "vllm.log",
        _ => return Err("Unsupported engine log.".into()),
    };
    let path = runtime_dir()?.join("logs").join(filename);
    let bytes = fs::read(path).map_err(|e| format!("No log found for {engine}: {e}"))?;
    Ok(String::from_utf8_lossy(&bytes[bytes.len().saturating_sub(16_000)..]).to_string())
}

#[derive(Deserialize)]
struct Release { id: u64, assets: Vec<ReleaseAsset> }
#[derive(Clone, Deserialize)]
struct ReleaseAsset { name: String, browser_download_url: String, digest: Option<String>, size: u64 }

fn download_verified(client: &reqwest::blocking::Client, asset: &ReleaseAsset, dest: &Path) -> Result<(), String> {
    let expected = asset.digest.as_deref().and_then(|d| d.strip_prefix("sha256:"))
        .filter(|s| s.len() == 64 && s.bytes().all(|c| c.is_ascii_hexdigit()))
        .ok_or_else(|| format!("Release asset {} has no published SHA-256 digest; installation aborted.", asset.name))?;
    if asset.size == 0 || asset.size > 1_000_000_000 { return Err("Download exceeds the 1 GB per-asset limit.".into()); }
    let url = reqwest::Url::parse(&asset.browser_download_url).map_err(|e| e.to_string())?;
    if url.scheme() != "https" || url.host_str() != Some("github.com") || !url.path().starts_with("/ggml-org/llama.cpp/releases/download/") {
        return Err("Installer requires official ggml-org/llama.cpp release assets.".into());
    }
    let mut response = client.get(url).send().map_err(|e| e.to_string())?.error_for_status().map_err(|e| e.to_string())?;
    let mut file = File::create(dest).map_err(|e| e.to_string())?;
    let copied = io::copy(&mut response.by_ref().take(1_000_000_001), &mut file).map_err(|e| e.to_string())?;
    file.flush().map_err(|e| e.to_string())?;
    if copied != asset.size { return Err("Downloaded file size does not match release metadata.".into()); }
    let mut reader = File::open(dest).map_err(|e| e.to_string())?;
    let mut hasher = Sha256::new();
    io::copy(&mut reader, &mut hasher).map_err(|e| e.to_string())?;
    if format!("{:x}", hasher.finalize()) != expected.to_ascii_lowercase() {
        return Err(format!("SHA-256 verification failed for {}.", asset.name));
    }
    Ok(())
}

fn extract_zip(archive_path: &Path, destination: &Path) -> Result<(), String> {
    let file = File::open(archive_path).map_err(|e| e.to_string())?;
    let mut archive = zip::ZipArchive::new(file).map_err(|e| e.to_string())?;
    for index in 0..archive.len() {
        let mut entry = archive.by_index(index).map_err(|e| e.to_string())?;
        let relative = entry.enclosed_name().ok_or("Archive has an unsafe file path")?.to_path_buf();
        if entry.unix_mode().is_some_and(|mode| mode & 0o170000 == 0o120000) { return Err("Archive contains an unsupported symlink".into()); }
        let target = destination.join(relative);
        if entry.is_dir() { fs::create_dir_all(&target).map_err(|e| e.to_string())?; }
        else {
            if let Some(parent) = target.parent() { fs::create_dir_all(parent).map_err(|e| e.to_string())?; }
            let mut output = File::create(target).map_err(|e| e.to_string())?;
            io::copy(&mut entry, &mut output).map_err(|e| e.to_string())?;
        }
    }
    Ok(())
}

fn find_server(folder: &Path, depth: usize) -> Option<PathBuf> {
    if depth > 5 { return None; }
    for entry in fs::read_dir(folder).ok()?.flatten() {
        let path = entry.path();
        if path.is_file() && path.file_name().and_then(|x| x.to_str()).is_some_and(|x| x.eq_ignore_ascii_case("llama-server.exe")) { return Some(path); }
        if path.is_dir() {
            if let Some(found) = find_server(&path, depth + 1) { return Some(found); }
        }
    }
    None
}

fn release_install_name(release_id: u64, cuda: bool) -> String {
    format!("llama-release-{release_id}-{}", if cuda { "cuda12" } else { "cpu" })
}

fn install_llama_windows(data_dir: PathBuf, cuda: bool) -> Result<String, String> {
    if !cfg!(all(target_os = "windows", target_arch = "x86_64")) {
        return Err("Automatic installation currently supports Windows x64; use an existing llama.cpp installation on other platforms.".into());
    }
    let client = reqwest::blocking::Client::builder().timeout(Duration::from_secs(240))
        .user_agent("Solarium/0.1").build().map_err(|e| e.to_string())?;
    let release: Release = client.get("https://api.github.com/repos/ggml-org/llama.cpp/releases/latest")
        .send().map_err(|e| e.to_string())?.error_for_status().map_err(|e| e.to_string())?
        .json().map_err(|e| e.to_string())?;
    // GitHub release IDs are numeric and safe for directory names; release tags are
    // arbitrary display strings and must not be used as filesystem components.
    let release_id = release.id;
    let target_asset = release.assets.iter().find(|a| a.name.starts_with("llama-") &&
        (if cuda { a.name.ends_with("bin-win-cuda-12.4-x64.zip") } else { a.name.ends_with("bin-win-cpu-x64.zip") }))
        .ok_or("No compatible Windows x64 llama.cpp release asset was found.")?;
    let runtime = if cuda { Some(release.assets.iter().find(|a| a.name.starts_with("cudart-") && a.name.ends_with("bin-win-cuda-12.4-x64.zip"))
        .ok_or("The CUDA runtime archive is missing from this release.")?) } else { None };
    fs::create_dir_all(&data_dir).map_err(|e| e.to_string())?;
    let install = data_dir.join(release_install_name(release_id, cuda));
    if let Some(path) = find_server(&install, 0) { return Ok(path.to_string_lossy().to_string()); }
    let stage = data_dir.join(format!(".install-{release_id}-{}-{}", if cuda { "cuda" } else { "cpu" }, std::process::id()));
    if stage.exists() { fs::remove_dir_all(&stage).map_err(|e| format!("Cannot clear incomplete installation: {e}"))?; }
    fs::create_dir(&stage).map_err(|e| e.to_string())?;
    let result = (|| {
        for (i, asset) in std::iter::once(target_asset).chain(runtime).enumerate() {
            let zip_path = stage.join(format!("download-{i}.zip"));
            download_verified(&client, asset, &zip_path)?;
            extract_zip(&zip_path, &stage)?;
            fs::remove_file(&zip_path).map_err(|e| e.to_string())?;
        }
        if find_server(&stage, 0).is_none() { return Err("Downloaded release does not contain llama-server.exe.".into()); }
        fs::rename(&stage, &install).map_err(|e| e.to_string())?;
        Ok(find_server(&install, 0).ok_or("Installed executable not found")?.to_string_lossy().to_string())
    })();
    if result.is_err() { let _ = fs::remove_dir_all(stage); }
    result
}

#[tauri::command]
async fn install_llama_server(cuda: bool) -> Result<String, String> {
    let dir = ensure_runtime_dir()?.join("engines");
    tauri::async_runtime::spawn_blocking(move || install_llama_windows(dir, cuda))
        .await.map_err(|e| e.to_string())?
}

#[tauri::command]
fn get_runtime_location() -> Result<String, String> {
    Ok(ensure_runtime_dir()?.display().to_string())
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .manage(EngineProcesses::default())
        .plugin(tauri_plugin_sql::Builder::default().build())
        .plugin(tauri_plugin_dialog::init())
        .invoke_handler(tauri::generate_handler![
            start_llama_server, stop_llama_server, start_vllm_server, stop_vllm_server,
            install_llama_server, install_vllm_wsl, nvidia_gpu_status, read_engine_log,
            get_runtime_location,
        ])
        .run(tauri::generate_context!())
        .expect("failed to initialize Solarium");
}

#[cfg(test)]
mod installer_tests {
    use super::*;

    #[test]
    fn upstream_release_tags_cannot_change_the_install_path() {
        // The previous installer rejected legitimate release tags containing dots
        // and other punctuation. The official numeric release ID is the only
        // value permitted in a generated directory component.
        let release: Release = serde_json::from_str(r#"{
            "id": 123456, "tag_name": "b12345+candidate.1",
            "assets": [{"name":"llama-b12345-bin-win-cpu-x64.zip",
                "browser_download_url":"https://github.com/ggml-org/llama.cpp/releases/download/b12345/llama.zip",
                "digest":"sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
                "size": 42}]
        }"#).unwrap();
        assert_eq!(release.id, 123456);
        assert_eq!(release_install_name(release.id, false), "llama-release-123456-cpu");
        assert_eq!(release_install_name(release.id, true), "llama-release-123456-cuda12");
    }
}
