//! Solarium-managed runtimes are installed alongside the development project or portable executable.
//! This deliberately avoids Tauri's per-user application-data location for large downloads.
use std::fs;
use std::path::PathBuf;
#[cfg(target_os = "windows")]
use std::process::Command;

pub fn runtime_dir() -> Result<PathBuf, String> {
    let base = if cfg!(debug_assertions) {
        // Cargo's working directory varies between `tauri dev` and `cargo run`.
        // CARGO_MANIFEST_DIR reliably points to `<project>/src-tauri`.
        PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .parent().ok_or("Cannot resolve the Solarium project directory")?.to_path_buf()
    } else {
        // Portable builds: never trust the launcher's current working directory.
        std::env::current_exe().map_err(|e| e.to_string())?
            .parent().ok_or("Cannot locate the Solarium executable")?.to_path_buf()
    };
    Ok(base.join("runtime"))
}

pub fn ensure_runtime_dir() -> Result<PathBuf, String> {
    let dir = runtime_dir()?;
    fs::create_dir_all(&dir).map_err(|e| format!(
        "Cannot create {}: {e}. Run Solarium from a writable, portable folder (not Program Files).", dir.display()
    ))?;
    // Fail immediately if the parent of `runtime/` isn't writable, rather than after a large download.
    let probe = dir.join(format!(".writable-{}", std::process::id()));
    fs::write(&probe, []).map_err(|e| format!(
        "Runtime folder {} is not writable: {e}. Move Solarium to a writable folder.", dir.display()
    ))?;
    let _ = fs::remove_file(probe);
    Ok(dir)
}

#[cfg(target_os = "windows")]
pub fn wsl_runtime_path(distro: &str) -> Result<String, String> {
    let windows_path = ensure_runtime_dir()?;
    // On Windows Rust may return extended-length paths (\\?\D:\...); WSL's
    // `wslpath` expects ordinary Win32 paths, not the extended-length prefix.
    let win32_path = windows_path.to_string_lossy();
    let win32_path = win32_path.strip_prefix(r"\\?\").unwrap_or(&win32_path);
    let output = Command::new("wsl.exe")
        .args(["-d", distro, "--", "wslpath", "-u"])
        .arg(win32_path)
        .output().map_err(|e| format!("Cannot call WSL2: {e}"))?;
    if !output.status.success() {
        return Err(format!("WSL2 could not convert Solarium's runtime path. Confirm '{distro}' is installed and running. {}",
            String::from_utf8_lossy(&output.stderr).trim()));
    }
    let path = String::from_utf8_lossy(&output.stdout).trim().to_owned();
    if !path.starts_with('/') || path.contains('\0') || path.contains('\n') {
        return Err("WSL2 returned an invalid runtime path".into());
    }
    Ok(path)
}

#[cfg(not(target_os = "windows"))]
pub fn wsl_runtime_path(_distro: &str) -> Result<String, String> {
    Err("The managed WSL2 vLLM installer is Windows-only.".into())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn runtime_is_relative_to_solarium_and_never_appdata() {
        let path = runtime_dir().unwrap();
        assert_eq!(path.file_name().unwrap(), "runtime");
        assert!(!path.to_string_lossy().contains("solarium-vllm"));
    }
}
