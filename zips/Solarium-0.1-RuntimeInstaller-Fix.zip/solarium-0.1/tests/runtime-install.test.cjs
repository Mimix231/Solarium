const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

const root = path.join(__dirname, '..');

// Uses fake WSL tools, no real GPU, Python packages or internet connection.
test('vLLM installer keeps venv and caches inside an explicitly supplied runtime path', (t) => {
  if (process.platform === 'win32') return t.skip('POSIX shell mock runs in CI/Linux; native Windows needs WSL2.');
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'solarium-runtime-test-'));
  t.after(() => fs.rmSync(tmp, { recursive: true, force: true }));
  const tools = path.join(tmp, 'bin');
  const runtime = path.join(tmp, 'runtime path with spaces');
  fs.mkdirSync(tools);
  const executable = (name, code) => {
    const filename = path.join(tools, name);
    fs.writeFileSync(filename, `#!/usr/bin/env bash\n${code}\n`, { mode: 0o755 });
    return filename;
  };
  executable('nvidia-smi', 'exit 0');
  executable('id', 'if [ "$1" = "-u" ]; then echo 1000; else /usr/bin/id "$@"; fi');
  executable('python3', `
    if [ "$1" = "-c" ]; then exit 0; fi
    if [ "$1" = "-m" ] && [ "$2" = "venv" ]; then
      mkdir -p "$4/bin"
      printf '#!/usr/bin/env bash\\nexit 0\\n' > "$4/bin/python"
      chmod +x "$4/bin/python"
      exit 0
    fi
    exit 4
  `);
  const result = spawnSync('bash', [path.join(root, 'scripts/install-vllm-wsl.sh'), runtime], {
    encoding: 'utf8', env: { ...process.env, PATH: `${tools}:/usr/bin:/bin` },
  });
  assert.equal(result.status, 0, `script failed:\n${result.stderr}`);
  assert.ok(fs.existsSync(path.join(runtime, 'vllm/venv/bin/python')));
  for (const folder of ['cache', 'cache/cuda', 'cache/triton', 'huggingface', 'tmp']) {
    assert.ok(fs.statSync(path.join(runtime, folder)).isDirectory(), folder);
  }
  assert.match(result.stdout, /runtime path with spaces/);
});

test('runtime paths and GitHub release directories cannot use unchecked release tag names', () => {
  const rust = fs.readFileSync(path.join(root, 'src-tauri/src/lib.rs'), 'utf8');
  const runtime = fs.readFileSync(path.join(root, 'src-tauri/src/runtime.rs'), 'utf8');
  assert.match(rust, /struct Release \{ id: u64,/);
  assert.match(rust, /release_install_name\(release_id, cuda\)/);
  assert.doesNotMatch(rust, /Unsafe release version\./);
  assert.match(runtime, /base\.join\("runtime"\)/);
  assert.doesNotMatch(rust, /app_data_dir\(\)/);
  assert.match(rust, /wsl_runtime_path\(&distro\)/);
  assert.match(rust, /HF_HOME=\{linux_runtime\}\/huggingface/);
});
