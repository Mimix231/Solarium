# Solarium 0.1 — Runtime installer fix validation

**Fix focus:** The native installer no longer rejects free-form GitHub release tags, and engine downloads, caches, logs, and vLLM virtual environments are anchored under a deterministic `./runtime` path.

## Checks performed here

| Check | Result |
|---|---|
| `npm test` (source parsing, strict engine/domain TypeScript compilation, existing tests, runtime regressions) | **PASS — 19/19** |
| `bash -n scripts/install-vllm-wsl.sh` | **PASS** |
| Installer shell execution using mocked NVIDIA and Python tools, with a runtime path containing spaces | **PASS** |
| GitHub release directory handling | Implemented with numeric release ID; Rust unit test added, not executed here |
| Full frontend TypeScript (`npm run check`) | **NOT VERIFIED** — `vite/client` and other dependencies are not installed |
| ESLint / Vite production bundle | **NOT VERIFIED** — npm packages unavailable in this environment |
| Native Rust (`cargo test`, `cargo check`, `tauri build`) | **NOT VERIFIED** — Rust toolchain unavailable in this environment |
| Actual verified GitHub release download on Windows | **NOT VERIFIED** — no outbound networking / Windows runtime |
| vLLM package installation and model launch on real WSL2 | **NOT VERIFIED** — no WSL2/NVIDIA hardware |

## Code changes

- `src-tauri/src/lib.rs`: removed dangerous/overly restrictive release-tag directory validation; generated install directories use the official release's numeric `id` instead. Preserved strict SHA-256 verification, HTTPS host checks, ZIP traversal prevention, and atomic staging.
- `src-tauri/src/runtime.rs`: deterministic development or portable-exe-relative `runtime/` folder and writable-folder checks; Windows-to-WSL drive path translation.
- `scripts/install-vllm-wsl.sh`: WSL-accessible virtual environment, package cache, temporary files, GPU caches, and model cache under `./runtime`; uses `--copies` for the virtualenv on a mounted Windows drive.
- `src/engine/desktop.ts`, `src/views/Models.tsx`: native runtime-location API and visible path in the Models UI.
- `tests/runtime-install.test.cjs`: shell-level installer regression and native source invariants.

## Windows verification checklist

From the project root on your desired drive (such as `D:`):

```powershell
npm install
npm test
npm run check
npm run lint
npm run build
npm run desktop:dev
```

In the desktop app, check the displayed **Local runtime folder**. It should point to `D:\\...\\solarium-0.1\\runtime` when developing on D:, not `%APPDATA%`. Then try **Install / update**, confirm an official checksum-verified llama-server executable appears under `runtime\\engines\\`, and start it with your GGUF. Install vLLM next if WSL2 and Python are ready; expect its environment in `runtime\\vllm\\venv` and HF caches in `runtime\\huggingface`. Consult `docs/RTX3060_DUAL_ENGINE_SETUP.md`.

**Limitations:** This is a source patch tested as far as the available Linux sandbox permits, **not** a verified Windows executable. On packaged installs the runtime is beside the executable; a protected `Program Files` directory is not writable. WSL2 itself and its system Python/drivers may still reside on C:, and existing GGUF files and SQLite databases are not migrated. Two engines share the RTX 3060's 12 GB of VRAM and may not fit simultaneously.
