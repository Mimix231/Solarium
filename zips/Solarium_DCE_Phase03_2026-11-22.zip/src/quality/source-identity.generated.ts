// Generated from actual source bytes; never hand edited.
export const sourceIdentity={"schemaVersion":1,"sha256":"9ab2fd2bdc8c044826e82babfcb3147de6d589c562f4a75f1ad38e1af8360530","files":725,"commit":null} as const;
