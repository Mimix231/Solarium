// Generated from actual source bytes; never hand edited.
export const sourceIdentity={"schemaVersion":1,"sha256":"abc9a08d7cc11d0b5bec8e15b7bf9a297201b676be7a1d92ea8bcb0f041885c4","files":378,"commit":"e7dd1eb68147dad936aca83e70a94c2bd3feca11"} as const;
