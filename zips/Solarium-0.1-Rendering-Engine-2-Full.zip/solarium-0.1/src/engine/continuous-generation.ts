import type { Capabilities, GenerationMetrics, LocalModel } from '../domain/types';
import type { InferenceAdapter } from './backends';
import { generationMetrics } from './backends';
import { createContinuationMessages, prepareGeneration, CHUNK_SIZE } from './context-window';
import { ModelContextError, type GenerationRequestOptions, type LlamaMessage, type LlamaTurnResult } from './llama';

/** Output allowance is reused; it does NOT allocate a second copy of model weights. */
export const OUTPUT_SEGMENT_TOKENS = CHUNK_SIZE;

export interface ContinuousAnswerOptions {
  adapter: InferenceAdapter;
  model: LocalModel;
  capabilities: Capabilities;
  messages: LlamaMessage[];
  signal: AbortSignal;
  request?: GenerationRequestOptions;
  onAnswer(delta: string): void;
  onReasoning(delta: string): void;
  onReasoningState?(active: boolean): void;
  onMetrics?(metrics: GenerationMetrics): void;
}

export interface ContinuousAnswerResult {
  answer: string;
  result: LlamaTurnResult;
  segments: number;
  /** Recoverable continuation limit: the already streamed answer remains available. */
  warning?: string;
}

/** Deduplicate a repeated prefix from a restarted streaming response without rewriting previous text. */
export function mayContinuePreviousSuffix(existing: string, incoming: string): boolean {
  const maximum = Math.min(1200, existing.length);
  if (incoming.length > maximum) return false;
  for (let length = maximum; length >= Math.max(8, incoming.length); length--) {
    if (existing.slice(-length).startsWith(incoming)) return true;
  }
  return false;
}

export function overlapLength(existing: string, incoming: string): number {
  const limit = Math.min(1200, existing.length, incoming.length);
  for (let count = limit; count >= 8; count--) {
    if (existing.endsWith(incoming.slice(0, count))) return count;
  }
  return 0;
}

/** The same local server/model remains loaded across requests; no new model is spawned. */
export async function streamContinuousAnswer(options: ContinuousAnswerOptions): Promise<ContinuousAnswerResult> {
  const { adapter, model, capabilities, messages, signal, request, onReasoning, onReasoningState, onMetrics } = options;
  let answer = '';
  let segments = 0;
  let failures = 0;
  let history = messages;
  let lastResult: LlamaTurnResult | undefined;
  let warning: string | undefined;
  let reasoningChars = 0;
  while (true) {
    const previousLength = answer.length;
    const previousReasoning = reasoningChars;
    if (signal.aborted) throw new DOMException('Stopped', 'AbortError');
    const started = performance.now();
    let firstToken: number | null = null;
    let reasoningStarted = false;
    let pending = '';
    let resolvingOverlap = segments > 0;
    const append = (delta: string): void => { if (delta) { answer += delta; options.onAnswer(delta); } };
    // Buffer only a possible repeated suffix. Unrelated continuation text streams immediately.
    const emitAnswer = (delta: string): void => {
      if (firstToken === null) firstToken = performance.now();
      if (reasoningStarted) { onReasoningState?.(false); reasoningStarted = false; }
      if (!resolvingOverlap) { append(delta); return; }
      pending += delta;
      if (mayContinuePreviousSuffix(answer, pending)) return;
      append(pending.slice(overlapLength(answer, pending)));
      pending = '';
      resolvingOverlap = false;
    };
    let extraHeadroom = 0;
    let activeCapabilities = capabilities;
    let result: LlamaTurnResult;
    for (let attempt = 0; ; attempt++) {
      const prepared = await prepareGeneration(adapter, model, activeCapabilities, history, signal, request, extraHeadroom);
      try {
        result = await adapter.generate(model, prepared.messages, activeCapabilities, {
          answer: emitAnswer,
          reasoning: (text) => { reasoningChars += text.length; if (!reasoningStarted) { reasoningStarted = true; onReasoningState?.(true); } onReasoning(text); },
        }, signal, { ...request, tools: prepared.tools, outputTokens: prepared.outputTokens });
        break;
      } catch (error) {
        // Only retry when the request was rejected before streaming any content.
        // Use the server's actual prompt count to correct inaccurate fallbacks.
        if (!(error instanceof ModelContextError) || attempt >= 2 || answer.length !== previousLength || signal.aborted) throw error;
        if (error.contextSize && error.contextSize > 0) {
          activeCapabilities = { ...activeCapabilities, contextSize: Math.min(prepared.contextSize, error.contextSize) };
        }
        extraHeadroom += Math.max(512, (error.promptTokens ?? prepared.promptTokens + 512) - prepared.promptTokens + 128);
      }
    }
    if (reasoningStarted) onReasoningState?.(false);
    if (pending) append(pending.slice(overlapLength(answer, pending)));
    if (result.finishReason === 'content_filter') throw new Error('The inference backend stopped generation due to a content filter.');
    onMetrics?.(generationMetrics(adapter.kind, model.modelId, started, firstToken, performance.now(), result.answer, result.usage?.completionTokens));
    segments++;
    lastResult = result;
    if (result.calls.length || result.finishReason !== 'length') break;
    const newAnswerChars = answer.length - previousLength;
    const newReasoningChars = reasoningChars - previousReasoning;
    // Some templates exhaust the entire chunk inside their reasoning channel.
    // Allow one additional continuation, but don't silently loop indefinitely.
    if (newAnswerChars < 8) failures++;
    else failures = 0;
    if (failures >= 2) {
      warning = newReasoningChars > 0
        ? 'The model spent the continuation allowance on reasoning without producing more answer text.'
        : 'The model did not provide more answer text in two consecutive continuations.';
      // A partially streamed response is a usable result and should not be erased
      // by throwing from here. The UI will mark it as potentially incomplete.
      if (!answer.trim()) throw new Error(warning);
      break;
    }
    // vLLM/llama.cpp reuse loaded weights. The server manages a bounded KV cache according to its own context configuration.
    history = createContinuationMessages(messages, answer);
  }
  if (!lastResult) throw new Error('Inference returned no result.');
  return { answer, result: lastResult, segments, ...(warning ? { warning } : {}) };
}
