// Generated from actual source bytes; never hand edited.
export const sourceIdentity={"schemaVersion":1,"sha256":"855f45a3f98e2b614128dd18ccaf081d8eceeb5fb4865b8f0f60a24601234d57","files":719,"commit":null} as const;
