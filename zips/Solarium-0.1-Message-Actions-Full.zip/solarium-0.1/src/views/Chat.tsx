import { useShallow } from 'zustand/react/shallow';
import { useEffect, useRef, useState, type ChangeEvent, type DragEvent, type KeyboardEvent } from 'react';
import { Alert, Box, Button, Chip, CircularProgress, Dialog, DialogActions, DialogContent, DialogTitle, FormControl, IconButton, MenuItem, ListSubheader, Select, Stack, TextField, Tooltip, Typography } from '@mui/material';
import AttachFileRounded from '@mui/icons-material/AttachFileRounded';
import TravelExploreRounded from '@mui/icons-material/TravelExploreRounded';
import FolderOpenRounded from '@mui/icons-material/FolderOpenRounded';
import ContentCopyRounded from '@mui/icons-material/ContentCopyRounded';
import EditOutlined from '@mui/icons-material/EditOutlined';
import ReplayRounded from '@mui/icons-material/ReplayRounded';
import CheckRounded from '@mui/icons-material/CheckRounded';
import { RichMessage } from '../components/RichMessage';
import { ThinkingPanel, type ThinkingSnapshot } from '../components/ThinkingPanel';
import { buildSearchIntent, rankResearchResults } from '../engine/search-intent';
import { readAttachments, readPublicWebpage, searchPublicWeb } from '../engine/creator';
import SendRounded from '@mui/icons-material/SendRounded';
import StopRounded from '@mui/icons-material/StopRounded';
import AddRounded from '@mui/icons-material/AddRounded';
import AutoAwesomeRounded from '@mui/icons-material/AutoAwesomeRounded';
import InsightsRounded from '@mui/icons-material/InsightsRounded';
import CloseRounded from '@mui/icons-material/CloseRounded';
import SmartToyOutlined from '@mui/icons-material/SmartToyOutlined';
import { AvatarView } from '../components/AvatarView';
import { useSolarium } from '../state/useSolarium';
import { suggestExpression } from '../domain/expressions';
import { now, uid, type GenerationMetrics, type SparkMode, type Expression, type ChatAttachment, type ChatSource } from '../domain/types';
import { runAgent } from '../engine/agent';
import { AgentEventEmitter } from '../engine/activity';
import { activateGGUFModel, scanGGUFDirectory } from '../engine/desktop';
import { catalogToModels } from '../engine/catalog';

const modes: SparkMode[] = ['conversation', 'work', 'research', 'creative'];
type Decision = 'allow' | 'deny';
type ReplyRequest = { kind: 'new' } | { kind: 'retry'; sessionId: string; messageId: string; editedContent?: string };
function ActivityPanel() {
  const events = useSolarium((s) => s.events);
  const close = useSolarium((s) => s.updatePreferences);
  return <aside className="activity-panel"><Stack direction="row" justifyContent="space-between" alignItems="center" px={1.8} py={1.5}><Box><Typography fontWeight={750} fontSize={12}>Live activity</Typography><Typography color="text.secondary" fontSize={10}>Actual model and tool events</Typography></Box><IconButton aria-label="Close activity" onClick={() => close({ showActivity: false })}><CloseRounded fontSize="small" /></IconButton></Stack>
    <Box className="activity-feed">{events.map((event) => <Box key={event.id} className={`activity-event ${event.kind}`}>
      <Stack direction="row" justifyContent="space-between" alignItems="center"><Typography fontWeight={700} fontSize={10.5} textTransform="capitalize">{event.kind === 'phase' ? event.phase : event.kind.replaceAll('_', ' ')}</Typography><Typography fontSize={9} color="text.secondary">{event.sequence}</Typography></Stack>
      <Typography fontSize={11} color="text.secondary" sx={{ whiteSpace: 'pre-wrap', overflowWrap: 'anywhere' }}>{event.text || event.status || event.tool}</Typography>
      {event.tool && <Chip size="small" label={event.tool} sx={{ mt: .5 }} />}
    </Box>)}{!events.length && <Typography fontSize={11} color="text.secondary">Activity will appear when a model runs. No simulated thinking cards.</Typography>}</Box>
  </aside>;
}
export function Chat() {
  const { workspace, createSession, appendMessage, setSessionMode, updatePreferences, pushEvent, clearEvents, setView } = useSolarium(useShallow((state) => ({ workspace: state.workspace, createSession: state.createSession, appendMessage: state.appendMessage, setSessionMode: state.setSessionMode, updatePreferences: state.updatePreferences, pushEvent: state.pushEvent, clearEvents: state.clearEvents, setView: state.setView })));
  const spark = workspace.sparks.find((s) => s.id === workspace.selectedSparkId) ?? workspace.sparks[0]!;
  const session = workspace.sessions.find((s) => s.id === workspace.activeSessionId);
  const modelId = session?.modelId ?? spark.preferredModelId ?? workspace.models[0]?.id ?? '';
  const model = workspace.models.find((m) => m.id === modelId);
  const [input, setInput] = useState('');
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [editingText, setEditingText] = useState('');
  const [reaction, setReaction] = useState<Expression | null>(null);
  const [autoReact, setAutoReact] = useState(true);
  const [metrics, setMetrics] = useState<GenerationMetrics | null>(null);
  const [draft, setDraft] = useState('');
  const [thinking, setThinking] = useState<ThinkingSnapshot | undefined>(undefined);
  const [busyStartedAt, setBusyStartedAt] = useState<number | null>(null);
  const [chatStatus, setChatStatus] = useState<'searching' | 'loading' | 'generating'>('generating');
  const thinkingPhaseStart = useRef<number | null>(null);
  const [busy, setBusy] = useState(false);
  const [modelBusy, setModelBusy] = useState(false);
  const [loadedModel, setLoadedModel] = useState('');
  const [error, setError] = useState('');
  const [pendingAttachments, setPendingAttachments] = useState<ChatAttachment[]>([]);
  const [research, setResearch] = useState(false);
  const [researchStatus, setResearchStatus] = useState('');
  const attachRef = useRef<HTMLInputElement>(null);
  const [attaching, setAttaching] = useState(false);
  const [approval, setApproval] = useState<{ name: string; args: Record<string, unknown> } | null>(null);
  const approvalRef = useRef<((value: Decision) => void) | null>(null);
  const controller = useRef<AbortController | null>(null);
  const displayFrame = useRef<number | null>(null);
  const thinkingFrame = useRef<number | null>(null);
  const bottom = useRef<HTMLDivElement>(null);
  useEffect(() => { bottom.current?.scrollIntoView({ behavior: 'smooth', block: 'end' }); }, [draft, session?.messages.length]);
  useEffect(() => () => {
    controller.current?.abort(); approvalRef.current?.('deny'); approvalRef.current = null;
    if (displayFrame.current !== null) cancelAnimationFrame(displayFrame.current);
    if (thinkingFrame.current !== null) cancelAnimationFrame(thinkingFrame.current);
  }, []);
  useEffect(() => {
    const folder = workspace.preferences.ggufDirectory;
    if (!folder || !('__TAURI_INTERNALS__' in window)) return;
    let cancelled = false;
    void scanGGUFDirectory(folder).then((files) => {
      if (!cancelled) useSolarium.getState().syncCatalog(catalogToModels(files, useSolarium.getState().workspace.preferences.serverPort), folder);
    }).catch((error: unknown) => { if (!cancelled) setError(`Could not scan your GGUF folder: ${String(error)}`); });
    return () => { cancelled = true; };
  }, [workspace.preferences.ggufDirectory, workspace.preferences.serverPort]);
  async function ensureGGUF(modelToLoad: NonNullable<typeof model>): Promise<NonNullable<typeof model>> {
    if (!modelToLoad.ggufPath) return modelToLoad;
    const preferences = useSolarium.getState().workspace.preferences;
    if (!preferences.llamaExecutable) throw Error('Install llama.cpp first in Models → Inference Engines.');
    const result = await activateGGUFModel({ executable: preferences.llamaExecutable, gguf: modelToLoad.ggufPath,
      port: preferences.serverPort, context: modelToLoad.contextSize, gpuLayers: 20 });
    const ready = { ...modelToLoad, endpoint: `http://127.0.0.1:${preferences.serverPort}`, modelId: result.modelId };
    useSolarium.getState().upsertModel(ready);
    setLoadedModel(result.detail);
    return ready;
  }
  async function changeModel(id: string) {
    if (busy || modelBusy) return;
    const selected = useSolarium.getState().workspace.models.find((m) => m.id === id);
    if (!selected) return;
    const target = useSolarium.getState().workspace.activeSessionId ?? useSolarium.getState().createSession();
    useSolarium.getState().updateSession(target, { modelId: selected.id });
    setLoadedModel(''); setError('');
    if (selected.ggufPath) {
      setModelBusy(true);
      try { await ensureGGUF(selected); }
      catch (error) { setError(`Model loading failed: ${String(error)}`); }
      finally { setModelBusy(false); }
    }
  }
  function answerApproval(value: Decision) {
    approvalRef.current?.(value); approvalRef.current = null; setApproval(null);
  }
  function requestApproval(name: string, args: Record<string, unknown>, signal: AbortSignal): Promise<Decision> {
    if (signal.aborted) return Promise.resolve('deny');
    return new Promise((resolve) => {
      const done = (value: Decision) => { signal.removeEventListener('abort', abort); resolve(value); };
      const abort = () => { approvalRef.current = null; setApproval(null); done('deny'); };
      signal.addEventListener('abort', abort, { once: true });
      approvalRef.current = done; setApproval({ name, args });
    });
  }
  async function attachFiles(files: FileList | File[]) {
    setAttaching(true);
    try { const items = await readAttachments(files); setPendingAttachments((old) => {
      if (old.length + items.length > 8) { setError('Attach a maximum of eight files.'); return old; }
      return [...old, ...items];
    }); setError(''); }
    catch (error) { setError(String(error)); }
    finally { setAttaching(false); }
  }
  function onDrop(event: DragEvent<HTMLElement>) { event.preventDefault(); if (event.dataTransfer.files.length) void attachFiles(event.dataTransfer.files); }
  function onAttachmentChange(event: ChangeEvent<HTMLInputElement>) { if (event.target.files) void attachFiles(event.target.files); event.target.value = ''; }
  async function researchPrompt(text: string): Promise<{ context: string; sources: ChatSource[] }> {
    if (!research) return { context: '', sources: [] };
    const link = text.match(/https:\/\/[^\s<>"']+/i)?.[0]?.replace(/[),.;]+$/, '');
    if (link) {
      const page = await readPublicWebpage(link);
      return { context: `Opened URL: ${link}\n${page}`, sources: [{ title: new URL(link).hostname, url: link, excerpt: page.slice(0,240) }] };
    }
    const intent = buildSearchIntent(text);
    const results = await searchPublicWeb(intent.query);
    const selection = rankResearchResults(results, intent).slice(0, 4);
    if (!selection.length) return { context: `Research query: ${intent.query}\nNo relevant sources found. Do not cite unrelated search results.`, sources: [] };
    const opened = await Promise.all(selection.slice(0, 2).map(async (item) => {
      try { return `${item.title}\n${item.url}\n${(await readPublicWebpage(item.url)).slice(0,5500)}`; }
      catch { return `${item.title}\n${item.url}\n${item.excerpt}`; }
    }));
    return { context: `Search query: ${intent.query}\n${opened.join('\n\n')}\nAdditional results: ${selection.slice(2).map((i) => `${i.title}: ${i.url} — ${i.excerpt}`).join('\n')}`, sources: selection };
  }
  async function send(request: ReplyRequest = { kind: 'new' }) {
    // Resolve the original turn first: retries must regenerate in the same
    // conversation, with the original attachments and selected model.
    const before = useSolarium.getState().workspace;
    const existing = request.kind === 'retry' ? before.sessions.find((s) => s.id === request.sessionId) : undefined;
    const replySession = existing ?? (request.kind === 'new' ? before.sessions.find((s) => s.id === before.activeSessionId) : undefined);
    const userTurn = request.kind === 'retry' ? existing?.messages.find((m) => m.id === request.messageId && m.role === 'user') : undefined;
    if (request.kind === 'retry' && !userTurn) { setError('The selected user message no longer exists.'); return; }
    const text = (request.kind === 'retry' ? request.editedContent ?? userTurn?.content ?? '' : input).trim();
    const attachments = request.kind === 'retry' ? userTurn?.attachments ?? [] : pendingAttachments;
    if ((!text && !attachments.length) || busy || controller.current || modelBusy || attaching) return;
    const targetSpark = replySession ? before.sparks.find((s) => s.id === replySession.sparkId) ?? spark : spark;
    const targetModelId = replySession?.modelId ?? targetSpark.preferredModelId ?? before.models[0]?.id ?? '';
    const selectedModel = before.models.find((m) => m.id === targetModelId);
    if (!selectedModel) { setError('Select a GGUF model or connect a model before chatting.'); return; }

    const abort = new AbortController(); controller.current = abort;
    setBusy(true); setBusyStartedAt(performance.now()); setChatStatus(research ? 'searching' : 'loading'); setReaction(null);
    thinkingPhaseStart.current = null;
    if (research) setResearchStatus('Searching and reading public websites…');
    let web: { context: string; sources: ChatSource[] } = { context: '', sources: [] };
    try { web = await researchPrompt(text); }
    catch (error) {
      if (!abort.signal.aborted) setError(`Web research failed: ${String(error)}`);
      controller.current = null; setBusy(false); setBusyStartedAt(null); setResearchStatus(''); return;
    } finally { setResearchStatus(''); }
    if (abort.signal.aborted) { controller.current = null; setBusy(false); setBusyStartedAt(null); return; }
    setChatStatus('loading');
    try { await ensureGGUF(selectedModel); }
    catch (error) {
      if (!abort.signal.aborted) setError(`Cannot load model: ${String(error)}`);
      controller.current = null; setBusy(false); setBusyStartedAt(null); return;
    }
    if (abort.signal.aborted) { controller.current = null; setBusy(false); setBusyStartedAt(null); return; }

    const current = useSolarium.getState();
    const targetId = request.kind === 'retry' ? request.sessionId : current.workspace.activeSessionId ?? current.createSession();
    if (request.kind === 'retry') {
      // Only discard the old response after the model is ready. A failed
      // load/search leaves all previous messages intact.
      if (!current.rewindUserTurn(targetId, request.messageId, request.editedContent)) {
        controller.current = null; setBusy(false); setBusyStartedAt(null);
        setError('Cannot retry this message. Refresh the conversation and try again.'); return;
      }
      setEditingMessageId(null); setEditingText('');
    } else {
      current.appendMessage(targetId, { id: uid(), role: 'user', content: text, attachments, createdAt: now() });
      setInput(''); setPendingAttachments([]);
    }
    const updated = useSolarium.getState().workspace;
    const chat = updated.sessions.find((s) => s.id === targetId);
    if (!chat) {
      controller.current = null; setBusy(false); setBusyStartedAt(null); setError('Could not locate the conversation.'); return;
    }
    const activeSpark = updated.sparks.find((s) => s.id === chat.sparkId) ?? targetSpark;
    const activeModel = updated.models.find((m) => m.id === (chat.modelId ?? activeSpark.preferredModelId ?? updated.models[0]?.id)) ?? selectedModel;
    setChatStatus('generating'); setMetrics(null); setThinking(undefined); setDraft(''); setError(''); clearEvents();
    const events = new AgentEventEmitter(pushEvent);
    let completed = '';
    let thinkingSnapshot: ThinkingSnapshot | undefined;
    const researchSources = new Map(web.sources.map((source) => [source.url, source]));
    try {
      completed = await runAgent({
        spark: activeSpark, model: activeModel, session: chat,
        memories: updated.memories, worlds: updated.worlds ?? [], preferences: updated.preferences, events, signal: abort.signal,
        projectInstructions: (updated.projects ?? []).find((p) => p.id === chat.projectId)?.instructions ?? '', supplementalContext: web.context, projects: updated.projects ?? [],
        onSource: (source) => { researchSources.set(source.url, source); },
        onMetrics: setMetrics, webEnabled: research,
        onThinking: (state) => {
          if (state.active && thinkingPhaseStart.current === null) thinkingPhaseStart.current = performance.now();
          const snapshot = { ...state, activeStartedAt: state.active ? thinkingPhaseStart.current ?? undefined : undefined };
          if (!state.active) thinkingPhaseStart.current = null;
          thinkingSnapshot = snapshot;
          if (thinkingFrame.current === null) thinkingFrame.current = requestAnimationFrame(() => { thinkingFrame.current = null; setThinking(thinkingSnapshot); });
        },
        onAnswer: (delta) => {
          completed += delta;
          if (displayFrame.current === null) displayFrame.current = requestAnimationFrame(() => { displayFrame.current = null; setDraft(completed); });
        },
        onApproval: (name, args) => requestApproval(name, args, abort.signal),
      });
    } catch (e) {
      if (!abort.signal.aborted) { events.emit('error', String(e)); setError(String(e)); }
    } finally {
      if (completed.trim()) { if (autoReact) setReaction(suggestExpression(completed)); }
      if (completed.trim()) appendMessage(targetId, { id: uid(), role: 'assistant', content: completed, sources: [...researchSources.values()], sparkId: activeSpark.id, ...(thinkingSnapshot?.text ? { reasoning: thinkingSnapshot.text, reasoningMs: thinkingSnapshot.elapsedMs } : {}), createdAt: now() });
      if (displayFrame.current !== null) { cancelAnimationFrame(displayFrame.current); displayFrame.current = null; }
      if (thinkingFrame.current !== null) { cancelAnimationFrame(thinkingFrame.current); thinkingFrame.current = null; }
      controller.current = null; setBusy(false); setBusyStartedAt(null); setDraft(''); setThinking(undefined); setApproval(null);
    }
  }
  async function copyUserMessage(text: string) {
    try { await navigator.clipboard.writeText(text); }
    catch { setError('Could not copy the message. Check clipboard permissions.'); }
  }
  function retryUserMessage(messageId: string, editedContent?: string) {
    if (!session || busy || modelBusy) return;
    if (editedContent !== undefined && !editedContent.trim()) { setError('A user message cannot be empty.'); return; }
    void send({ kind: 'retry', sessionId: session.id, messageId, editedContent });
  }
  function keydown(e: KeyboardEvent<HTMLDivElement>) { if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) { e.preventDefault(); void send(); } }
  return <div className="chat-layout" onDragOver={(e) => e.preventDefault()} onDrop={onDrop}>
    <section className="chat-primary">
      <div className="chat-header">
        <Stack direction="row" alignItems="center" gap={1} minWidth={0}><AvatarView avatar={reaction ? { ...spark.avatar, expression: reaction } : spark.avatar} size={31} active={busy} /><Stack minWidth={0}><Typography fontSize={12.5} fontWeight={750} noWrap>{spark.name}</Typography><Typography color="text.secondary" fontSize={10} noWrap>{model ? `${model.name} · ${model.backend ?? 'llama.cpp'}` : 'No model connected'}</Typography></Stack><span className={`status-dot ${model ? 'ready-dot' : ''}`} /></Stack>
        <Stack direction="row" alignItems="center" gap={.8}>
          <FormControl size="small" className="mode-select"><Select aria-label="Conversation mode" disabled={busy} value={session?.mode ?? 'conversation'} onChange={(e) => { if (session) setSessionMode(session.id, e.target.value as SparkMode); else setSessionMode(createSession(), e.target.value as SparkMode); }} sx={{ fontSize: 11 }}>{modes.map((mode) => <MenuItem key={mode} value={mode}>{mode[0]?.toUpperCase()}{mode.slice(1)}</MenuItem>)}</Select></FormControl>
          {metrics && <Tooltip title={`First token ${metrics.firstTokenMs?.toFixed(0) ?? '—'} ms · ${metrics.completionTokens === null ? 'estimated' : 'reported'} output tokens`}><Chip size="small" variant="outlined" label={`${metrics.tokensPerSecond ?? '—'} tok/s${metrics.completionTokens === null ? ' ≈' : ''}`} /></Tooltip>}
          <Tooltip title="Toggle lightweight avatar reaction from completed text"><Button size="small" variant="text" onClick={() => { setAutoReact((v) => !v); setReaction(null); }} sx={{ fontSize: 10 }}>{autoReact ? 'Expressions on' : 'Expressions off'}</Button></Tooltip>
          <Tooltip title="Activity"><IconButton aria-label="Toggle activity" onClick={() => updatePreferences({ showActivity: !workspace.preferences.showActivity })}><InsightsRounded fontSize="small" /></IconButton></Tooltip>
          <Tooltip title="New conversation"><IconButton aria-label="New conversation" disabled={busy} onClick={() => createSession()}><AddRounded fontSize="small" /></IconButton></Tooltip>
        </Stack>
      </div>
      <div className="message-list" role="log" aria-live="polite">
        {!session?.messages.length && <div className="welcome">
          <div className="welcome-orbit"><AvatarView avatar={reaction ? { ...spark.avatar, expression: reaction } : spark.avatar} size={94} /></div>
          <span className="eyebrow">YOUR AI COMPANION</span>
          <Typography variant="h5" mt={1}>A universe of possibilities.</Typography>
          <Typography color="text.secondary" mt={1} fontSize={13} maxWidth={440} textAlign="center">{spark.greeting}</Typography>
          <Stack direction="row" gap={1} justifyContent="center" flexWrap="wrap" mt={3}>
            {['Explore an idea', 'Help me write code', 'Brainstorm something new'].map((prompt) => <button key={prompt} className="prompt-chip" onClick={() => setInput(prompt)}>{prompt} ↗</button>)}
          </Stack>
          <Stack direction="row" gap={1} mt={3} flexWrap="wrap" justifyContent="center">
            <Button onClick={() => setView('sparks')} startIcon={<AutoAwesomeRounded />}>Customize Spark</Button>
            {!model && <Button onClick={() => setView('models')} startIcon={<SmartToyOutlined />} variant="contained">Connect a model</Button>}
          </Stack>
        </div>}
        {session?.messages.map((message) => <div className={`message-row ${message.role}`} key={message.id}>
          {message.role === 'assistant' && <AvatarView avatar={workspace.sparks.find((s) => s.id === message.sparkId)?.avatar ?? spark.avatar} size={26} />}
          <div className="message-content">
            {message.role === 'user' ? <>
              <div className="user-message-bubble">
                <Typography fontWeight={700} fontSize={11} color="text.secondary" mb={.45}>You</Typography>
                {editingMessageId === message.id ? <Stack gap={1}>
                  <TextField aria-label="Edit user message" multiline minRows={2} maxRows={12} autoFocus fullWidth size="small"
                    value={editingText} onChange={(e) => setEditingText(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Escape') { e.preventDefault(); setEditingMessageId(null); }
                      if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); retryUserMessage(message.id, editingText); }
                    }} sx={{ '& .MuiInputBase-root': { fontSize: 12.5 } }}/>
                  <Stack direction="row" justifyContent="flex-end" gap={.7}>
                    <Button size="small" disabled={busy || modelBusy} onClick={() => { setEditingMessageId(null); setEditingText(''); }}>Cancel</Button>
                    <Button size="small" variant="contained" disabled={!editingText.trim() || busy || modelBusy} startIcon={<CheckRounded sx={{ fontSize: 14 }}/>} onClick={() => retryUserMessage(message.id, editingText)}>Save & retry</Button>
                  </Stack>
                </Stack> : <RichMessage text={message.content} attachments={message.attachments} sources={message.sources}/>}
              </div>
              <div className="user-message-actions" aria-label="User message actions">
                <Tooltip title="Copy this message"><span><Button aria-label="Copy user message" size="small" startIcon={<ContentCopyRounded sx={{ fontSize: 13 }}/>} onClick={() => void copyUserMessage(message.content)}>Copy</Button></span></Tooltip>
                <Tooltip title="Edit this message and generate a new reply"><span><Button aria-label="Edit user message" size="small" disabled={busy || modelBusy || editingMessageId === message.id} startIcon={<EditOutlined sx={{ fontSize: 13 }}/>} onClick={() => { setEditingMessageId(message.id); setEditingText(message.content); setError(''); }}>Edit</Button></span></Tooltip>
                <Tooltip title="Remove later messages and regenerate the answer"><span><Button aria-label="Retry user message" size="small" disabled={busy || modelBusy || editingMessageId === message.id} startIcon={<ReplayRounded sx={{ fontSize: 13 }}/>} onClick={() => retryUserMessage(message.id)}>Retry</Button></span></Tooltip>
                <Button size="small" disabled={busy} onClick={() => { if (session) useSolarium.getState().branchSession(session.id, message.id); }} title="Create an independent conversation from this message">↳ Branch</Button>
              </div>
            </> : <>
              <Typography fontWeight={700} fontSize={11} color="text.secondary" mb={.45}>{workspace.sparks.find((s) => s.id === message.sparkId)?.name ?? spark.name}</Typography>
              <ThinkingPanel snapshot={message.reasoning ? { text: message.reasoning, elapsedMs: message.reasoningMs ?? 0, active: false } : undefined}/>
              <RichMessage text={message.content} attachments={message.attachments} sources={message.sources}/>
              <Button sx={{ mt: .35, opacity: .7, fontSize: 10 }} size="small" disabled={busy} onClick={() => { if (session) useSolarium.getState().branchSession(session.id, message.id); }} title="Create an independent conversation from this message">↳ Branch from here</Button>
            </>}
          </div>
        </div>)}
        {busy && <div className="message-row assistant"><AvatarView avatar={reaction ? { ...spark.avatar, expression: reaction } : spark.avatar} size={26} active /><div className="message-content"><Typography fontSize={11} fontWeight={700} mb={.6}>{spark.name} <CircularProgress size={10} sx={{ ml: .8 }} /></Typography><ThinkingPanel snapshot={thinking} busy busyStartedAt={busyStartedAt} status={chatStatus}/><RichMessage text={draft || researchStatus || ''}/></div></div>}
        <div ref={bottom} />
      </div>
      <div className="composer-wrap">
        {error && <Alert severity="warning" onClose={() => setError('')} sx={{ mb: 1 }}>{error}</Alert>}
        <div className="composer-model-row">
          <FormControl size="small" sx={{ minWidth: 225, maxWidth: '85%' }}>
            <Select variant="standard" disableUnderline size="small" aria-label="Choose GGUF or connected model" disabled={busy || modelBusy}
              displayEmpty value={modelId} onChange={(e) => void changeModel(e.target.value)} sx={{ fontSize: 11 }}>
              {!workspace.models.length && <MenuItem value="" disabled>Set a GGUF folder in Settings</MenuItem>}
              {workspace.models.some((m) => m.ggufPath) && <ListSubheader>GGUF models in your folder</ListSubheader>}
              {workspace.models.filter((m) => m.ggufPath).map((m) => <MenuItem key={m.id} value={m.id}>{m.name}</MenuItem>)}
              {workspace.models.some((m) => !m.ggufPath) && <ListSubheader>Other local servers</ListSubheader>}
              {workspace.models.filter((m) => !m.ggufPath).map((m) => <MenuItem key={m.id} value={m.id}>{m.name} · {m.backend ?? 'llama.cpp'}</MenuItem>)}
            </Select>
          </FormControl>
          {modelBusy ? <Stack direction="row" gap={.7} alignItems="center"><CircularProgress size={11}/><Typography fontSize={10}>Loading GGUF…</Typography></Stack> : <Typography color="text.secondary" fontSize={10} noWrap>{loadedModel || (model?.ggufPath ? 'Select to load · local GGUF' : (model ? model.backend : 'No GGUF folder configured'))}</Typography>}
          <Button size="small" onClick={() => setView('settings')} sx={{ ml: 'auto' }}>Library settings</Button>
        </div>
        {session?.projectId && <Button size="small" startIcon={<FolderOpenRounded fontSize="small"/>} onClick={() => setView('projects')} sx={{ mb: .5 }}>Project: {(workspace.projects ?? []).find((p) => p.id === session.projectId)?.name ?? 'Unknown project'}</Button>}
        {pendingAttachments.length > 0 && <Stack direction="row" gap={.7} flexWrap="wrap" mb={.7}>{pendingAttachments.map((a) => <Chip key={a.id} size="small" label={`${a.kind === 'image' ? '▧ ' : '▤ '}${a.name}`} onDelete={() => setPendingAttachments((items) => items.filter((i) => i.id !== a.id))}/>)}</Stack>}
        <Stack direction="row" gap={1} mb={.6} alignItems="center"><input ref={attachRef} hidden type="file" multiple accept="image/png,image/jpeg,image/webp,.txt,.md,.pdf,.docx,.ts,.tsx,.js,.jsx,.json,.css,.html,.py,.rs,.go,.java,.cpp,.xml,.yml,.yaml,.toml,.sql,.csv,.log,.svg" onChange={onAttachmentChange}/>
          <Button size="small" disabled={busy || attaching} startIcon={<AttachFileRounded sx={{ fontSize: 15 }}/>} onClick={() => attachRef.current?.click()}>{attaching ? 'Reading…' : 'Attach files'}</Button>
          <Button size="small" color={research ? 'primary' : 'inherit'} variant={research ? 'contained' : 'text'} startIcon={<TravelExploreRounded sx={{ fontSize: 15 }}/>} onClick={() => setResearch((value) => !value)} disabled={busy}>{research ? 'Web search on' : 'Web search off'}</Button>
          <Typography color="text.secondary" fontSize={10}>Drop images, PDFs, DOCX, or source files here</Typography></Stack>
        <div className="composer glass"><TextField placeholder={`Message ${spark.name}…`} variant="standard" fullWidth multiline maxRows={8} value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={keydown} disabled={busy || modelBusy} slotProps={{ input: { disableUnderline: true } }} />
          {busy ? <Tooltip title="Stop generation"><IconButton aria-label="Stop generation" className="send-button" onClick={() => { controller.current?.abort(); answerApproval('deny'); }}><StopRounded /></IconButton></Tooltip> : <Tooltip title="Send (Enter)"><span><IconButton aria-label="Send message" className="send-button" disabled={(!input.trim() && !pendingAttachments.length) || modelBusy || attaching} onClick={() => void send()}><SendRounded /></IconButton></span></Tooltip>}
        </div>
        <Typography color="text.secondary" textAlign="center" fontSize={10} mt={.7}>Your Sparks run on local models. Verify important information.</Typography>

      </div>
    </section>
    {workspace.preferences.showActivity && <ActivityPanel />}
    <Dialog open={Boolean(approval)} onClose={() => answerApproval('deny')} fullWidth maxWidth="xs"><DialogTitle fontSize={15}>Allow local tool?</DialogTitle><DialogContent><Typography mb={1} fontWeight={700}>{approval?.name}</Typography><Typography color="text.secondary" fontSize={12} sx={{ overflowWrap: 'anywhere', whiteSpace: 'pre-wrap' }}>{JSON.stringify(approval?.args ?? {}, null, 2)}</Typography><Typography color="text.secondary" fontSize={11} mt={2}>This tool will run only if you approve it.</Typography></DialogContent><DialogActions><Button onClick={() => answerApproval('deny')}>Deny</Button><Button variant="contained" onClick={() => answerApproval('allow')}>Allow once</Button></DialogActions></Dialog>
  </div>;
}
