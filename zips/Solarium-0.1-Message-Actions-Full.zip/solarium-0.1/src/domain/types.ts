export const traitNames = ['curiosity', 'analysis', 'empathy', 'humor', 'sarcasm', 'patience', 'creativity', 'confidence'] as const;
export type Trait = typeof traitNames[number];
export type Traits = Record<Trait, number>;
export type SparkMode = 'conversation' | 'work' | 'research' | 'creative';
export type Expression = 'neutral' | 'curious' | 'happy' | 'focused' | 'sad' | 'angry' | 'surprised' | 'embarrassed';
export type AvatarStyle = 'orb' | 'portrait' | 'glyph' | 'anime';
export type AnimeHair = 'bob' | 'long' | 'twin-tails' | 'ponytail' | 'pixie' | 'hime' | 'messy' | 'wolf-cut' | 'braided-crown' | 'side-ponytail' | 'curly' | 'layered' | 'ahoge';
export type AnimeEyes = 'round' | 'sharp' | 'sleepy' | 'almond' | 'droopy' | 'wide' | 'narrow' | 'upturned';
export type AnimeOutfit = 'hoodie' | 'uniform' | 'dress' | 'jacket' | 'kimono' | 'turtleneck' | 'armor' | 'cardigan';
export type AnimeAccessory = 'none' | 'ribbon' | 'glasses' | 'earrings' | 'cat-ears' | 'halo' | 'face-mask' | 'beret' | 'witch-hat' | 'cap' | 'headphones' | 'eyepatch' | 'choker' | 'flower-crown';
export interface AnimeAppearance {
  skin: string; hairColor: string; hairAccent: string; eyeColor: string; outfitColor: string; outfitAccent: string; background: string;
  hairstyle: AnimeHair; eyeShape: AnimeEyes; outfit: AnimeOutfit; accessory: AnimeAccessory;
  bangs: 'curtain' | 'straight' | 'swept'; face: 'oval' | 'round' | 'sharp';
  blush: number; eyeScale: number; hairVolume: number; zoom: number; offsetX: number; offsetY: number;
  sideHair: 'none' | 'wispy' | 'braids'; brows: 'soft' | 'arched' | 'straight'; pupil: 'round' | 'star' | 'slit';
  mouth: 'subtle' | 'smile' | 'smirk' | 'neutral' | 'grin' | 'laugh' | 'fang' | 'pout' | 'open' | 'cat-smile' | 'frown' | 'soft-smile'; accessorySecondary: AnimeAccessory;
  shoulderWidth: number; sparkle: number; irisPattern?: 'solid' | 'ringed' | 'sunburst' | 'sparkle' | 'gradient' | 'flower' | 'spiral';
  makeup?: 'none' | 'freckles' | 'eyeliner' | 'beauty-mark' | 'star-cheeks';
}
export type AvatarHair = 'wave' | 'short' | 'none';
export type AvatarAccessory = 'none' | 'glasses' | 'halo';
export interface SparkAvatar {
  style: AvatarStyle;
  color: string;
  secondary: string;
  glyph: string;
  image?: string;
  expression: Expression;
  hair: AvatarHair; accessory: AvatarAccessory;
  animate: boolean; expressionImages?: Partial<Record<Expression, string>>; anime?: AnimeAppearance;
}
export interface ExampleTurn { id: string; user: string; assistant: string }
export type PersonalityMode = 'simple' | 'advanced' | 'raw';
export interface SparkDNA {
  mode: PersonalityMode;
  raw: string;
  identity: string;
  speech: string;
  behavior: string;
  relationships: string;
  workStyle: string;
  boundaries: string;
}
export type InferenceBackend = 'llama.cpp' | 'vllm' | 'ollama';
export interface GenerationMetrics {
  backend: InferenceBackend;
  model: string;
  elapsedMs: number;
  firstTokenMs: number | null;
  completionTokens: number | null;
  estimatedTokens: number;
  tokensPerSecond: number | null;
}
export interface Spark {
  id: string; name: string; description: string; greeting: string;
  instructions: string; dna?: SparkDNA; traits: Traits; examples: ExampleTurn[];
  avatar: SparkAvatar; preferredModelId: string | null;
  createdAt: string; updatedAt: string;
}
export interface LocalModel {
  backend?: InferenceBackend;
  id: string; name: string; endpoint: string; modelId: string;
  ggufPath?: string; visionEnabled?: boolean; contextSize: number; temperature: number;
  maxTokens: number; createdAt: string;
}
export interface ChatAttachment { id: string; name: string; mime: string; kind: 'image' | 'text' | 'document'; size: number; text?: string; dataUrl?: string }
export interface ChatSource { title: string; url: string; excerpt?: string }
export interface ChatMessage { id: string; role: 'user' | 'assistant'; content: string; createdAt: string; sparkId?: string; attachments?: ChatAttachment[]; sources?: ChatSource[]; reasoning?: string; reasoningMs?: number }
export interface CreatorProject { id: string; name: string; description: string; instructions: string; folder: string; sparkId: string | null; modelId: string | null; createdAt: string; updatedAt: string }
export interface ChatSession {
  parentSessionId?: string; forkMessageId?: string;
  id: string; title: string; sparkId: string; modelId: string | null; projectId?: string | null;
  mode: SparkMode; createdAt: string; updatedAt: string; messages: ChatMessage[];
}
export interface WorldEntry { id: string; title: string; content: string; keywords: string[]; enabled: boolean }
export interface SparkWorld { id: string; sparkId: string; title: string; description: string; entries: WorldEntry[]; createdAt: string }
export interface LabCase { id: string; sparkId: string; title: string; prompt: string; expectedPhrases: string[]; lastResponse?: string; rating?: number }
export interface TeamRun { id: string; title: string; task: string; sparkIds: string[]; modelId: string; createdAt: string; steps: { sparkId: string; content: string; error?: string }[] }
export interface MemoryItem {
  id: string; text: string; scope: 'global' | 'spark'; sparkId: string | null;
  enabled: boolean; createdAt: string;
}
export type ThemeId = 'crystal' | 'obsidian' | 'aurora' | 'material' | 'slate' | 'solar' | 'peach' | 'cherry' | 'lime' | 'blueberry' | 'tangerine' | 'kiwi' | 'strawberry';
export type Density = 'ultra' | 'compact' | 'comfortable';
export interface Preferences {
  theme: ThemeId; density: Density; reducedMotion: boolean; workspaceMode?: 'companion' | 'workspace';
  sidebarOpen: boolean; showActivity: boolean;
  toolPermissions: Record<string, 'ask' | 'allow' | 'deny'>;
  llamaExecutable: string; serverPort: number; ggufDirectory: string;
}
export interface Workspace {
  schemaVersion: 1;
  sparks: Spark[]; sessions: ChatSession[]; models: LocalModel[];
  memories: MemoryItem[]; projects?: CreatorProject[]; activeProjectId?: string | null; worlds?: SparkWorld[]; labCases?: LabCase[]; teamRuns?: TeamRun[]; preferences: Preferences;
  selectedSparkId: string; activeSessionId: string | null;
}
export type ActivityPhase = 'looking' | 'thinking' | 'browsing' | 'observing' | 'verifying' | 'answering';
export type ActivityEvent = {
  id: string; runId: string; sequence: number; at: string;
  kind: 'phase' | 'reasoning' | 'tool_call' | 'tool_result' | 'error';
  phase?: ActivityPhase; status?: 'started' | 'completed' | 'failed';
  text?: string; tool?: string;
};
export interface Capabilities {
  reasoning: 'observed' | 'unknown';
  tools: 'supported' | 'unknown';
  vision: 'supported' | 'unknown' | 'user-enabled';
  contextSize: number | null;
  source: 'server-properties' | 'unavailable';
}
export const uid = (): string => globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2)}`;
export const now = (): string => new Date().toISOString();
