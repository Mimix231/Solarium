import type { ChatSource } from '../domain/types';

export interface SearchIntent { query: string; topic: 'software' | 'general'; terms: string[] }

/** Extract a research objective, rather than searching the user's entire conversational message. */
export function buildSearchIntent(message: string): SearchIntent {
  const text = message.replace(/https:\/\/\S+/gi, ' ').replace(/\s+/g, ' ').trim();
  const software = /\b(app|application|program|software|editor|ide|code|coding|programming|build|create|develop|implement|debug|typescript|javascript|react|rust|tauri|ffmpeg|python|llama\.?cpp|vllm|gpu|ui|interface|frontend|backend)\b/i.test(text);
  const video = /\b(video|timeline|footage|film editing|montage)\b/i.test(text);
  const image = /\b(image|photo|raster|vector|graphics)\b/i.test(text);
  const game = /\b(game|voxel|engine|rendering|three\.js)\b/i.test(text);
  const searchTopic = video ? 'video editing software architecture development' : image ? 'image editing software architecture development' : game ? 'game engine development architecture' : '';
  const stack = ['Tauri','Rust','React','TypeScript','FFmpeg','Python','Electron','WebGPU','CUDA','llama.cpp','vLLM'].filter((term) => new RegExp(`\\b${term.replace('.', '\\.')}\\b`, 'i').test(text));
  if (software) {
    const major = searchTopic || (/(bug|error|fix|debug)/i.test(text) ? 'programming debugging documentation' : 'software implementation architecture');
    return { topic: 'software', terms: [major, ...stack], query: [...new Set([major, ...stack, 'documentation examples'])].join(' ').slice(0, 240) };
  }
  const terms = text.replace(/^(hi|hello|hey|please|can you|could you|i want to|tell me about|look up|search for)\s+/ig, '')
    .replace(/\b(i|me|my|you|we|our|would|could|please|want|think|about|what|how|the|and|that|this|some|with)\b/gi,' ').split(/[^\p{L}\p{N}]+/u).filter((word) => word.length > 2).slice(0, 10);
  return { query: terms.join(' ').slice(0, 240) || text.slice(0, 240), topic: 'general', terms };
}

const TECH = /\b(programming|source code|software|library|api|sdk|development|editor|github|documentation|tutorial|framework|ffmpeg|rust|tauri|react|typescript|javascript|gpu|video processing|timeline)\b/i;
const MOVIES = /\b(cinema|movie theater|movie theatre|showtimes|tickets|screenings|box office|film festival|cinemas near)\b/i;
export function rankResearchResults(results: ChatSource[], intent: SearchIntent): ChatSource[] {
  const seen = new Set<string>();
  return results.map((item) => {
    let url: URL;
    try { url = new URL(item.url); } catch { return { item, score: -999 }; }
    const normalized = url.origin + url.pathname.replace(/\/$/, '');
    if (seen.has(normalized) || url.protocol !== 'https:') return { item, score: -999 };
    seen.add(normalized);
    const body = `${item.title} ${item.excerpt ?? ''} ${url.pathname}`;
    let score = 0;
    if (intent.topic === 'software') {
      if (TECH.test(body)) score += 5;
      if (MOVIES.test(body)) score -= 15;
      if (/(github\.com|docs\.|developer\.|docs\.rs|crates\.io|npmjs\.com|stackoverflow\.com)/i.test(url.hostname)) score += 3;
      if (/\b(editor|editing|software|code|development|api|ffmpeg|timeline)\b/i.test(body)) score += 2;
    } else {
      for (const term of intent.terms) if (body.toLowerCase().includes(term.toLowerCase())) score += 1;
    }
    return { item, score };
  }).filter((candidate) => candidate.score >= (intent.topic === 'software' ? 2 : 0))
    .sort((a, b) => b.score - a.score).map(({ item }) => item);
}
