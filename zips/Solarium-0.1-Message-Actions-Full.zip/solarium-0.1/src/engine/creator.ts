import type { ChatAttachment, ChatSource } from '../domain/types';
import { uid } from '../domain/types';
const invokeDesktop = async <T>(name: string, args: Record<string, unknown>): Promise<T> => {
  if (typeof window === 'undefined' || !('__TAURI_INTERNALS__' in window)) throw Error('This feature requires Solarium Desktop.');
  const { invoke } = await import('@tauri-apps/api/core');
  return invoke<T>(name, args);
};
export const listProjectFiles = (root: string) => invokeDesktop<string[]>('list_project_files', { root });
export const readProjectFile = (root: string, relative: string) => invokeDesktop<string>('read_project_file', { root, relative });
export const writeProjectFile = (root: string, relative: string, content: string, expected: string) => invokeDesktop<void>('write_project_file', { root, relative, content, expected });
export const searchPublicWeb = (query: string) => invokeDesktop<ChatSource[]>('search_public_web', { query });
export const readPublicWebpage = (url: string) => invokeDesktop<string>('read_public_webpage', { url });

const imageTypes = ['image/png','image/jpeg','image/webp'];
const textExtensions = /\.(?:txt|md|ts|tsx|js|jsx|json|css|html|py|rs|go|java|cpp|c|h|xml|yml|yaml|toml|sql|csv|sh|log|svg)$/i;
const readAsDataUrl = (file: File): Promise<string> => new Promise((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(String(reader.result)); reader.onerror = () => reject(Error('Could not read image')); reader.readAsDataURL(file); });
/** Explicit 8-file limit; never silently strip file content before submitting to a model. */
export async function readAttachments(files: FileList | File[]): Promise<ChatAttachment[]> {
  const selected = Array.from(files);
  if (selected.length > 8) throw Error('Attach up to eight files per message.');
  const attachments: ChatAttachment[] = [];
  for (const file of selected) {
    if (imageTypes.includes(file.type)) {
      if (file.size > 1_500_000) throw Error(`${file.name}: images must be smaller than 1.5 MB.`);
      attachments.push({ id: uid(), name: file.name, kind: 'image', size: file.size, mime: file.type, dataUrl: await readAsDataUrl(file) });
    } else if (textExtensions.test(file.name) || file.type.startsWith('text/')) {
      if (file.size > 450_000) throw Error(`${file.name}: text attachments must be smaller than 450 KB.`);
      attachments.push({ id: uid(), name: file.name, kind: 'text', size: file.size, mime: file.type || 'text/plain', text: await file.text() });
    } else if (file.type === 'application/pdf' || /\.pdf$/i.test(file.name)) {
      if (file.size > 8_000_000) throw Error(`${file.name}: PDFs must be smaller than 8 MB.`);
      const pdfjs = await import('pdfjs-dist');
      const worker = await import('pdfjs-dist/build/pdf.worker.min.mjs?url');
      pdfjs.GlobalWorkerOptions.workerSrc = worker.default;
      const document = await pdfjs.getDocument({ data: new Uint8Array(await file.arrayBuffer()), useSystemFonts: true, disableFontFace: true }).promise;
      const pages: string[] = [];
      for (let i = 1; i <= Math.min(document.numPages, 80); i++) {
        const page = await document.getPage(i); const content = await page.getTextContent();
        pages.push(`[Page ${i}] ${content.items.map((item: unknown) => {
          if (typeof item !== 'object' || item === null || !('str' in item)) return '';
          return typeof item.str === 'string' ? item.str : '';
        }).join(' ')}`);
      }
      attachments.push({ id: uid(), name: file.name, kind: 'document', size: file.size, mime: 'application/pdf', text: pages.join('\n').slice(0, 110_000) });
    } else if (/\.docx$/i.test(file.name)) {
      if (file.size > 8_000_000) throw Error(`${file.name}: Word documents must be smaller than 8 MB.`);
      const { default: mammoth } = await import('mammoth/mammoth.browser');
      const result = await mammoth.extractRawText({ arrayBuffer: await file.arrayBuffer() });
      attachments.push({ id: uid(), name: file.name, kind: 'document', size: file.size, mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', text: result.value.slice(0,110_000) });
    } else throw Error(`${file.name}: unsupported attachment type. Use images, PDF, DOCX or text/code files.`);
  }
  return attachments;
}
