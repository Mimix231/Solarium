import type { Capabilities, GenerationMetrics, LocalModel } from '../domain/types';
import type { InferenceAdapter } from './backends';
import { generationMetrics } from './backends';
import type { GenerationRequestOptions, LlamaMessage, LlamaTurnResult } from './llama';

/** Output allowance is reused; it does NOT allocate a second copy of model weights. */
export const OUTPUT_SEGMENT_TOKENS = 2048;

export interface ContinuousAnswerOptions {
  adapter: InferenceAdapter;
  model: LocalModel;
  capabilities: Capabilities;
  messages: LlamaMessage[];
  signal: AbortSignal;
  request?: GenerationRequestOptions;
  onAnswer(delta: string): void;
  onReasoning(delta: string): void;
  onReasoningState?(active: boolean): void;
  onMetrics?(metrics: GenerationMetrics): void;
}

export interface ContinuousAnswerResult {
  answer: string;
  result: LlamaTurnResult;
  segments: number;
}

/** Limit the *input* on a new request; the engine's fixed n_ctx/--max-model-len determines KV capacity. */
export function continuationMessages(original: LlamaMessage[], answer: string, contextSize: number, budget = OUTPUT_SEGMENT_TOKENS): LlamaMessage[] {
  const system = original.filter((message) => message.role === 'system');
  const recentUser = [...original].reverse().find((message) => message.role === 'user');
  if (!recentUser) throw new Error('Cannot continue without a user request.');
  // Simple approximate sizing, not a second persistent context/memory system. Retain persona and latest request.
  const instruction = 'Continue the previous answer from the exact point where it stopped. Do not restart, repeat earlier sections, or add a new introduction. Finish naturally when complete.';
  const textSize = (value: LlamaMessage['content']) => typeof value === 'string' ? value.length : value.reduce((size, item) => size + (item.type === 'text' ? item.text.length : 200), 0);
  const fixed = [...system, recentUser].reduce((sum, message) => sum + textSize(message.content), 0) + instruction.length;
  // Leave output budget and some template/special-token overhead within the context window.
  const maxCharacters = Math.floor(Math.max(0, contextSize - budget - 192) * 3);
  if (fixed >= maxCharacters) throw new Error('The selected model context is too small for its personality, question and a 2048-token output segment. Increase its context size or shorten the prompt.');
  const tail = answer.slice(-Math.max(80, maxCharacters - fixed));
  return [...system, recentUser,
    { role: 'assistant', content: tail },
    { role: 'user', content: instruction },
  ];
}

/** Deduplicate a repeated prefix from a restarted streaming response without rewriting previous text. */
export function mayContinuePreviousSuffix(existing: string, incoming: string): boolean {
  const maximum = Math.min(1200, existing.length);
  if (incoming.length > maximum) return false;
  for (let length = maximum; length >= Math.max(8, incoming.length); length--) {
    if (existing.slice(-length).startsWith(incoming)) return true;
  }
  return false;
}

export function overlapLength(existing: string, incoming: string): number {
  const limit = Math.min(1200, existing.length, incoming.length);
  for (let count = limit; count >= 8; count--) {
    if (existing.endsWith(incoming.slice(0, count))) return count;
  }
  return 0;
}

/** The same local server/model remains loaded across requests; no new model is spawned. */
export async function streamContinuousAnswer(options: ContinuousAnswerOptions): Promise<ContinuousAnswerResult> {
  const { adapter, model, capabilities, messages, signal, request, onReasoning, onReasoningState, onMetrics } = options;
  let answer = '';
  let segments = 0;
  let failures = 0;
  let history = messages;
  let lastResult: LlamaTurnResult | undefined;
  while (true) {
    const previousLength = answer.length;
    if (signal.aborted) throw new DOMException('Stopped', 'AbortError');
    const started = performance.now();
    let firstToken: number | null = null;
    let reasoningStarted = false;
    let pending = '';
    let resolvingOverlap = segments > 0;
    const append = (delta: string): void => { if (delta) { answer += delta; options.onAnswer(delta); } };
    // Buffer only a possible repeated suffix. Unrelated continuation text streams immediately.
    const emitAnswer = (delta: string): void => {
      if (firstToken === null) firstToken = performance.now();
      if (reasoningStarted) { onReasoningState?.(false); reasoningStarted = false; }
      if (!resolvingOverlap) { append(delta); return; }
      pending += delta;
      if (mayContinuePreviousSuffix(answer, pending)) return;
      append(pending.slice(overlapLength(answer, pending)));
      pending = '';
      resolvingOverlap = false;
    };
    const result = await adapter.generate(model, history, capabilities, {
      answer: emitAnswer,
      reasoning: (text) => { if (!reasoningStarted) { reasoningStarted = true; onReasoningState?.(true); } onReasoning(text); },
    }, signal, { ...request, outputTokens: OUTPUT_SEGMENT_TOKENS });
    if (reasoningStarted) onReasoningState?.(false);
    if (pending) append(pending.slice(overlapLength(answer, pending)));
    if (result.finishReason === 'content_filter') throw new Error('The inference backend stopped generation due to a content filter.');
    onMetrics?.(generationMetrics(adapter.kind, model.modelId, started, firstToken, performance.now(), result.answer, result.usage?.completionTokens));
    segments++;
    lastResult = result;
    if (result.calls.length || result.finishReason !== 'length') break;
    if (answer.length - previousLength < 8) failures++;
    else failures = 0;
    if (failures >= 2) throw new Error('Generation stopped after repeated empty continuation segments.');
    // vLLM/llama.cpp reuse loaded weights. The server manages a bounded KV cache according to its own context configuration.
    history = continuationMessages(messages, answer, model.contextSize || capabilities.contextSize || 4096);
  }
  if (!lastResult) throw new Error('Inference returned no result.');
  return { answer, result: lastResult, segments };
}
