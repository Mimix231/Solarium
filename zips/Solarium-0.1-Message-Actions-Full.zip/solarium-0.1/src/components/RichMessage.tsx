import { useState } from 'react';
import type { ComponentProps } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import rehypeHighlight from 'rehype-highlight';
import { Box, Button, Chip, Dialog, DialogContent, IconButton, Stack, Tooltip, Typography } from '@mui/material';
import CloseRounded from '@mui/icons-material/CloseRounded';
import ContentCopyRounded from '@mui/icons-material/ContentCopyRounded';
import type { ChatAttachment, ChatSource } from '../domain/types';
import 'katex/dist/katex.min.css';
import 'highlight.js/styles/github-dark.min.css';

/** Markdown is parsed as text, never as HTML. External images are not auto-fetched. */
export function RichMessage({ text, attachments = [], sources = [] }: { text: string; attachments?: ChatAttachment[]; sources?: ChatSource[] }) {
  const [lightbox, setLightbox] = useState<string | null>(null);
  return <div className="rich-message">
    <ReactMarkdown skipHtml remarkPlugins={[remarkGfm, remarkMath]} rehypePlugins={[rehypeKatex, rehypeHighlight]} components={{
      a: ({ href, children }: ComponentProps<'a'>) => {
        if (!href || !/^https?:\/\//i.test(href)) return <span>{children}</span>;
        return <a href={href} target="_blank" rel="noopener noreferrer">{children}</a>;
      },
      img: ({ src, alt }: ComponentProps<'img'>) => <span className="remote-image-link">[Image: {alt || src || 'external resource'} — external images are not loaded automatically]</span>,
      pre: ({ children }: ComponentProps<'pre'>) => <div className="rich-code-shell"><Tooltip title="Copy code block"><IconButton className="copy-code" size="small" aria-label="Copy code block" onClick={() => { const text = flattenText(children); void navigator.clipboard.writeText(text); }}><ContentCopyRounded sx={{ fontSize: 14 }}/></IconButton></Tooltip><pre>{children}</pre></div>,
    }}>{text}</ReactMarkdown>
    {attachments.length > 0 && <div className="message-attachments">{attachments.map((attachment) => <div className="attachment-card" key={attachment.id}>
      {attachment.kind === 'image' && attachment.dataUrl ? <button className="attachment-image" onClick={() => setLightbox(attachment.dataUrl!)}><img src={attachment.dataUrl} alt={attachment.name} loading="lazy" /></button> : <span className="attachment-file-icon">▤</span>}
      <Stack minWidth={0}><Typography fontSize={11} fontWeight={700} noWrap>{attachment.name}</Typography><Typography fontSize={9} color="text.secondary">{attachment.kind} · {(attachment.size / 1024).toFixed(0)} KB</Typography></Stack>
    </div>)}</div>}
    {sources.length > 0 && <Box className="message-sources"><Typography fontSize={10.5} color="text.secondary" fontWeight={750} mb={.8}>Sources read or searched</Typography><Stack direction="row" gap={.6} flexWrap="wrap">{sources.map((s, i) => <Chip key={s.url + i} clickable component="a" href={s.url} target="_blank" rel="noopener noreferrer" size="small" variant="outlined" label={`${i + 1}. ${s.title || s.url}`} title={s.excerpt}/>)}</Stack></Box>}
    <Dialog open={Boolean(lightbox)} onClose={() => setLightbox(null)} maxWidth="xl"><DialogContent sx={{ position: 'relative', p: 1, bgcolor: '#111827' }}><Button onClick={() => setLightbox(null)} sx={{ position: 'absolute', right: 8, top: 8 }}><CloseRounded/></Button>{lightbox && <img src={lightbox} alt="Expanded attachment" className="image-lightbox"/>}</DialogContent></Dialog>
  </div>;
}
function flattenText(value: unknown): string {
  if (typeof value === 'string' || typeof value === 'number') return String(value);
  if (Array.isArray(value)) return value.map(flattenText).join('');
  if (value && typeof value === 'object' && 'props' in value) return flattenText((value as {props: {children?: unknown}}).props.children);
  return '';
}
