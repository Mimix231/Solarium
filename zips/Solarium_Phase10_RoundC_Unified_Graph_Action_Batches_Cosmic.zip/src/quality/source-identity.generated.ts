// Generated from actual source bytes; never hand edited.
export const sourceIdentity={"schemaVersion":1,"sha256":"54c435437056073c86de99e111e87ea05f374f7fef2aa0566ca3108e3345a610","files":596,"commit":"e7dd1eb68147dad936aca83e70a94c2bd3feca11"} as const;
