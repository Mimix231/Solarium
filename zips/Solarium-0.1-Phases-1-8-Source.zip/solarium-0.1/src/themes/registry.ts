import { createTheme } from '@mui/material/styles';
import type { ThemeId } from '../domain/types';
export const themes: { id: ThemeId; title: string; description: string; sample: string; dark: boolean; accent: string }[] = [
  { id: 'obsidian', title: 'Obsidian', description: 'Quiet dark precision', sample: 'linear-gradient(130deg,#131826,#292c3d)', dark: true, accent: '#9c92ef' },
  { id: 'crystal', title: 'Crystal', description: 'Luminous frosted glass', sample: 'linear-gradient(130deg,#eefaff,#dcd7f8)', dark: false, accent: '#697fd2' },
  { id: 'aurora', title: 'Aurora', description: 'Neon atmospheric depth', sample: 'linear-gradient(130deg,#142e41,#483779,#1f5b5c)', dark: true, accent: '#83e4d7' },
  { id: 'material', title: 'Material', description: 'Expressive tonal surfaces', sample: 'linear-gradient(130deg,#e7d8fb,#c5d8fd)', dark: false, accent: '#6b55b8' },
  { id: 'slate', title: 'Slate', description: 'Utility-first workstation', sample: 'linear-gradient(130deg,#262b33,#414950)', dark: true, accent: '#a9c0c9' },
  { id: 'solar', title: 'Solar', description: 'Warm celestial atmosphere', sample: 'linear-gradient(130deg,#101c31,#403020)', dark: true, accent: '#f3bd72' },
];
export function createSolariumTheme(themeId: ThemeId, density: 'ultra' | 'compact' | 'comfortable') {
  const found = themes.find((theme) => theme.id === themeId) ?? themes[0]!;
  const dark = found.dark;
  const compact = density === 'ultra' ? 0.80 : density === 'comfortable' ? 1.2 : 1;
  return createTheme({
    cssVariables: true,
    palette: {
      mode: dark ? 'dark' : 'light',
      primary: { main: found.accent },
      background: { default: dark ? '#111622' : '#f5f6fb', paper: dark ? '#212636' : '#fff' },
      text: { primary: dark ? '#ececf6' : '#1d2435', secondary: dark ? '#a6afc2' : '#657186' },
    },
    typography: {
      fontFamily: 'Inter, ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif',
      fontSize: 13 * compact,
      button: { textTransform: 'none', fontWeight: 600, fontSize: 12 * compact },
      h5: { fontWeight: 750, fontSize: 22 * compact, letterSpacing: '-.6px' },
      h6: { fontWeight: 730, fontSize: 16 * compact },
    },
    shape: { borderRadius: themeId === 'slate' ? 4 : themeId === 'material' ? 22 : 12 },
    components: {
      MuiButton: { defaultProps: { size: 'small', disableElevation: true }, styleOverrides: { root: { minHeight: density === 'ultra' ? 25 : density === 'comfortable' ? 36 : 30, borderRadius: themeId === 'material' ? 100 : 10 } } },
      MuiTextField: { defaultProps: { size: 'small' } },
      MuiIconButton: { defaultProps: { size: 'small' } },
      MuiTooltip: { defaultProps: { arrow: true } },
      MuiPaper: { styleOverrides: { root: { backgroundImage: 'none' } } },
      MuiSlider: { styleOverrides: { thumb: { width: 12, height: 12 } } },
    },
  });
}
