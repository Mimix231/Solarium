export const traitNames = ['curiosity', 'analysis', 'empathy', 'humor', 'sarcasm', 'patience', 'creativity', 'confidence'] as const;
export type Trait = typeof traitNames[number];
export type Traits = Record<Trait, number>;
export type SparkMode = 'conversation' | 'work' | 'research' | 'creative';
export type Expression = 'neutral' | 'curious' | 'happy' | 'focused';
export type AvatarStyle = 'orb' | 'portrait' | 'glyph';
export type AvatarHair = 'wave' | 'short' | 'none';
export type AvatarAccessory = 'none' | 'glasses' | 'halo';
export interface SparkAvatar {
  style: AvatarStyle;
  color: string;
  secondary: string;
  glyph: string;
  image?: string;
  expression: Expression;
  hair: AvatarHair; accessory: AvatarAccessory;
  animate: boolean;
}
export interface ExampleTurn { id: string; user: string; assistant: string }
export interface Spark {
  id: string; name: string; description: string; greeting: string;
  instructions: string; traits: Traits; examples: ExampleTurn[];
  avatar: SparkAvatar; preferredModelId: string | null;
  createdAt: string; updatedAt: string;
}
export interface LocalModel {
  id: string; name: string; endpoint: string; modelId: string;
  ggufPath?: string; contextSize: number; temperature: number;
  maxTokens: number; createdAt: string;
}
export interface ChatMessage { id: string; role: 'user' | 'assistant'; content: string; createdAt: string; sparkId?: string }
export interface ChatSession {
  id: string; title: string; sparkId: string; modelId: string | null;
  mode: SparkMode; createdAt: string; updatedAt: string; messages: ChatMessage[];
}
export interface MemoryItem {
  id: string; text: string; scope: 'global' | 'spark'; sparkId: string | null;
  enabled: boolean; createdAt: string;
}
export type ThemeId = 'crystal' | 'obsidian' | 'aurora' | 'material' | 'slate' | 'solar';
export type Density = 'ultra' | 'compact' | 'comfortable';
export interface Preferences {
  theme: ThemeId; density: Density; reducedMotion: boolean;
  sidebarOpen: boolean; showActivity: boolean;
  toolPermissions: Record<string, 'ask' | 'allow' | 'deny'>;
  llamaExecutable: string; serverPort: number;
}
export interface Workspace {
  schemaVersion: 1;
  sparks: Spark[]; sessions: ChatSession[]; models: LocalModel[];
  memories: MemoryItem[]; preferences: Preferences;
  selectedSparkId: string; activeSessionId: string | null;
}
export type ActivityPhase = 'looking' | 'thinking' | 'browsing' | 'observing' | 'verifying' | 'answering';
export type ActivityEvent = {
  id: string; runId: string; sequence: number; at: string;
  kind: 'phase' | 'reasoning' | 'tool_call' | 'tool_result' | 'error';
  phase?: ActivityPhase; status?: 'started' | 'completed' | 'failed';
  text?: string; tool?: string;
};
export interface Capabilities {
  reasoning: 'observed' | 'unknown';
  tools: 'supported' | 'unknown';
  vision: 'supported' | 'unknown';
  contextSize: number | null;
  source: 'server-properties' | 'unavailable';
}
export const uid = (): string => globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2)}`;
export const now = (): string => new Date().toISOString();
