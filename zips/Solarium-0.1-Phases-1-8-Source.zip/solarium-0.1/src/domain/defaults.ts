import type { Spark, SparkAvatar, Traits, Workspace } from './types';
import { now, uid } from './types';

export const defaultAvatar: SparkAvatar = {
  style: 'portrait', color: '#8d7af2', secondary: '#e0b9b6', glyph: '✦',
  expression: 'curious', hair: 'wave', accessory: 'none', animate: true,
};
export const defaultTraits: Traits = {
  curiosity: 90, analysis: 85, empathy: 65, humor: 50, sarcasm: 20,
  patience: 80, creativity: 75, confidence: 75,
};
export function newSpark(): Spark {
  const timestamp = now();
  return {
    id: uid(), name: 'New Spark', description: 'A personality waiting to be discovered.',
    greeting: 'Hello! What should we explore today?', instructions: '',
    traits: { ...defaultTraits }, examples: [], avatar: { ...defaultAvatar },
    preferredModelId: null, createdAt: timestamp, updatedAt: timestamp,
  };
}
export function defaultWorkspace(): Workspace {
  const explorer = newSpark();
  explorer.name = 'Astra';
  explorer.description = 'A brilliant, endlessly curious research companion.';
  explorer.greeting = 'How intriguing. Tell me what you would like to investigate.';
  explorer.instructions = 'Speak elegantly and clearly, show enthusiasm for discovery, and treat questions as opportunities to explore. State uncertainty plainly. Be practical when work needs doing.';
  const maker = newSpark();
  maker.name = 'Forge';
  maker.description = 'A focused engineering partner who gets things built.';
  maker.greeting = 'Ready when you are. What are we building?';
  maker.avatar = { ...defaultAvatar, style: 'glyph', color: '#5ba99c', secondary: '#9ad8b9', glyph: '⬡' };
  maker.instructions = 'Prioritize correctness, clear steps, executable code, and measurable validation.';
  maker.traits = { ...maker.traits, analysis: 100, humor: 25, patience: 95 };
  return {
    schemaVersion: 1, sparks: [explorer, maker], sessions: [], models: [], memories: [],
    selectedSparkId: explorer.id, activeSessionId: null,
    preferences: {
      theme: 'obsidian', density: 'compact', reducedMotion: false,
      sidebarOpen: true, showActivity: false,
      toolPermissions: { get_current_time: 'ask', calculate: 'ask', search_memories: 'ask' },
      llamaExecutable: '', serverPort: 8080,
    },
  };
}
