import type { ChatMessage, ChatSession, Density, LocalModel, MemoryItem, Preferences, Spark, SparkAvatar, ThemeId, Workspace } from './types';
import { defaultAvatar, defaultTraits, defaultWorkspace, newSpark } from './defaults';
import { now, traitNames, uid } from './types';

const object = (data: unknown): Record<string, unknown> => data && typeof data === 'object' && !Array.isArray(data) ? data as Record<string, unknown> : {};
const text = (data: unknown, max = 20_000): string => typeof data === 'string' ? data.slice(0, max) : '';
const number = (data: unknown, fallback: number, min: number, max: number): number =>
  typeof data === 'number' && Number.isFinite(data) ? Math.min(max, Math.max(min, data)) : fallback;
const option = <T extends string>(data: unknown, allowed: readonly T[], fallback: T): T =>
  typeof data === 'string' && allowed.includes(data as T) ? data as T : fallback;
const hexColor = (data: unknown, fallback: string): string => typeof data === 'string' && /^#[a-f0-9]{6}$/i.test(data) ? data : fallback;

export function validateSpark(data: unknown): Spark {
  const d = object(data);
  if (!text(d.name, 60).trim()) throw new Error('Spark is missing a valid name.');
  const fallback = newSpark();
  const traits = object(d.traits);
  const avatar = object(d.avatar);
  const examples = Array.isArray(d.examples) ? d.examples : [];
  const safeAvatar: SparkAvatar = {
    style: option(avatar.style, ['orb', 'portrait', 'glyph'] as const, defaultAvatar.style),
    color: hexColor(avatar.color, defaultAvatar.color),
    secondary: hexColor(avatar.secondary, defaultAvatar.secondary),
    glyph: text(avatar.glyph, 2) || defaultAvatar.glyph,
    expression: option(avatar.expression, ['neutral', 'curious', 'happy', 'focused'] as const, defaultAvatar.expression),
    hair: option(avatar.hair, ['wave', 'short', 'none'] as const, defaultAvatar.hair),
    accessory: option(avatar.accessory, ['none', 'glasses', 'halo'] as const, defaultAvatar.accessory),
    animate: typeof avatar.animate === 'boolean' ? avatar.animate : defaultAvatar.animate,
    ...(typeof avatar.image === 'string' && avatar.image.length < 2_100_000 && /^data:image\/(?:png|jpeg|webp);base64,[a-z0-9+/=]+$/i.test(avatar.image) ? { image: avatar.image } : {}),
  };
  return {
    id: text(d.id, 100) || fallback.id,
    name: text(d.name, 60).trim(), description: text(d.description, 500),
    greeting: text(d.greeting, 1200) || fallback.greeting,
    instructions: text(d.instructions, 18_000),
    traits: Object.fromEntries(traitNames.map((trait) => [trait, number(traits[trait], defaultTraits[trait], 0, 100)])) as unknown as Spark['traits'],
    avatar: safeAvatar, preferredModelId: text(d.preferredModelId, 100) || null,
    examples: examples.slice(0, 20).map((example: unknown) => object(example)).filter((example) => typeof example.user === 'string' && typeof example.assistant === 'string').map((example) => ({ id: text(example.id, 100) || uid(), user: text(example.user, 2000), assistant: text(example.assistant, 5000) })),
    createdAt: text(d.createdAt, 40) || now(), updatedAt: text(d.updatedAt, 40) || now(),
  };
}

function validateModel(data: unknown): LocalModel | null {
  const m = object(data);
  const endpoint = text(m.endpoint, 200);
  const identifier = text(m.modelId, 255);
  if (!identifier) return null;
  try {
    const url = new URL(endpoint);
    if (url.protocol !== 'http:' || !['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname) || url.username || url.password || url.search || url.hash || !['', '/'].includes(url.pathname)) return null;
    return {
      id: text(m.id, 100) || uid(), name: text(m.name, 100) || identifier,
      endpoint: url.origin, modelId: identifier,
      ...(typeof m.ggufPath === 'string' ? { ggufPath: text(m.ggufPath, 1200) } : {}),
      contextSize: number(m.contextSize, 4096, 256, 262144),
      temperature: number(m.temperature, .7, 0, 2),
      maxTokens: number(m.maxTokens, 2048, 32, 131072),
      createdAt: text(m.createdAt, 40) || now(),
    };
  } catch { return null; }
}

function validateMessage(data: unknown): ChatMessage | null {
  const m = object(data);
  if (m.role !== 'user' && m.role !== 'assistant') return null;
  return {
    id: text(m.id, 100) || uid(), role: m.role,
    content: text(m.content, 80_000), createdAt: text(m.createdAt, 40) || now(),
    ...(typeof m.sparkId === 'string' ? { sparkId: text(m.sparkId, 100) } : {}),
  };
}

function validateSession(data: unknown, sparkIds: Set<string>): ChatSession | null {
  const d = object(data);
  const sparkId = text(d.sparkId, 100);
  if (!sparkIds.has(sparkId)) return null;
  const raw = Array.isArray(d.messages) ? d.messages : [];
  return {
    id: text(d.id, 100) || uid(), sparkId,
    title: text(d.title, 100) || 'Conversation', modelId: text(d.modelId, 100) || null,
    mode: option(d.mode, ['conversation', 'work', 'research', 'creative'] as const, 'conversation'),
    createdAt: text(d.createdAt, 40) || now(), updatedAt: text(d.updatedAt, 40) || now(),
    messages: raw.map(validateMessage).filter((message): message is ChatMessage => message !== null).slice(-2_000),
  };
}

function validateMemory(data: unknown, sparkIds: Set<string>): MemoryItem | null {
  const m = object(data);
  if (!text(m.text, 3000).trim()) return null;
  const sparkId = text(m.sparkId, 100);
  const scope = m.scope === 'spark' ? 'spark' : 'global';
  if (scope === 'spark' && !sparkIds.has(sparkId)) return null;
  return { id: text(m.id, 100) || uid(), text: text(m.text, 3000), scope,
    sparkId: scope === 'global' ? null : sparkId,
    enabled: m.enabled !== false, createdAt: text(m.createdAt, 40) || now() };
}

function validatePreferences(data: unknown): Preferences {
  const p = object(data);
  const fallback = defaultWorkspace().preferences;
  const permissions = object(p.toolPermissions);
  const allowed: Record<string, 'ask' | 'allow' | 'deny'> = { ...fallback.toolPermissions };
  for (const name of Object.keys(allowed)) allowed[name] = option(permissions[name], ['ask', 'allow', 'deny'] as const, 'ask');
  return {
    theme: option<ThemeId>(p.theme, ['crystal','obsidian','aurora','material','slate','solar'], fallback.theme),
    density: option<Density>(p.density, ['ultra','compact','comfortable'], fallback.density),
    reducedMotion: p.reducedMotion === true,
    sidebarOpen: p.sidebarOpen !== false, showActivity: p.showActivity === true,
    llamaExecutable: text(p.llamaExecutable, 1200),
    serverPort: number(p.serverPort, 8080, 1024, 65535),
    toolPermissions: allowed,
  };
}

export function validateWorkspace(data: unknown): Workspace {
  if (!data || typeof data !== 'object' || Array.isArray(data)) throw new Error('Workspace file must be a JSON object.');
  const d = object(data);
  if (d.schemaVersion !== 1 || !Array.isArray(d.sparks) || !Array.isArray(d.sessions) || !Array.isArray(d.models) || !Array.isArray(d.memories)) {
    throw new Error('Unrecognized or incomplete Solarium workspace.');
  }
  const sparks: Spark[] = [];
  const seen = new Set<string>();
  for (const candidate of d.sparks.slice(0, 500)) {
    try {
      const spark = validateSpark(candidate);
      if (!seen.has(spark.id)) { sparks.push(spark); seen.add(spark.id); }
    } catch { /* Skip a malformed imported profile. */ }
  }
  if (!sparks.length) throw new Error('Workspace contains no valid Sparks.');
  const models = d.models.map(validateModel).filter((m): m is LocalModel => m !== null).slice(0, 300);
  const sessions = d.sessions.map((s) => validateSession(s, seen)).filter((s): s is ChatSession => s !== null).slice(0, 50_000);
  const memories = d.memories.map((m) => validateMemory(m, seen)).filter((m): m is MemoryItem => m !== null).slice(0, 10_000);
  const selectedSparkId = seen.has(text(d.selectedSparkId, 100)) ? text(d.selectedSparkId, 100) : sparks[0]!.id;
  const activeSessionId = sessions.find((s) => s.id === d.activeSessionId)?.id ?? null;
  const modelIds = new Set(models.map((m) => m.id));
  for (const spark of sparks) if (spark.preferredModelId && !modelIds.has(spark.preferredModelId)) spark.preferredModelId = null;
  for (const session of sessions) if (session.modelId && !modelIds.has(session.modelId)) session.modelId = null;
  return {
    schemaVersion: 1, sparks, sessions, models, memories,
    preferences: validatePreferences(d.preferences), selectedSparkId, activeSessionId,
  };
}
