import type { MemoryItem, Spark } from '../domain/types';
export const toolDefinitions = [
  { type: 'function', function: { name: 'get_current_time', description: 'Read the computer’s local current date and time.', parameters: { type: 'object', properties: {}, additionalProperties: false } } },
  { type: 'function', function: { name: 'calculate', description: 'Calculate arithmetic using numbers and +, -, *, /, and parentheses.', parameters: { type: 'object', properties: { expression: { type: 'string', description: 'Arithmetic expression.' } }, required: ['expression'], additionalProperties: false } } },
  { type: 'function', function: { name: 'search_memories', description: 'Search user-approved Solarium memories for context.', parameters: { type: 'object', properties: { query: { type: 'string' } }, required: ['query'], additionalProperties: false } } },
] as const;
export const availableToolNames = toolDefinitions.map((t) => t.function.name);

/** No eval, Function constructor, arbitrary process execution, or network side effects. */
export function calculate(expression: string): number {
  if (expression.length > 160) throw new Error('Expression is too long.');
  const tokens = expression.match(/(?:\d+\.\d*|\.\d+|\d+)|[()+*/-]/g) ?? [];
  if (tokens.join('') !== expression.replace(/\s/g, '')) throw new Error('Unsupported arithmetic characters.');
  if (tokens.length > 80) throw new Error('Too many arithmetic terms.');
  let index = 0;
  const peek = () => tokens[index];
  function factor(depth: number): number {
    if (depth > 20) throw new Error('Expression is too nested.');
    const token = tokens[index++];
    if (token === '+' || token === '-') return (token === '-' ? -1 : 1) * factor(depth + 1);
    if (token === '(') {
      const value = sum(depth + 1);
      if (tokens[index++] !== ')') throw new Error('Missing closing parenthesis.');
      return value;
    }
    if (!token || !/^(?:\d+\.?\d*|\.\d+)$/.test(token)) throw new Error('Expected a number.');
    return Number(token);
  }
  function product(depth: number): number {
    let value = factor(depth);
    while (peek() === '*' || peek() === '/') {
      const operator = tokens[index++];
      const right = factor(depth);
      if (operator === '/' && right === 0) throw new Error('Division by zero.');
      value = operator === '*' ? value * right : value / right;
    }
    return value;
  }
  function sum(depth: number): number {
    let value = product(depth);
    while (peek() === '+' || peek() === '-') {
      const operator = tokens[index++];
      const right = product(depth);
      value = operator === '+' ? value + right : value - right;
    }
    return value;
  }
  const result = sum(0);
  if (index !== tokens.length) throw new Error('Unexpected token.');
  if (!Number.isFinite(result)) throw new Error('Result is not finite.');
  return result;
}
export function executeTool(name: string, args: Record<string, unknown>, spark: Spark, memories: MemoryItem[]): string {
  switch (name) {
    case 'get_current_time': return new Date().toLocaleString(undefined, { dateStyle: 'full', timeStyle: 'long' });
    case 'calculate': {
      if (typeof args.expression !== 'string') throw new Error('Missing expression.');
      return String(calculate(args.expression));
    }
    case 'search_memories': {
      if (typeof args.query !== 'string' || !args.query.trim()) throw new Error('Missing search query.');
      const words = args.query.toLowerCase().split(/\s+/).filter(Boolean);
      const matches = memories.filter((m) => m.enabled && (m.scope === 'global' || m.sparkId === spark.id) && words.some((w) => m.text.toLowerCase().includes(w)));
      return JSON.stringify(matches.slice(0, 10).map((m) => m.text));
    }
    default: throw new Error(`Unsupported tool: ${name}`);
  }
}
