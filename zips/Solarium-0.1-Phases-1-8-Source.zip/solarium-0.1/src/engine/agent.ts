import type { ChatSession, LocalModel, MemoryItem, Preferences, Spark } from '../domain/types';
import { composeSparkInstructions } from '../domain/persona';
import { AgentEventEmitter } from './activity';
import { inspectModel, streamLlamaTurn, type LlamaMessage } from './llama';
import { executeTool } from './tools';

export interface AgentOptions {
  spark: Spark; model: LocalModel; session: ChatSession;
  memories: MemoryItem[]; preferences: Preferences;
  events: AgentEventEmitter; signal: AbortSignal;
  onAnswer: (delta: string) => void;
  onApproval: (name: string, args: Record<string, unknown>) => Promise<'allow' | 'deny'>;
}
export async function runAgent(options: AgentOptions): Promise<string> {
  const { spark, model, session, memories, preferences, events, signal, onAnswer, onApproval } = options;
  events.phase('looking', 'started', 'Checking the local model and composing context.');
  const { ids, capabilities } = await inspectModel(model, signal);
  if (ids.length && !ids.includes(model.modelId)) throw new Error(`Model "${model.modelId}" is not loaded. Loaded: ${ids.join(', ')}`);
  const messages: LlamaMessage[] = [
    { role: 'system', content: composeSparkInstructions(spark, session.mode, memories) },
    ...session.messages.slice(-40).map((m): LlamaMessage => ({ role: m.role, content: m.content })),
  ];
  events.phase('looking', 'completed', `Connected to ${model.modelId}.`);
  let answer = '';
  for (let turn = 0; turn < 5; turn++) {
    if (signal.aborted) throw new DOMException('Cancelled', 'AbortError');
    events.phase('thinking', 'started', `Generating model turn ${turn + 1}.`);
    let reasoningObserved = false;
    const result = await streamLlamaTurn(model, messages, capabilities, {
      answer: (delta) => { answer += delta; onAnswer(delta); },
      reasoning: (delta) => { reasoningObserved = true; events.emit('reasoning', delta); },
    }, signal);
    events.phase('thinking', 'completed', reasoningObserved ? 'Native reasoning text received.' : 'Model turn completed (no reasoning channel observed).');
    if (!result.calls.length) {
      events.phase('verifying', 'started', 'Checking generated output.');
      if (!answer.trim()) {
        events.phase('verifying', 'failed', 'The model returned no answer.');
        throw new Error('Model returned an empty answer. Check its chat template and settings.');
      }
      events.phase('verifying', 'completed', 'Non-empty answer received. This is not a factual verification.');
      events.phase('answering', 'completed', 'Response completed.');
      return answer;
    }
    messages.push({ role: 'assistant', content: result.answer, tool_calls: result.calls });
    for (const call of result.calls) {
      if (signal.aborted) throw new DOMException('Cancelled', 'AbortError');
      let args: Record<string, unknown>;
      try { const parsed: unknown = JSON.parse(call.function.arguments || '{}'); if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error('Tool arguments must be an object.'); args = parsed as Record<string, unknown>; }
      catch { args = {}; }
      events.emit('tool_call', JSON.stringify(args), { tool: call.function.name });
      const rule = preferences.toolPermissions[call.function.name] ?? 'deny';
      const decision = rule === 'ask' ? await onApproval(call.function.name, args) : rule === 'allow' ? 'allow' : 'deny';
      const output = decision === 'deny' ? 'User denied permission for this tool.' : (() => {
        try { return executeTool(call.function.name, args, spark, memories); }
        catch (error) { return `Tool error: ${String(error)}`; }
      })();
      events.emit('tool_result', output.slice(0, 800), { tool: call.function.name });
      messages.push({ role: 'tool', tool_call_id: call.id, content: output });
    }
    events.phase('observing', 'completed', 'Tool responses delivered to the model.');
  }
  if (answer.trim()) return answer;
  throw new Error('Maximum tool iterations reached without a final answer.');
}
