const isDesktop = (): boolean => typeof window !== 'undefined' && '__TAURI_INTERNALS__' in window;
export async function chooseFile(filters: { name: string; extensions: string[] }[] = []): Promise<string | null> {
  if (!isDesktop()) throw new Error('Native file browsing is available in the desktop app only.');
  const { open } = await import('@tauri-apps/plugin-dialog');
  const result = await open({ multiple: false, directory: false, ...(filters.length ? { filters } : {}) });
  return typeof result === 'string' ? result : null;
}
export async function startLlamaServer(executable: string, gguf: string, port: number, context: number): Promise<string> {
  if (!isDesktop()) throw new Error('Start/stop commands require the desktop app.');
  const { invoke } = await import('@tauri-apps/api/core');
  return invoke<string>('start_llama_server', { executable, gguf, port, context });
}
export async function stopLlamaServer(): Promise<string> {
  if (!isDesktop()) throw new Error('Start/stop commands require the desktop app.');
  const { invoke } = await import('@tauri-apps/api/core');
  return invoke<string>('stop_llama_server');
}
