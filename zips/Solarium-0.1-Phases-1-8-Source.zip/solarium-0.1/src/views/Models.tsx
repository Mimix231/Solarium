import { useShallow } from 'zustand/react/shallow';
import { useState } from 'react';
import { Alert, Box, Button, Chip, IconButton, Stack, TextField, Typography, Tooltip } from '@mui/material';
import AddRounded from '@mui/icons-material/AddRounded';
import FolderOpenRounded from '@mui/icons-material/FolderOpenRounded';
import PlayArrowRounded from '@mui/icons-material/PlayArrowRounded';
import StopRounded from '@mui/icons-material/StopRounded';
import DeleteOutlineRounded from '@mui/icons-material/DeleteOutlineRounded';
import RefreshRounded from '@mui/icons-material/RefreshRounded';
import { SectionTitle } from '../components/SectionTitle';
import { useSolarium } from '../state/useSolarium';
import { inspectModel } from '../engine/llama';
import { chooseFile, startLlamaServer, stopLlamaServer } from '../engine/desktop';
import { now, uid, type Capabilities, type LocalModel } from '../domain/types';
export function Models() {
  const { workspace, upsertModel, removeModel, updatePreferences } = useSolarium(useShallow((state) => ({ workspace: state.workspace, upsertModel: state.upsertModel, removeModel: state.removeModel, updatePreferences: state.updatePreferences })));
  const [name, setName] = useState('Local model');
  const [endpoint, setEndpoint] = useState('http://127.0.0.1:8080');
  const [modelId, setModelId] = useState('');
  const [ggufPath, setGgufPath] = useState('');
  const [contextSize, setContextSize] = useState(4096);
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const [checks, setChecks] = useState<Record<string, { ids: string[]; capabilities: Capabilities }>>({});
  const [failure, setFailure] = useState(false);
  async function check(model: LocalModel) {
    setBusy(true);
    try {
      const result = await inspectModel(model);
      setChecks((prev) => ({ ...prev, [model.id]: result }));
      setFailure(false); setMessage(`Connected to ${model.name}; ${result.ids.length} model(s) loaded.`);
    } catch (error) { setFailure(true); setMessage(`Connection failed: ${String(error)}`); }
    finally { setBusy(false); }
  }
  async function runStart() {
    setBusy(true);
    try {
      setMessage(await startLlamaServer(workspace.preferences.llamaExecutable, ggufPath, workspace.preferences.serverPort, contextSize));
      setFailure(false);
    } catch (error) { setFailure(true); setMessage(String(error)); }
    finally { setBusy(false); }
  }
  async function runStop() {
    setBusy(true);
    try { setMessage(await stopLlamaServer()); setFailure(false); }
    catch (error) { setFailure(true); setMessage(String(error)); }
    finally { setBusy(false); }
  }
  return <Box className="view-scroll page-padding">
    <SectionTitle eyebrow="COMPUTE ON YOUR DEVICE" title="Local Models" description="Connect to llama.cpp, inspect capabilities, and bind models to your Sparks." />
    {message && <Alert severity={failure ? 'warning' : 'success'} onClose={() => setMessage('')} sx={{ mb: 2, maxWidth: 850 }}>{message}</Alert>}
    <Box className="glass panel" sx={{ maxWidth: 850, mb: 2 }}>
      <Stack direction="row" justifyContent="space-between" alignItems="center"><Typography fontWeight={750} fontSize={13}>Configured endpoints</Typography><Chip label={`${workspace.models.length} registered`} size="small" /></Stack>
      <Stack gap={1.1} mt={2}>{workspace.models.map((model) => <Box key={model.id} className="model-row">
        <Box flex={1} minWidth={0}><Typography fontSize={13} fontWeight={700}>{model.name}</Typography><Typography fontSize={11} color="text.secondary" sx={{ overflowWrap: 'anywhere' }}>{model.modelId} · {model.endpoint}</Typography>
          <Stack direction="row" gap={1} mt={1.1} flexWrap="wrap">
            <TextField label="Temperature" type="number" size="small" value={model.temperature} onChange={(e) => {
              const value = Number(e.target.value);
              if (Number.isFinite(value) && value >= 0 && value <= 2) upsertModel({ ...model, temperature: value });
            }} inputProps={{ min: 0, max: 2, step: 0.05 }} sx={{ width: 110 }} />
            <TextField label="Max tokens" type="number" size="small" value={model.maxTokens} onChange={(e) => {
              const value = Number(e.target.value);
              if (Number.isInteger(value) && value >= 32 && value <= 131072) upsertModel({ ...model, maxTokens: value });
            }} inputProps={{ min: 32, max: 131072, step: 32 }} sx={{ width: 125 }} />
          </Stack>
          {checks[model.id] && <Stack direction="row" gap={.65} mt={.7} flexWrap="wrap"><Chip label={`Context ${checks[model.id]?.capabilities.contextSize ?? '?'}`} size="small" /><Chip label={`Tools ${checks[model.id]?.capabilities.tools}`} size="small" /><Chip label={`Vision ${checks[model.id]?.capabilities.vision}`} size="small" /><Chip label={`Reasoning ${checks[model.id]?.capabilities.reasoning}`} size="small" /></Stack>}
        </Box><Tooltip title="Check server"><span><IconButton disabled={busy} aria-label={`Inspect ${model.name}`} onClick={() => void check(model)}><RefreshRounded fontSize="small" /></IconButton></span></Tooltip><IconButton aria-label={`Remove ${model.name}`} onClick={() => removeModel(model.id)}><DeleteOutlineRounded fontSize="small" /></IconButton>
      </Box>)}
        {!workspace.models.length && <Typography color="text.secondary" fontSize={12}>No models registered. Connect an existing local inference server below.</Typography>}
      </Stack>
      <Typography fontWeight={750} fontSize={13} mt={3} mb={1.3}>Register a model</Typography>
      <div className="model-form"><TextField fullWidth label="Display name" value={name} onChange={(e) => setName(e.target.value)} /><TextField fullWidth label="Model ID from /v1/models" placeholder="e.g. local-model" value={modelId} onChange={(e) => setModelId(e.target.value)} /><TextField fullWidth label="Server URL (loopback only)" value={endpoint} onChange={(e) => setEndpoint(e.target.value)} /><TextField fullWidth label="Context tokens" type="number" value={contextSize} onChange={(e) => setContextSize(Number(e.target.value))} /></div>
      <Stack direction="row" gap={1} mt={1.5} flexWrap="wrap"><Button startIcon={<AddRounded />} variant="contained" disabled={!name.trim() || !modelId.trim() || contextSize < 256} onClick={() => {
        try {
          const url = new URL(endpoint);
          if (url.protocol !== 'http:' || !['localhost', '127.0.0.1', '[::1]'].includes(url.hostname)) throw new Error('Only localhost servers are supported.');
          upsertModel({ id: uid(), name: name.trim(), endpoint: url.origin, modelId: modelId.trim(), contextSize, temperature: .7, maxTokens: 2048, createdAt: now(), ...(ggufPath ? { ggufPath } : {}) });
          setMessage('Model registered. Inspect it to verify connectivity.'); setFailure(false);
        } catch (error) { setFailure(true); setMessage(String(error)); }
      }}>Register</Button><Button variant="outlined" disabled={busy} onClick={() => void (async () => {
        const temporary: LocalModel = { id: '_preview', name, endpoint, modelId, contextSize, temperature: .7, maxTokens: 2048, createdAt: now() };
        try { const info = await inspectModel(temporary); setModelId(info.ids[0] ?? modelId); setMessage(`Discovered: ${info.ids.join(', ') || '(no models)'}`); setFailure(false); }
        catch (error) { setFailure(true); setMessage(String(error)); }
      })()}>Discover loaded model</Button></Stack>
    </Box>
    <Box className="glass panel" sx={{ maxWidth: 850 }}>
      <Typography fontWeight={750} fontSize={13} mb={1}>Launch llama.cpp (desktop)</Typography>
      <Typography fontSize={12} color="text.secondary" mb={2}>Point to your installed llama-server executable and a GGUF model. Solarium starts a loopback-only child process; inference stays local.</Typography>
      <Stack gap={1.3}>
        <Stack direction="row" gap={1}><TextField fullWidth label="llama-server executable path" value={workspace.preferences.llamaExecutable} onChange={(e) => updatePreferences({ llamaExecutable: e.target.value })} /><Button startIcon={<FolderOpenRounded />} onClick={() => void chooseFile().then((value) => { if (value) updatePreferences({ llamaExecutable: value }); }).catch((error: unknown) => { setFailure(true); setMessage(String(error)); })}>Browse</Button></Stack>
        <Stack direction="row" gap={1}><TextField fullWidth label="GGUF model path" value={ggufPath} onChange={(e) => setGgufPath(e.target.value)} /><Button startIcon={<FolderOpenRounded />} onClick={() => void chooseFile([{ name: 'GGUF models', extensions: ['gguf'] }]).then((value) => { if (value) setGgufPath(value); }).catch((error: unknown) => { setFailure(true); setMessage(String(error)); })}>Browse</Button></Stack>
        <Stack direction="row" gap={1}><TextField label="Local port" type="number" value={workspace.preferences.serverPort} onChange={(e) => updatePreferences({ serverPort: Number(e.target.value) })} sx={{ width: 130 }} /><Button variant="contained" startIcon={<PlayArrowRounded />} disabled={busy || !ggufPath || !workspace.preferences.llamaExecutable} onClick={() => void runStart()}>Start server</Button><Button variant="outlined" startIcon={<StopRounded />} disabled={busy} onClick={() => void runStop()}>Stop</Button></Stack>
      </Stack>
    </Box>
  </Box>;
}
