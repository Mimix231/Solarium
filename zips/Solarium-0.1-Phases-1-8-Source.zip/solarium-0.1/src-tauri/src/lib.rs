use std::path::Path;
use std::process::{Child, Command, Stdio};
use std::sync::Mutex;
use tauri::State;

#[derive(Default)]
struct LocalServer(Mutex<Option<Child>>);

impl Drop for LocalServer {
    fn drop(&mut self) {
        if let Ok(mut guard) = self.0.lock() {
            if let Some(mut process) = guard.take() {
                let _ = process.kill();
                let _ = process.wait();
            }
        }
    }
}

#[tauri::command]
fn start_llama_server(
    state: State<'_, LocalServer>,
    executable: String,
    gguf: String,
    port: u16,
    context: u32,
) -> Result<String, String> {
    let path = Path::new(&executable);
    let model = Path::new(&gguf);
    if !path.is_file() {
        return Err("llama-server executable does not exist.".into());
    }
    if !model.is_file() || !model.extension().and_then(|x| x.to_str()).is_some_and(|x| x.eq_ignore_ascii_case("gguf")) {
        return Err("Select an existing GGUF model file.".into());
    }
    let filename = path.file_stem().and_then(|s| s.to_str()).unwrap_or("").to_lowercase();
    if !filename.contains("llama-server") {
        return Err("For safety, only an executable named llama-server may be launched.".into());
    }
    if port < 1024 || context < 256 || context > 262_144 {
        return Err("Invalid port or context length.".into());
    }
    let mut child = state.0.lock().map_err(|_| "Server lock unavailable")?;
    if let Some(process) = child.as_mut() {
        if process.try_wait().map_err(|e| e.to_string())?.is_none() {
            return Err("A Solarium-managed llama-server is already running.".into());
        }
    }
    let process = Command::new(path)
        .args(["-m", &gguf, "--host", "127.0.0.1", "--port", &port.to_string(), "-c", &context.to_string(), "--no-webui"])
        .stdin(Stdio::null()).stdout(Stdio::null()).stderr(Stdio::null())
        .spawn().map_err(|e| e.to_string())?;
    let pid = process.id();
    *child = Some(process);
    Ok(format!("Started local llama-server (PID {pid}) on 127.0.0.1:{port}. It may need a moment to load the model."))
}

#[tauri::command]
fn stop_llama_server(state: State<'_, LocalServer>) -> Result<String, String> {
    let mut guard = state.0.lock().map_err(|_| "Server lock unavailable")?;
    match guard.take() {
        Some(mut process) => {
            process.kill().map_err(|e| e.to_string())?;
            let _ = process.wait();
            Ok("Stopped the Solarium-managed llama-server.".into())
        }
        None => Err("No Solarium-managed llama-server is running.".into()),
    }
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .manage(LocalServer::default())
        .plugin(tauri_plugin_sql::Builder::default().build())
        .plugin(tauri_plugin_dialog::init())
        .invoke_handler(tauri::generate_handler![start_llama_server, stop_llama_server])
        .run(tauri::generate_context!())
        .expect("failed to initialize Solarium");
}
