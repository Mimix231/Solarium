# Solarium 0.1

**Local AI, personal identities.** Solarium is an open-source Tauri 2 desktop application for chatting with local llama.cpp models through customizable AI personalities called **Sparks**. The interface uses React, TypeScript, Material UI, and six distinct CSS themes.

## Getting started

Prerequisites: Node.js 22+, npm, and a locally installed `llama-server` from llama.cpp. For **desktop** builds, install a recent Rust toolchain, platform development dependencies, and the Tauri 2 prerequisites (on Windows: WebView2 and Microsoft C++ Build Tools).

```bash
npm install
npm run dev
```

To open the desktop version (requires Rust and platform prerequisites):

```bash
npm run desktop:dev
```

To create a desktop installer:

```bash
npm run desktop:build
```

### Connect a local LLM

Solarium **does not download models** and **does not bundle llama.cpp binaries or GGUF weights**. Supply your own GGUF and `llama-server`.

If you already have a server, start it separately (example):

```powershell
llama-server.exe -m "C:\Models\YourModel.gguf" --host 127.0.0.1 --port 8080 -c 4096
```

In the **Models** workspace, choose **Discover loaded model**, then register the server's model ID and URL. The app only permits loopback inference addresses, never remote model servers. If running the **Tauri desktop build**, you can alternatively select the installed `llama-server` binary and GGUF file and press **Start server**; afterward discover and register the model. Starting a model process can take time, particularly with large GGUF files.

In **Sparks**, select your personality and optionally associate a preferred model. In **Chat**, start a conversation. Model compatibility depends on the actual GGUF, chat template, and server flags; not all GGUF models support native tool calls, reasoning, or vision.

## Included subsystems

| Phase | Included in 0.1 |
| --- | --- |
| 1. Design system | Compact 3-column layout, MUI theme tokens, six separate themes (`crystal`, `obsidian`, `aurora`, `material`, `slate`, `solar`), density settings, optional motion reduction. |
| 2. Spark Studio | Spark CRUD, traits, behavioral examples, instructions, preferred models, per-Spark import and export, avatar assignment. |
| 3. Local models | Loopback llama.cpp connection, `/v1/models`, `/props`, SSE streaming, best-effort capability inspection, local model process start/stop on Tauri, sampling controls. |
| 4. Conversations | Multi-chat history and search, explicit Spark and model selection, persisted messages, four interaction modes, stop generation. |
| 5. Memory | Local, user-approved, editable memory library with per-Spark scope and enabled/disabled toggles. **No automatic extraction.** |
| 6. Activity and tools | Ordered event emitter, actual SSE reasoning parsing and tool records, permissions and one-time approval dialog, built-in time/calculator/memory-search tools. |
| 7. Avatars | Portrait, orb, and glyph styles; color and expression controls, hair/accessory layers, image import, opt-in lightweight CSS animation. |
| 8. Optimization / QA | Selective Zustand subscriptions, activity-event coalescing, reduced-motion CSS, strict TypeScript settings, modular engines, unit and mock-stream integration tests. |

These are **initial implementations**, not claims of feature parity with mature editors, professional avatar builders, or fully autonomous agents. This release does not include face tracking, generated avatar images, full web-browsing tools, auto-installer downloads, or robust hardware-based inference benchmarking.

## Testing

```bash
npm test          # TypeScript syntax and core TS compile; eleven tests, including mocked LLM SSE and tool flow
npm run check     # Full frontend TypeScript types (requires npm install)
npm run lint      # ESLint (requires npm install)
npm run build     # Frontend production build (requires npm install)
npm run desktop:build # Native platform build (requires Rust, cargo, and platform toolchain)
```

**Validation limitation of this package's authoring environment:** the environment did not have network access to npm or a Rust/Cargo compiler. The core TypeScript compilation, mock-stream integration tests, and source syntax validation were run; **frontend production compilation, ESLint against installed libraries, real llama.cpp inference, and the native Tauri build could not be executed**. After `npm install`, run the remaining checks locally before treating the release as production-ready.

## Architecture

```text
src/
  components/      MUI window shell, theme picker, avatar SVG renderer
  views/           Chat, Spark Studio, model manager, memory library, settings
  domain/          Strongly typed profiles, prompts, validations and defaults
  engine/          llama.cpp SSE transport, reasoning splitter, tools, agent loop, capabilities
  data/            SQLite (Tauri) / localStorage (browser preview) workspace persistence
  state/           Zustand store, actions, debounced serialized storage writes
  themes/          One theme CSS file per design language, plus shared layout CSS
src-tauri/
  src/lib.rs       Native llama-server process lifecycle and Tauri plugins
  capabilities/   Least required desktop dialog and SQL permissions
```

### Security and privacy

- Desktop application uses SQLite in its app data directory. Browser development uses origin-local `localStorage`. Imported images are embedded as data URLs in that local workspace; maximum input size 1.5 MB.
- Model requests only go to `http://localhost`, `http://127.0.0.1`, or `http://[::1]`. No cloud API is configured. Tool permissions default to **ask**; unrecognized tools default to **deny**.
- No automatic memory creation or uploading conversations. Users approve shared/global and private Spark memories explicitly.
- The model's generated reasoning is shown **only if emitted through actual native reasoning fields or a `<think>` tag**. Status messages do not pretend to be hidden model reasoning.
- Imported workspaces/Sparks should be treated as untrusted data; review behavioral instructions before using them with a model. JSON data is not executed as code.

### Developer notes

- `composeSparkInstructions()` in `src/domain/persona.ts` assembles identity, mode, traits, explicit examples and memory context separately from inference capability detection.
- `streamLlamaTurn()` in `src/engine/llama.ts` handles incremental SSE and reasoning/tool-call deltas; `runAgent()` in `src/engine/agent.ts` executes supported tools with permission mediation.
- `AgentEventEmitter` in `src/engine/activity.ts` is the **sole source** of ordered run events. The UI does not create a separate synthetic activity projector.
- The `workspace` database currently stores one validated, versioned JSON snapshot per workspace to keep version 0.1 migrations small; a future schema should normalize large messages and attachments into separate tables.
- Large local model inference will use substantially more memory and CPU/GPU than the interface. Animation is cosmetic and is reduced with the corresponding preference or OS setting.

## License

MIT. Solarium is free software; models used with Solarium may have their own separate licenses.
