# Solarium development rules

**MANDATORY FIRST READ for inference, agent, tools, model context, and runtime edits:**
[`docs/info/INFERENCE_ARCHITECTURE.md`](docs/info/INFERENCE_ARCHITECTURE.md)

The documented single-stream reasoning/answer path, model-memory reuse, input-vs-output distinction, and staged project-tool registration are compatibility requirements. Do not add 2,048-token HTTP generation loops, extra reasoning quotas, synthetic continuation chats, or tool-schema blockers that prevent an existing project from being edited. Do not alter the inference architecture without a focused regression test and a corresponding update to the architecture contract.

Keep Spark personas, real filesystem verification, Ask/Auto/YOLO permissions, project-folder scoping, and Web Search OFF behavior intact. Every claimed filesystem or terminal success requires an actual executed result. Run and report available tests; distinguish skipped checks from successful ones.

**Read for Sources, task execution, project tools, storage and imports:** [Sources and Action Architecture](docs/info/SOURCE_AND_ACTION_ARCHITECTURE.md). Preserve scoped originals, per-command verification, actual output logs and durable task recovery. Failed checks remain work to repair; a different pass is not overall completion.

**Read for authoring, long chapters, characters, canon and web research:** [Writing, Canon and Research Architecture](docs/info/WRITING_CANON_RESEARCH_ARCHITECTURE.md). Preserve stable rich documents/revisions, explicit length targets, planned scene boundaries, per-field evidence and locked AU facts. Characters never become the Spark persona. A finished fence or model EOS alone is not proof that a requested chapter length was reached.

## SPICA unified block warehouse and nonterminal tool diagnostics (2026-11-12)

All canonical block implementations now reside in `src/spica/runtime/blocks/<category>/`:
legacy schema-1 descriptions under `<category>/<subcategory>/` and executable V2 nodes under
`<category>/runtime/<subcategory>/`. `src/spica/runtime` contains the engine **and its sole block source tree**; there is no competing `src/spica/blocks` directory. Regenerate the two checked manifests with
`npm run spica:registry` and `npm run spica:runtime:registry`.

A rejected SPICA tool inspection or malformed call remains a failed operation in the work log,
but must not terminate the overall user task. Deliver its exact diagnostic to the model and
advertise the appropriate registered inspector on the next inference turn; the Spark must
explicitly call it. No hidden retry, guessed arguments, aliasing, or permission bypass is allowed.
User-denied permission still blocks the unauthorized action. Verify the phase regressions and
`tests/spica-block-unification.test.cjs` after changes to any of these contracts.

## SPICA Phase 09 export and tool-sequencing requirements (2026-11-12)

The canonical block sources are `src/spica/runtime/blocks/`. Run `npm run spica:blocks:cleanup:check`; the cleanup command refuses to delete unique or divergent sources. See `spica/roadmap/23_PHASE09_IMPLEMENTATION_REPORT.md`. Browser and desktop emitters must validate actual target compatibility and artifact evidence. Unsupported authored V2 graphs must not be silently exported as schema-1 apps. `spica_next_action` reports exact graph/tool prerequisites; repeated invalid calls must not become fake progress or cause a hidden retry.

## SPICA stale runtime source handling (2026-11-12)

When a Phase 09 archive is extracted onto a previous phase, obsolete executable block
files can survive at `src/spica/runtime/blocks/<category>/<subcategory>/*.ts` while
the canonical copy exists at `<category>/runtime/<subcategory>/*.ts`. Before
`npm run dev`, `npm run build`, or `npm run check`, the `spica:runtime:cleanup`
script checks those sources and removes *only* duplicates whose executable AST and
resolved import targets match. It does not rewrite or delete divergent or
unique files. The schema-1 registry rejects misplaced `defineRuntimeBlock` sources
with a specific remediation message. Verify with
`npm run spica:runtime:cleanup:check`, both registry checks, and
`node --test tests/spica-stale-runtime-cleanup.test.cjs`.

## SPICA Phase 09 flat-block startup fix (2026-11-12)

The startup cleanup now scans **direct** category files as well as nested old
V2 paths, using canonical block IDs and resolved-import-aware AST comparison.
This covers old `data-records/save-note.ts` and all Phase 04–08 layouts when
an archive is extracted on top of an existing working tree. Unique/divergent
sources are never deleted. Verify with the eight
`tests/spica-stale-runtime-cleanup.test.cjs` tests and both registry checks.
See `spica/roadmap/25_PHASE09_FLAT_BLOCK_STARTUP_FIX.md`.

## Phase 09 Tool Contract Intelligence checkpoint (2026-11-12)

Model-facing tool declarations, SPICA inspection, preflight and the final executor
must validate against the *same* registered schema through
`src/engine/intelligence/tool-contract-intelligence.ts`. Do not introduce
shadow argument contracts, feature-specific build shortcuts, hidden retries,
or a second inference stream. `inspect_spica_tool.arguments` means read-only
candidate validation and never invokes the named tool. Repeated invalid calls
and redundant identical reads are not progress; retain errors until a real
contract inspection or verified project-state change. Consult
`spica/roadmap/26_PHASE09_TOOL_CONTRACT_INTELLIGENCE.md` and run
`npm run test:spica:contracts` along with all existing phase suites.

## Phase 10 persistent SPICA task/checkpoint contract (2026-11-13)

For SPICA development instructions, `SpicaTaskOrchestrator` owns a versioned plan in the existing `task_execution` record. Only real graph revisions and current verified build results complete construction/verification stages. The model finishing a response does not complete an unfinished application task; preserve a resumable paused state, including the original goal and diagnostic. Ask/Auto/YOLO permissions and explicit user Stop/Cancel remain authoritative. Never silently replay a saved graph edit or auto-select a substitute tool.

`AgentBudgetScheduler` manages a soft prompt-working target (default 4,096) **between natural tool turns**; `streamContinuousAnswer()` still calls a single backend generation stream per turn. Do not create another LLM context-shift loop, fake Continue message, second model load, or truncated tool contract. Mandatory prompt/tools may borrow the actual context capacity above the configured target. Keep `docs/info/INFERENCE_ARCHITECTURE.md` consistent with any change.

`list_spica_toolchain` accepts `query`, `stage`, `offset`, `limit`, `includeSchemas`; its response is derived from the exact registered executable contracts, and any optional argument must have a real, tested effect. All executable blocks remain one file per block under `src/spica/runtime/blocks/`. Run `npm run test:spica:phase10` and earlier phase suites after changes. A complete target-platform/GGUF acceptance test is necessary before claiming Phase 10 release readiness.

## Phase 10 canonical graph-editor correction (2026-11-13)

There is exactly one Spark-facing graph editor, `edit_spica_graph`. It handles
schema-1 and V2 through the `view` discriminator; **do not restore**
`edit_spica_v2_graph` as a tool or alias. V2 runtime nodes must retain exact
registered ports and valid `validateConfig` data during preflight and durable
storage. The Graph V2 migration-origin check is required in the preflight,
dry-run and save paths; no mismatched schema-1 origin may be committed. The
unreferenced old `agent-build.ts` direct starter fallback was removed. Keep
`src/spica/runtime/blocks/` the only block implementation root. See
`spica/roadmap/43_PHASE10_SINGLE_GRAPH_EDITOR_CORRECTION.md` and run the Phase
03/95/10 suites and both registry checks before delivery.

## Phase 10 registered capability and composer-plan correction (2026-11-13)

For error-prone small GGUF Sparks, preserve exact tool names while exposing natural-language capability queries that return actual registered block IDs, ports and configs. `resolve_spica_capabilities` is read-only; do not silently alias hallucinated block IDs or bypass authorization. `inspect_spica_runtime_block`, `inspect_spica_wiring`, `inspect_spica_tool`, and `inspect_solarium_tool` accept their documented discovery/inspection parameters. The Compose stage must prioritize real validation over repeated generic inspection; Plan discovery requires a real registered block ID. Record-list/delete adapters stay one source file each in `src/spica/runtime/blocks/`, behind permissioned transactional storage. The folded plan is centered directly above the chat input; the expanded plan remains above composer controls. Run `npm run test:spica:phase10:reliability` and all prior phase suites; see `spica/roadmap/44_PHASE10_REGISTERED_CAPABILITIES_AND_COLLAPSIBLE_PLAN.md`.


## Phase 10 scoped aliases and interactive event runtime (2026-11-13)

User-approved source-controlled aliases in `src/spica/runtime/aliases.ts` resolve
**only known runtime block identifiers** to tested canonical implementations.
They are never new callable tools, never synthetic block implementations, and
never guesses substituted for unknown identifiers. Canonicalize all authored
block locks, keep one block source file per implementation, and reject aliases
pointing to missing/duplicate blocks. The `SpicaRuntimeBlockContext.interaction`
bridge is scoped to explicitly delivered string UI events and transactional
session text; it never grants database access or runs arbitrary JavaScript.
Unconditional storage effects must not run in an automatic preview. Only
previously authorized `records.read` / `records.write` transactions may access
real storage. The previous Phase 9 'no aliasing' rule refers to hidden fallbacks;
these reviewed and documented runtime-only aliases are an explicit user-requested
exception, not a general alias fallback. Test the Notes Organizer end-to-end
Save/Reopen path and all phase suites before delivering changes.

## SPICA Phase 10 Round A execution reliability (2026-11-13)

`spicaScopedEditParameters()` must not throw on unverified model-proposed
operation names. Validate through `verifiedSpicaEditScope()` and do not promote
`inspect_params` / tool-inspector responses into `spicaEditScope` unless the
actual operation is registered for the chosen graph view. Failed preflights
must return compact required/accepted keys plus the selected operation schema,
not the entire 25-variant graph editor union. A stalled tool is **not** hidden
by its name: corrected arguments remain callable subject to exact validation,
preflight, permissions and revision checks. The work log and plan count only
persisted, advancing graph revisions as implemented changes. No hardcoded
Dona-specific agent routing.

Run `node scripts/audit-spica-phase10-roundA.cjs`, the Phase 01–10 suites,
`npm run test:spica:contracts` and the registry checks. See
`spica/roadmap/47_PHASE10_ROUND_A_EXECUTION_AUDIT_AND_FIXES.md`. Round B Thought
Blocks are a separate, unimplemented round; keep the native inference stream
contract intact.

## SPICA Phase 10 Round B independent thoughts and inspector view (2026-11-14)

`SparkThoughtJournal` is the authoritative action-level journal held inside the
existing `SpicaTaskPlan` in `task_execution`. Each record is persisted before
native inference, then after the model has emitted its proposed tool calls and
**before** any tool executes, then after actual tool results and settlement.
If persistence fails, do not execute the uncheckpointed operation. Keep actual
model reasoning archived locally, never synthesize hidden reasoning. Use one
natural generation stream per Thought Block; do not split mid-reasoning at a
token quota or issue synthetic Continue prompts. The next thought sees saved
verified evidence, not the previous reasoning transcript. Interrupted thoughts
are paused; pending tool calls must never replay automatically on Resume.

`inspect_spica_tool` and `inspect_solarium_tool` share explicit `view` schemas
and `resolveInspectorView()`: string format, documented structured format or a
bounded array. Neither guesses unsupported values or uses a V2-named duplicate
editor. Run `npm run test:spica:phase10:roundB`, all existing phase suites,
registry checks, and frontend checks where dependencies are installed. See
`spica/roadmap/48_PHASE10_ROUND_B_INDEPENDENT_THOUGHT_BLOCKS.md`.

## Phase 10 Round C construction interfaces

- Use `edit_spica_graph` as the canonical atomic graph editor (`revision` + `edits`, or supported `edit_type` shorthand). Never reintroduce `edit_spica_v2_graph`.
- Migrate through `edit_spica_graph({revision,view:'v2',edits:[{op:'migrate_graph'}]})`; use `compose_blocks` to install a validated set of real blocks. The older `*_v2_graph` functions are retained only for compatibility, not primary model guidance.
- `run_spica_graph({revision,view:'v2'})` executes current registered runtime blocks; a passed adapter run is not standalone export evidence.
- Action batches checkpoint only on recorded revision progress or verified completion. Never close a construction batch for inspections alone. Resume from compact saved evidence, never replay pending writes.
- Cosmic is an opt-in interface in `src/themes/cosmic/`, separate from the default Classic and older console-channel styles. Use the five immutable image references under `docs/design/cosmic/` when reviewing it.

## Phase 10 Round D: source-backed construction and runtime blocks (2026-11-14)

The shared SPICA agent must expose authorized actual project-file editing/checking tools alongside graph preflights during construction. `src/spica/construction-coordinator.ts` pages **existing** tool definitions; it never executes tools, invents tool names, weakens grants, or bypasses matching SPICA revision/preflight checks. A failed native check keeps diagnostics and source repair reachable in the same small tool set. The backend's real results (not proposed arguments) are the source of truth for edited file paths and command outcomes.

`SpicaTaskOrchestrator.recordSourceWrite()` and `SparkActionBatchJournal.recordSourceWrite()` checkpoint confirmed source changes. Inspections, no-op replacements, failed writes, format-only migrations, and failed checks do not verify the requested feature. Resume never replays pending edits. New executable V2 blocks remain one source file per block under `src/spica/runtime/blocks/`; permissioned data operations use the existing transactional storage host. The Cosmic theme is out of Round D scope. See `spica/roadmap/51_PHASE10_ROUND_D_CONSTRUCTION_RUNTIME_AND_CHECKPOINTS.md`; run `npm run test:spica:phase10:roundD` and earlier phase regressions.
