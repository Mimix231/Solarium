use std::{
    fs,
    path::{Path, PathBuf},
};
fn safe(root: &Path, path: &Path) -> Result<PathBuf, String> {
    let path = path.canonicalize().map_err(|e| e.to_string())?;
    if !path.starts_with(root) {
        return Err("Installed dependency source is outside the selected project".into());
    }
    Ok(path)
}
#[tauri::command]
pub async fn inspect_dependency_api(
    root: String,
    package_name: String,
    query: String,
) -> Result<serde_json::Value, String> {
    tauri::async_runtime::spawn_blocking(move||{
        if package_name.is_empty()||package_name.len()>200||package_name.split('/').any(|s|s.is_empty()||s=="."||s=="..")||!package_name.chars().all(|c|c.is_ascii_alphanumeric()||"@_./-".contains(c)){return Err("Use an actual installed package name".into())}if query.trim().is_empty()||query.len()>500{return Err("Supply a focused API or type query".into())}
        let base=crate::creator::safe_root(&root)?;let package=safe(&base,&base.join("node_modules").join(&package_name))?;let manifest=safe(&base,&package.join("package.json"))?;let metadata:serde_json::Value=serde_json::from_slice(&fs::read(manifest).map_err(|e|e.to_string())?).map_err(|e|e.to_string())?;
        fn scan(base:&Path,dir:&Path,files:&mut Vec<PathBuf>,depth:u8)->Result<(),String>{if depth>5||files.len()>=500{return Ok(())}for entry in fs::read_dir(dir).map_err(|e|e.to_string())?{let entry=entry.map_err(|e|e.to_string())?;let kind=entry.file_type().map_err(|e|e.to_string())?;if kind.is_symlink(){continue}if kind.is_dir(){if !["node_modules","test","tests","__tests__",".git"].contains(&entry.file_name().to_string_lossy().as_ref()){scan(base,&entry.path(),files,depth+1)?;}}else if kind.is_file()&&["ts","tsx","js","mjs","cjs","md"].contains(&entry.path().extension().and_then(|e|e.to_str()).unwrap_or("")){files.push(safe(base,&entry.path())?);if files.len()>=500{break}}}Ok(())}
        let mut files=Vec::new();for key in ["types","typings"]{if let Some(entry)=metadata[key].as_str(){if let Ok(path)=safe(&base,&package.join(entry)){files.push(path)}}}scan(&base,&package,&mut files,0)?;files.sort();files.dedup();let terms:Vec<String>=query.to_lowercase().split(|c:char|!c.is_alphanumeric()&&c!='_').filter(|w|w.len()>1).map(str::to_owned).collect();let mut passages=Vec::new();
        for file in &files{let stat=file.metadata().map_err(|e|e.to_string())?;if stat.len()>2_000_000{continue}let Ok(text)=fs::read_to_string(file)else{continue};let lines:Vec<&str>=text.lines().collect();let matches:Vec<_>=lines.iter().enumerate().filter_map(|(index,line)|{let lower=line.to_lowercase();let score=terms.iter().filter(|t|lower.contains(t.as_str())).count();(score>0).then_some((score,index))}).collect();for (score,index) in matches.into_iter().take(6){let start=index.saturating_sub(4);let end=(index+12).min(lines.len());passages.push((score,serde_json::json!({"path":file.strip_prefix(&base).map_err(|e|e.to_string())?.to_string_lossy().replace('\\',"/"),"startLine":start+1,"endLine":end,"content":lines[start..end].join("\n")})));}}
        passages.sort_by(|a,b|b.0.cmp(&a.0));Ok(serde_json::json!({"provider":"actual installed dependency source","package":package_name,"version":metadata["version"],"types":metadata["types"],"homepage":metadata["homepage"],"repository":metadata["repository"],"filesExamined":files.len(),"matches":passages.into_iter().take(6).map(|(_,v)|v).collect::<Vec<_>>(),"notice":"Read later lines with read_project_file. Publisher links are package metadata, not independent verification of an online API. No web request was made."}))
    }).await.map_err(|e|e.to_string())?
}
