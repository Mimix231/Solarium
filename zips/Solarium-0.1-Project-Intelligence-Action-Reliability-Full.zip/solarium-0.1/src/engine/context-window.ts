import type { Capabilities, LocalModel } from '../domain/types';
import type { InferenceAdapter } from './backends';
import type { GenerationRequestOptions, LlamaMessage } from './llama';

/** A new request reuses an existing model; the output budget never increases its KV-cache capacity. */
export const CHUNK_SIZE = 2048;
export const CONTEXT_HEADROOM = 96;
export const MIN_OUTPUT = 64;

export interface PreparedGeneration {
  messages: LlamaMessage[];
  outputTokens: number;
  promptTokens: number;
  contextSize: number;
  discardedHistory: number;
  tokenCountSource: 'server' | 'estimate';
  tools: NonNullable<GenerationRequestOptions['tools']>;
}

export function effectiveContextSize(model: LocalModel, capabilities: Capabilities): number {
  const limits = [model.contextSize, capabilities.contextSize].filter((v): v is number => typeof v === 'number' && Number.isFinite(v) && v > 0);
  return Math.floor(Math.min(...(limits.length ? limits : [4096])));
}

export function conservativeTokenEstimate(messages: LlamaMessage[]): number {
  let tokens = 0;
  for (const message of messages) {
    // Conservative for mixed code/non-English text. Never treat a data URL as prompt text.
    tokens += 32 + message.role.length;
    if (typeof message.content === 'string') {
      tokens += Math.ceil(new TextEncoder().encode(message.content).length / 2);
    } else {
      for (const part of message.content) {
        tokens += part.type === 'text' ? Math.ceil(new TextEncoder().encode(part.text).length / 2) : 1400;
      }
    }
    if (message.tool_calls?.length) tokens += Math.ceil(new TextEncoder().encode(JSON.stringify(message.tool_calls)).length / 2);
  }
  return tokens + 32;
}

function latestUserIndex(messages: LlamaMessage[]): number {
  for (let i = messages.length - 1; i >= 0; i--) if (messages[i]?.role === 'user') return i;
  return -1;
}

function isOptionalSystem(message: LlamaMessage): boolean {
  return message.role === 'system' && typeof message.content === 'string' && /^(?:WEB RESEARCH MATERIAL|PROJECT INSTRUCTIONS|PROJECT FILE SNAPSHOT) \(/.test(message.content);
}

/**
 * Fits a real inference request into the currently loaded model's context window.
 * - No chat-history deletion: only the temporary request gets pruned.
 * - The primary Spark instructions and user request are kept unchanged.
 * - Runtime tokenizer is preferred; we reserve template/output headroom even then.
 */
export async function prepareGeneration(
  adapter: InferenceAdapter,
  model: LocalModel,
  capabilities: Capabilities,
  original: LlamaMessage[],
  signal: AbortSignal,
  request: GenerationRequestOptions = {},
  extraHeadroom = 0,
): Promise<PreparedGeneration> {
  if (signal.aborted) throw new DOMException('Stopped', 'AbortError');
  if (!original.some((m) => m.role === 'user')) throw new Error('A user message is required for inference.');
  const contextSize = effectiveContextSize(model, capabilities);
  const headroom = CONTEXT_HEADROOM + Math.max(0, Math.floor(extraHeadroom));
  const messages = [...original];
  let discardedHistory = 0;
  let tools = [...(request.tools ?? [])];
  let source: 'server' | 'estimate' = 'estimate';
  const count = async (): Promise<number> => {
    if (signal.aborted) throw new DOMException('Stopped', 'AbortError');
    try {
      const tokens = await adapter.countTokens(model, messages, signal);
      if (tokens !== null && Number.isSafeInteger(tokens) && tokens >= 0) {
        source = 'server';
        return tokens + (tools.length ? Math.ceil(JSON.stringify(tools).length / 2) + 64 : 0);
      }
    } catch (error) {
      if (signal.aborted) throw error;
      // Older backends may not implement tokenizer APIs. Conservatively estimate instead.
    }
    source = 'estimate';
    return conservativeTokenEstimate(messages) + (tools.length ? Math.ceil(JSON.stringify(tools).length / 2) + 64 : 0);
  };
  let promptTokens = await count();

  // Context integrity comes before reserving a large output allowance.
  // A smaller initial output allowance is preferable to making a follow-up
  // question forget the project it belongs to. llama.cpp streams natively
  // with outputTokens=-1 and is not interrupted at this allowance.
  // Trim untrusted retrieved pages before discarding actual conversation.
  while (promptTokens + MIN_OUTPUT + headroom > contextSize) {
    const optional = messages.findIndex(isOptionalSystem);
    if (optional < 0) break;
    messages.splice(optional, 1);
    discardedHistory++;
    promptTokens = await count();
  }
  while (promptTokens + MIN_OUTPUT + headroom > contextSize) {
    const latestUser = latestUserIndex(messages);
    const oldest = messages.findIndex((message, index) => index < latestUser && message.role !== 'system');
    if (oldest < 0) break;
    messages.splice(oldest, 1);
    discardedHistory++;
    promptTokens = await count();
  }
  // Only omit tool schemas when they genuinely cannot coexist with the
  // essential prompt. If omitted, the caller must report tool unavailability.
  if (promptTokens + MIN_OUTPUT + headroom > contextSize && tools.length) {
    if (request.requireTools) throw new Error('The active model context is too small to hold the Spark identity, project requirements and required development tools. Increase its loaded context size in Models and restart inference; Solarium will not silently remove tools from an implementation request.');
    tools = [];
    promptTokens = await count();
  }
  const outputTokens = Math.min(CHUNK_SIZE, contextSize - promptTokens - headroom);
  if (outputTokens < MIN_OUTPUT) {
    throw new Error(
      `The active model has a ${contextSize}-token context window, but essential Spark instructions and the latest request need about ${promptTokens} tokens. ` +
      'Increase the loaded model context (and restart its inference server), or shorten the latest request/personality. Older chat turns were already excluded from this inference request.',
    );
  }
  return { messages, outputTokens, promptTokens, contextSize, discardedHistory, tokenCountSource: source, tools };
}

