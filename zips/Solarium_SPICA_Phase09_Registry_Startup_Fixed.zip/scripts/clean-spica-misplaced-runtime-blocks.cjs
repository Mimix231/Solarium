#!/usr/bin/env node
'use strict';
/**
 * Remove stale V2 modules left in schema-1 category directories when newer
 * SPICA archives are extracted over older working trees.
 *
 * Canonical: src/spica/runtime/blocks/<category>/runtime/<subpath>
 * Obsolete:  src/spica/runtime/blocks/<category>/<subpath>
 *
 * This script never moves or rewrites code. A stale source is removed only if
 * its executable AST and resolved imports match the canonical source. A
 * divergent or unique implementation is left untouched and blocks startup.
 */
const fs = require('node:fs');
const path = require('node:path');
const { execFileSync } = require('node:child_process');
let ts;
try { ts = require('typescript'); }
catch { ts = require(path.join(execFileSync('npm', ['root', '-g'], { encoding: 'utf8' }).trim(), 'typescript')); }

const root = path.resolve(__dirname, '..');
const blocksRoot = path.join(root, 'src/spica/runtime/blocks');
const checkOnly = process.argv.includes('--check');

function fail(message) { throw new Error(`SPICA stale runtime cleanup: ${message}`); }
function parse(file) {
  const source = ts.createSourceFile(file, fs.readFileSync(file, 'utf8'), ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  if (source.parseDiagnostics.length) fail(`Cannot parse ${path.relative(root, file)}: ${source.parseDiagnostics[0].messageText}`);
  return source;
}
function isRuntimeModule(source) {
  return source.statements.some(statement => ts.isExportAssignment(statement) &&
    !statement.isExportEquals && ts.isCallExpression(statement.expression) &&
    ts.isIdentifier(statement.expression.expression) &&
    statement.expression.expression.text === 'defineRuntimeBlock');
}
function semanticSignature(file, source) {
  const printer = ts.createPrinter({ removeComments: true, newLine: ts.NewLineKind.LineFeed });
  const imports = [];
  const statements = [];
  for (const statement of source.statements) {
    if (ts.isImportDeclaration(statement)) {
      if (!ts.isStringLiteral(statement.moduleSpecifier)) fail(`Dynamic import in ${path.relative(root, file)}`);
      const specifier = statement.moduleSpecifier.text;
      // A relocated module must still import precisely the same resolved helper.
      const target = specifier.startsWith('.')
        ? path.resolve(path.dirname(file), specifier)
        : `package:${specifier}`;
      imports.push({ target, clause: statement.importClause?.getText(source) ?? '' });
    } else {
      statements.push(printer.printNode(ts.EmitHint.Unspecified, statement, source));
    }
  }
  return JSON.stringify({ imports, statements });
}
function filesUnder(dir) {
  const result = [];
  for (const item of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, item.name);
    if (item.isSymbolicLink()) fail(`Symbolic links cannot be processed: ${path.relative(root, full)}`);
    if (item.isDirectory()) result.push(...filesUnder(full));
    else if (item.isFile() && /\.tsx?$/.test(item.name) && !/\.test\.tsx?$/.test(item.name)) result.push(full);
  }
  return result;
}
function pruneEmpty(folder, stop) {
  while (folder !== stop && folder.startsWith(stop + path.sep) && fs.readdirSync(folder).length === 0) {
    fs.rmdirSync(folder);
    folder = path.dirname(folder);
  }
}
function main() {
  if (!fs.existsSync(blocksRoot)) fail(`Missing canonical block root ${blocksRoot}`);
  const misplaced = [];
  for (const category of fs.readdirSync(blocksRoot, { withFileTypes: true })) {
    if (!category.isDirectory()) continue;
    const categoryRoot = path.join(blocksRoot, category.name);
    for (const entry of fs.readdirSync(categoryRoot, { withFileTypes: true })) {
      if (entry.name === 'runtime') continue;
      const full = path.join(categoryRoot, entry.name);
      if (entry.isSymbolicLink()) fail(`Symbolic links cannot be processed: ${path.relative(root, full)}`);
      if (!entry.isDirectory()) continue;
      for (const stale of filesUnder(full)) {
        const source = parse(stale);
        if (!isRuntimeModule(source)) continue; // Schema-1 block, keep it.
        const subpath = path.relative(categoryRoot, stale);
        const canonical = path.join(categoryRoot, 'runtime', subpath);
        if (!fs.existsSync(canonical)) fail(
          `Found an unregistered executable block at ${path.relative(root, stale)}. ` +
          `Its canonical path is missing: ${path.relative(root, canonical)}. No file was removed.`);
        const canonicalSource = parse(canonical);
        if (!isRuntimeModule(canonicalSource) ||
            semanticSignature(stale, source) !== semanticSignature(canonical, canonicalSource)) fail(
          `Found a divergent executable block at ${path.relative(root, stale)}. ` +
          `Compare it with ${path.relative(root, canonical)} manually; no file was removed.`);
        misplaced.push({ stale, categoryRoot });
      }
    }
  }
  if (checkOnly && misplaced.length) fail(
    `${misplaced.length} verified old runtime copies remain, including ${path.relative(root, misplaced[0].stale)}. ` +
    `Run npm run spica:runtime:cleanup to remove only matching duplicates.`);
  for (const { stale, categoryRoot } of misplaced) {
    fs.unlinkSync(stale);
    pruneEmpty(path.dirname(stale), categoryRoot);
    console.log(`Removed verified duplicate: ${path.relative(root, stale)}`);
  }
  console.log(`SPICA stale runtime cleanup verified: ${misplaced.length} old runtime copies ${checkOnly ? 'detected' : 'removed'}.`);
}
try { main(); } catch (error) { console.error(error.message); process.exitCode = 1; }
