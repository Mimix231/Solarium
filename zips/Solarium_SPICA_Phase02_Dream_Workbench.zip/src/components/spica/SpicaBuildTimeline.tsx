import { Box, Stack, Tooltip, Typography } from '@mui/material';
import { Check, Close, Remove } from '@mui/icons-material';
import { stageStatus, type SpicaBuildEvent, type SpicaBuildStage } from '../../spica/build-events';

const phases: { stage: SpicaBuildStage; label: string }[] = [
  { stage: 'generate', label: 'Export' },
  { stage: 'prepare', label: 'Dependencies' },
  { stage: 'compile', label: 'Compile' },
  { stage: 'native-test', label: 'Native tests' },
  { stage: 'desktop-build', label: 'Desktop build' },
  { stage: 'scenario-test', label: 'Scenarios' },
  { stage: 'preview', label: 'Preview' },
];

export function SpicaBuildTimeline({ events }: { events: readonly SpicaBuildEvent[] }) {
  return <Stack className="spica-build-timeline" direction="row" gap={.4} aria-label="Actual build stage statuses">
    {phases.map(({ stage, label }) => {
      const status = stageStatus(events, stage);
      return <Tooltip key={stage} title={`${label}: ${status}`}>
        <Box className="spica-timeline-step" data-status={status}>
          <Box className="spica-timeline-dot" aria-hidden="true">
            {status === 'passed' ? <Check sx={{ fontSize: 12 }} /> : status === 'failed' || status === 'cancelled' ?
              <Close sx={{ fontSize: 12 }} /> : status === 'running' ? <span className="spica-timeline-spinner" /> : <Remove sx={{ fontSize: 12 }} />}
          </Box>
          <Typography fontSize={10} fontWeight={status === 'running' ? 700 : 500}>{label}</Typography>
          <Box component="span" className="spica-sr-only">{status}</Box>
        </Box>
      </Tooltip>;
    })}
  </Stack>;
}
