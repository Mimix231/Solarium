# Solarium 0.1 — Engine + Spark DNA validation

Build date: 2026-10-09.

## Verified in this environment

- **PASS:** `npm test` — TypeScript/TSX parser checked 29 source files without syntax errors.
- **PASS:** Strict domain/engine TypeScript compilation through global `tsc`.
- **PASS:** Node unit and mocked SSE integration suite: **17/17 tests passed**.
- **PASS:** Dual inference adapter test confirms concurrent calls to separate `127.0.0.1:8080` and `127.0.0.1:8000` mock servers and vLLM usage parsing.
- **PASS:** Raw personality content survives workspace serialization without simplification; legacy instructions do not override the raw persona.
- **PASS:** Advanced DNA prompt composition, imported image sanitization, endpoint SSRF restrictions, tool approvals, memory isolation, token-metric labels.

## Could not verify here

- `npm install` / `npm run check` / `npm run lint` / `npm run build`: the npm registry was unreachable, so dependencies are not installed in this container.
- Native Rust `cargo check` and Tauri packaging: the Rust toolchain is not installed here.
- Real GPU performance, downloaded binary correctness, vLLM installation under WSL2, process lifecycle on Windows, and live GPU contention: RTX 3060 / Windows / WSL2 hardware is unavailable here.
- Visual screenshot comparison: no installed browser app build was available.

These are **material outstanding checks**, not successful tests. This package is a source-code implementation, **not a verified Windows binary** or a guarantee that two models will fit simultaneously in 12 GB VRAM.

## Run on your Windows development machine

```powershell
npm install
npm test
npm run check
npm run lint
npm run build
npm run desktop:build
```

Then install both engines from the desktop Models page, inspect endpoints, and run a dual-engine comparison while checking GPU usage. Review [`docs/RTX3060_DUAL_ENGINE_SETUP.md`](docs/RTX3060_DUAL_ENGINE_SETUP.md).

- **PASS (limited):** offline frontend TypeScript static audit with temporary dependency declaration substitutes. This does not validate the real React/MUI/Tauri package typings and cannot replace `npm run check` after installing npm dependencies.
- **PASS:** all npm, TypeScript and Tauri desktop config JSON files parsed successfully.
