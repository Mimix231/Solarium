import { useShallow } from 'zustand/react/shallow';
import { useRef, useState, type ChangeEvent } from 'react';
import { validateSpark } from '../domain/validation';
import { Alert, Box, Button, Chip, Dialog, DialogActions, DialogContent, DialogTitle, Divider, FormControl, FormControlLabel, IconButton, InputLabel, MenuItem, Select, Stack, Switch, Tab, Tabs, TextField, Typography } from '@mui/material';
import AddRounded from '@mui/icons-material/AddRounded';
import EditRounded from '@mui/icons-material/EditRounded';
import DeleteOutlineRounded from '@mui/icons-material/DeleteOutlineRounded';
import UploadRounded from '@mui/icons-material/UploadRounded';
import DownloadRounded from '@mui/icons-material/DownloadRounded';
import { AvatarView } from '../components/AvatarView';
import { SparkDnaEditor } from '../components/SparkDnaEditor';
import { SectionTitle } from '../components/SectionTitle';
import { useSolarium } from '../state/useSolarium';
import { now, uid, type Expression, type Spark, type SparkAvatar } from '../domain/types';

export function SparkStudio() {
  const { workspace, addSpark, selectSpark, setView, deleteSpark, editingSparkId, setEditingSparkId, updateSpark } = useSolarium(useShallow((state) => ({ workspace: state.workspace, addSpark: state.addSpark, selectSpark: state.selectSpark, setView: state.setView, deleteSpark: state.deleteSpark, editingSparkId: state.editingSparkId, setEditingSparkId: state.setEditingSparkId, updateSpark: state.updateSpark })));
  const selected = workspace.sparks.find((s) => s.id === editingSparkId);
  const [tab, setTab] = useState(0);
  const [warning, setWarning] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const importRef = useRef<HTMLInputElement>(null);
  const expressionRef = useRef<HTMLInputElement>(null);
  const setField = <K extends keyof Spark>(key: K, value: Spark[K]) => { if (selected) updateSpark(selected.id, { [key]: value }); };
  const setAvatar = (patch: Partial<SparkAvatar>) => { if (selected) updateSpark(selected.id, { avatar: { ...selected.avatar, ...patch } }); };
  function importPortrait(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type) || file.size > 1_500_000) {
      setWarning('Choose a PNG, JPEG, or WebP image smaller than 1.5 MB.'); return;
    }
    const reader = new FileReader();
    reader.onload = () => { if (typeof reader.result === 'string') setAvatar({ image: reader.result }); };
    reader.readAsDataURL(file);
  }
  function importExpression(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0]; event.target.value = '';
    if (!file || !selected) return;
    if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type) || file.size > 1_500_000) {
      setWarning('Choose a PNG, JPEG or WebP under 1.5 MB.'); return;
    }
    const expression: Expression = selected.avatar.expression;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        const active = useSolarium.getState().workspace.sparks.find((s) => s.id === selected.id);
        if (active) updateSpark(active.id, { avatar: { ...active.avatar, expressionImages: { ...active.avatar.expressionImages, [expression]: reader.result } } });
      }
    };
    reader.readAsDataURL(file);
  }
  function exportSpark(spark: Spark) {
    const blob = new Blob([JSON.stringify({ format: 'solarium-spark-v1', spark }, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url; link.download = `${spark.name.toLowerCase().replace(/[^a-z0-9]+/g, '-') || 'spark'}.spark.json`; link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  async function importSpark(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0]; event.target.value = '';
    if (!file) return;
    try {
      if (file.size > 2_000_000) throw new Error('Spark file is too large.');
      const data: unknown = JSON.parse(await file.text());
      if (!data || typeof data !== 'object') throw new Error('Invalid Spark data.');
      const payload = data as { format?: string; spark?: unknown };
      if (payload.format !== 'solarium-spark-v1' || !payload.spark || typeof payload.spark !== 'object') throw new Error('Unsupported Spark format.');
      const candidate = validateSpark(payload.spark);
      const imported: Spark = {
        ...candidate, id: uid(), preferredModelId: null,
        createdAt: now(), updatedAt: now(),
      };
      useSolarium.getState().mutate((w) => { w.sparks.push(imported); w.selectedSparkId = imported.id; });
      setEditingSparkId(imported.id);
    } catch (error) { setWarning(`Could not import Spark: ${String(error)}`); }
  }
  return <Box className="view-scroll page-padding">
    <SectionTitle eyebrow="YOUR PERSONALITY COLLECTION" title="Spark Studio" description="Build distinct AI personalities. Give each Spark a voice, an identity, and an appearance." action={<Stack direction="row" gap={1}><input hidden ref={importRef} type="file" accept=".json" onChange={(e) => void importSpark(e)} /><Button variant="outlined" startIcon={<UploadRounded />} onClick={() => importRef.current?.click()}>Import</Button><Button variant="contained" startIcon={<AddRounded />} onClick={() => { setTab(0); addSpark(); }}>Create Spark</Button></Stack>} />
    <Box className="spark-grid">
      {workspace.sparks.map((spark) => <div key={spark.id} className="glass spark-card">
        <div className="spark-card-glow" style={{ background: spark.avatar.color }} />
        <Stack direction="row" alignItems="start" justifyContent="space-between"><AvatarView avatar={spark.avatar} size={73} /><Chip label={workspace.selectedSparkId === spark.id ? 'ACTIVE' : 'SPARK'} color={workspace.selectedSparkId === spark.id ? 'primary' : 'default'} size="small" variant="outlined" /></Stack>
        <Typography variant="h6" mt={2}>{spark.name}</Typography>
        <Typography color="text.secondary" fontSize={12} className="spark-description">{spark.description}</Typography>
        <Stack direction="row" gap={1} mt="auto" pt={2}>
          <Button fullWidth variant={workspace.selectedSparkId === spark.id ? 'outlined' : 'contained'} onClick={() => { selectSpark(spark.id); setView('chat'); }}>{workspace.selectedSparkId === spark.id ? 'Chat now' : 'Activate'}</Button>
          <IconButton aria-label={`Export ${spark.name}`} className="icon-surface" onClick={() => exportSpark(spark)}><DownloadRounded fontSize="small" /></IconButton>
          <IconButton aria-label={`Edit ${spark.name}`} className="icon-surface" onClick={() => { setTab(0); setEditingSparkId(spark.id); }}><EditRounded fontSize="small" /></IconButton>
        </Stack>
      </div>)}
      <button className="spark-create glass" onClick={addSpark}><AddRounded sx={{ fontSize: 29 }} /><strong>Make another Spark</strong><span>Start with a blank personality</span></button>
    </Box>
    <Dialog open={Boolean(selected)} onClose={() => setEditingSparkId(null)} maxWidth="lg" fullWidth slotProps={{ paper: { className: 'editor-dialog' } }}>
      {selected && <>
        <DialogTitle sx={{ display: 'flex', gap: 1.4, alignItems: 'center' }}><AvatarView avatar={selected.avatar} size={42} /><Box><Typography fontWeight={750}>Edit {selected.name}</Typography><Typography color="text.secondary" fontSize={11}>Changes save automatically</Typography></Box></DialogTitle>
        <Tabs value={tab} onChange={(_, value: number) => setTab(value)} variant="scrollable" scrollButtons="auto" sx={{ px: 2 }}><Tab label="Identity" /><Tab label="Personality" /><Tab label="Appearance" /><Tab label="Behavior" /></Tabs>
        <DialogContent dividers sx={{ minHeight: 340 }}>
          {warning && <Alert severity="warning" onClose={() => setWarning('')} sx={{ mb: 2 }}>{warning}</Alert>}
          {tab === 0 && <Stack gap={2}>
            <TextField label="Spark name" value={selected.name} inputProps={{ maxLength: 60 }} onChange={(e) => setField('name', e.target.value)} fullWidth />
            <TextField label="Short description" value={selected.description} onChange={(e) => setField('description', e.target.value)} fullWidth multiline minRows={2} />
            <TextField label="First greeting" value={selected.greeting} onChange={(e) => setField('greeting', e.target.value)} fullWidth multiline minRows={2} />
            <Typography color="text.secondary" fontSize={11}>The greeting appears when starting a fresh conversation.</Typography>
          </Stack>}
          {tab === 1 && <SparkDnaEditor key={selected.id} spark={selected} models={workspace.models} update={(patch) => updateSpark(selected.id, patch)} />}
          {tab === 2 && <Stack gap={2}>
            <Stack alignItems="center" py={1}><AvatarView avatar={selected.avatar} size={112} active /><Typography color="text.secondary" fontSize={11} mt={1}>Live avatar preview</Typography></Stack>
            <Box className="avatar-controls">
              <FormControl fullWidth size="small"><InputLabel>Avatar style</InputLabel><Select label="Avatar style" value={selected.avatar.style} onChange={(e) => setAvatar({ style: e.target.value as SparkAvatar['style'], image: undefined })}><MenuItem value="portrait">Portrait</MenuItem><MenuItem value="orb">Orb</MenuItem><MenuItem value="glyph">Glyph</MenuItem></Select></FormControl>
              <FormControl fullWidth size="small"><InputLabel>Expression</InputLabel><Select label="Expression" value={selected.avatar.expression} onChange={(e) => setAvatar({ expression: e.target.value as SparkAvatar['expression'] })}>{(['neutral','curious','happy','focused'] as const).map((x) => <MenuItem key={x} value={x}>{x}</MenuItem>)}</Select></FormControl>
              <label className="color-label">Primary color<input aria-label="Primary avatar color" type="color" value={selected.avatar.color} onChange={(e) => setAvatar({ color: e.target.value, image: undefined })} /></label>
              <label className="color-label">Secondary color<input aria-label="Secondary avatar color" type="color" value={selected.avatar.secondary} onChange={(e) => setAvatar({ secondary: e.target.value, image: undefined })} /></label>
              <FormControl size="small" fullWidth><InputLabel>Hair layer</InputLabel><Select label="Hair layer" value={selected.avatar.hair ?? 'wave'} onChange={(e) => setAvatar({ hair: e.target.value as SparkAvatar['hair'] })}><MenuItem value="wave">Wavy</MenuItem><MenuItem value="short">Short</MenuItem><MenuItem value="none">None</MenuItem></Select></FormControl>
              <FormControl size="small" fullWidth><InputLabel>Accessory layer</InputLabel><Select label="Accessory layer" value={selected.avatar.accessory ?? 'none'} onChange={(e) => setAvatar({ accessory: e.target.value as SparkAvatar['accessory'] })}><MenuItem value="none">None</MenuItem><MenuItem value="glasses">Glasses</MenuItem><MenuItem value="halo">Halo</MenuItem></Select></FormControl>
              <TextField label="Glyph character" value={selected.avatar.glyph} onChange={(e) => setAvatar({ glyph: e.target.value.slice(0, 2) })} />
              <FormControlLabel control={<Switch checked={selected.avatar.animate} onChange={(e) => setAvatar({ animate: e.target.checked })} />} label="Subtle animation" />
            </Box>
            <input ref={expressionRef} hidden type="file" accept="image/png,image/jpeg,image/webp" onChange={importExpression} />
            <Stack direction="row" gap={1} flexWrap="wrap">
              <Button variant="outlined" startIcon={<UploadRounded />} onClick={() => expressionRef.current?.click()}>Set {selected.avatar.expression} expression image</Button>
              {selected.avatar.expressionImages?.[selected.avatar.expression] && <Button onClick={() => {
                const images = { ...selected.avatar.expressionImages }; delete images[selected.avatar.expression]; setAvatar({ expressionImages: images });
              }}>Remove expression image</Button>}
            </Stack>
            <Typography fontSize={11} color="text.secondary">Assign different images to Neutral, Curious, Happy, and Focused using the Expression selector above.</Typography>
            <input ref={inputRef} hidden type="file" accept="image/png,image/jpeg,image/webp" onChange={importPortrait} />
            <Stack direction="row" gap={1}><Button variant="outlined" startIcon={<UploadRounded />} onClick={() => inputRef.current?.click()}>Import portrait</Button>{selected.avatar.image && <Button onClick={() => setAvatar({ image: undefined })}>Remove image</Button>}</Stack>
            <Typography color="text.secondary" fontSize={11}>Uploaded images remain on your device. Animated SVG avatars do not use an LLM or GPU-intensive rendering.</Typography>
          </Stack>}
          {tab === 3 && <Stack gap={2}>
            <Typography fontSize={12} color="text.secondary">Assign a preferred local model. Conversation mode can still override it.</Typography>
            <FormControl fullWidth size="small"><InputLabel>Preferred model</InputLabel><Select label="Preferred model" value={selected.preferredModelId ?? ''} onChange={(e) => setField('preferredModelId', e.target.value || null)}><MenuItem value="">Use current/default model</MenuItem>{workspace.models.map((m) => <MenuItem value={m.id} key={m.id}>{m.name}</MenuItem>)}</Select></FormControl>
            <Divider />
            <Typography fontWeight={650} fontSize={12}>Privacy and memory</Typography>
            <Typography fontSize={12} color="text.secondary">Each Spark can access global memories and memories explicitly assigned to it. Memories are never extracted automatically.</Typography>
            <Button sx={{ alignSelf: 'start' }} onClick={() => { setEditingSparkId(null); setView('memories'); }}>Manage memories</Button>
          </Stack>}
        </DialogContent>
        <DialogActions sx={{ px: 2, py: 1.3 }}><Typography color="text.secondary" fontSize={10} sx={{ mr: 'auto' }}>Edited {new Date(selected.updatedAt || now()).toLocaleDateString()}</Typography><Button color="error" startIcon={<DeleteOutlineRounded />} disabled={workspace.sparks.length <= 1} onClick={() => { if (confirm(`Delete ${selected.name} and all its chats?`)) { deleteSpark(selected.id); setEditingSparkId(null); } }}>Delete</Button><Button variant="contained" onClick={() => setEditingSparkId(null)}>Done</Button></DialogActions>
      </>}
    </Dialog>
  </Box>;
}
