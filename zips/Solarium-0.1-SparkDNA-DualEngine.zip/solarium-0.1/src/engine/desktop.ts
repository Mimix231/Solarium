const isDesktop = (): boolean => typeof window !== 'undefined' && '__TAURI_INTERNALS__' in window;
export async function chooseFile(filters: { name: string; extensions: string[] }[] = []): Promise<string | null> {
  if (!isDesktop()) throw new Error('Native file browsing is available in the desktop app only.');
  const { open } = await import('@tauri-apps/plugin-dialog');
  const result = await open({ multiple: false, directory: false, ...(filters.length ? { filters } : {}) });
  return typeof result === 'string' ? result : null;
}
export async function startLlamaServer(executable: string, gguf: string, port: number, context: number, gpuLayers = -1): Promise<string> {
  if (!isDesktop()) throw new Error('Start/stop commands require the desktop app.');
  const { invoke } = await import('@tauri-apps/api/core');
  return invoke<string>('start_llama_server', { executable, gguf, port, context, gpuLayers });
}
export async function stopLlamaServer(): Promise<string> {
  if (!isDesktop()) throw new Error('Start/stop commands require the desktop app.');
  const { invoke } = await import('@tauri-apps/api/core');
  return invoke<string>('stop_llama_server');
}

export async function installLlamaServer(cuda: boolean): Promise<string> {
  if (!isDesktop()) throw new Error('Automatic installation requires Solarium Desktop on Windows x64.');
  const { invoke } = await import('@tauri-apps/api/core');
  return invoke<string>('install_llama_server', { cuda });
}
export async function startVllmServer(distro: string, model: string, port: number, context: number, gpuMemoryUtilization: number): Promise<string> {
  if (!isDesktop()) throw new Error('WSL2 server launch requires the Windows desktop application.');
  const { invoke } = await import('@tauri-apps/api/core');
  return invoke<string>('start_vllm_server', { distro, model, port, context, gpuMemoryUtilization });
}
export async function stopVllmServer(): Promise<string> {
  if (!isDesktop()) throw new Error('WSL2 server control requires the Windows desktop application.');
  const { invoke } = await import('@tauri-apps/api/core');
  return invoke<string>('stop_vllm_server');
}
export async function gpuStatus(): Promise<string> {
  if (!isDesktop()) throw new Error('GPU inspection requires the desktop application.');
  const { invoke } = await import('@tauri-apps/api/core');
  return invoke<string>('nvidia_gpu_status');
}

export async function installVllmWsl(distro: string): Promise<string> {
  if (!isDesktop()) throw new Error('WSL2 installation requires Solarium Desktop for Windows.');
  const { invoke } = await import('@tauri-apps/api/core');
  return invoke<string>('install_vllm_wsl', { distro });
}

export async function readEngineLog(engine: 'llama.cpp' | 'vllm'): Promise<string> {
  if (!isDesktop()) throw new Error('Engine logs require the desktop application.');
  const { invoke } = await import('@tauri-apps/api/core');
  return invoke<string>('read_engine_log', { engine });
}
