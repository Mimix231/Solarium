#!/usr/bin/env bash
# Runs INSIDE an existing WSL2 Ubuntu distro. Review before clicking Install.
set -euo pipefail
if [ "$(id -u)" -eq 0 ]; then echo 'Install vLLM as an ordinary WSL user, not root.' >&2; exit 1; fi
if ! command -v nvidia-smi >/dev/null 2>&1; then echo 'NVIDIA GPU passthrough in WSL2 is unavailable; update the host NVIDIA driver.' >&2; exit 1; fi
if ! command -v python3 >/dev/null 2>&1; then echo 'Install Python 3.10+ and python3-venv inside WSL2 first.' >&2; exit 1; fi
python3 -m venv "$HOME/.local/share/solarium-vllm"
"$HOME/.local/share/solarium-vllm/bin/python" -m pip install --upgrade pip
"$HOME/.local/share/solarium-vllm/bin/python" -m pip install vllm
printf 'Installed vLLM: %s\n' "$HOME/.local/share/solarium-vllm/bin/vllm"
