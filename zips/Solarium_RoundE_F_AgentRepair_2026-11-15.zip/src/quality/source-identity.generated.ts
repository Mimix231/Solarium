// Generated from actual source bytes; never hand edited.
export const sourceIdentity={"schemaVersion":1,"sha256":"2cd041239c64a3cc6afe96da6ab95e06a6b89f0692d9daebc71ceabfa3e087e9","files":691,"commit":"312f81cc9d3aa4a486aa1e8541cde76ae6fb64c8"} as const;
