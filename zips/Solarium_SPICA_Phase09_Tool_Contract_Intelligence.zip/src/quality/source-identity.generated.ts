// Generated from actual source bytes; never hand edited.
export const sourceIdentity={"schemaVersion":1,"sha256":"fdea443b0f5a7e6636188a7cee8c11f686aa030178ac7bf3623e6bbed7f2a817","files":574,"commit":null} as const;
