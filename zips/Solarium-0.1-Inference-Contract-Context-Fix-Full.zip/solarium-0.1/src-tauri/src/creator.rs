//! Creator workspace: explicit local file access and opt-in public web retrieval.
use std::fs;
use std::io::Read;
use std::net::{IpAddr, ToSocketAddrs};
use std::path::{Path, PathBuf};
use std::time::Duration;
use serde::Serialize;

fn safe_root(root: &str) -> Result<PathBuf, String> {
    let dir = Path::new(root).canonicalize().map_err(|e| format!("Project directory unavailable: {e}"))?;
    if !dir.is_dir() { return Err("The project folder is not a directory.".into()); }
    Ok(dir)
}
fn safe_file(root: &str, relative: &str) -> Result<PathBuf, String> {
    if relative.is_empty() || relative.len() > 1024 { return Err("Invalid file path.".into()); }
    let base = safe_root(root)?;
    let proposed = Path::new(relative);
    if proposed.is_absolute() || proposed.components().any(|c| !matches!(c, std::path::Component::Normal(_))) {
        return Err("Only project-relative paths are accepted.".into());
    }
    let path = base.join(proposed).canonicalize().map_err(|e| e.to_string())?;
    if !path.starts_with(&base) || !path.is_file() { return Err("File is outside the project or not a regular file.".into()); }
    let allowed = ["rs", "ts", "tsx", "js", "jsx", "json", "md", "txt", "css", "html", "py", "toml", "yml", "yaml", "xml", "svg", "c", "h", "cpp", "hpp", "java", "go", "sh", "ps1", "sql", "vue", "svelte", "gitignore", "csv", "tex"];
    let ext = path.extension().and_then(|x| x.to_str()).unwrap_or("").to_lowercase();
    if !allowed.contains(&ext.as_str()) && path.file_name().and_then(|x| x.to_str()) != Some(".gitignore") { return Err("This file format is not editable in Solarium.".into()); }
    Ok(path)
}
#[tauri::command]
pub fn list_project_files(root: String) -> Result<Vec<String>, String> {
    let base = safe_root(&root)?;
    let mut found = Vec::new();
    fn walk(base: &Path, path: &Path, depth: usize, out: &mut Vec<String>) {
        if depth > 6 || out.len() >= 500 { return; }
        let Ok(items) = fs::read_dir(path) else { return; };
        for entry in items.flatten() {
            if out.len() >= 500 { break; }
            let Ok(ft) = entry.file_type() else { continue; };
            if ft.is_symlink() { continue; }
            let name = entry.file_name().to_string_lossy().to_string();
            if ft.is_dir() {
                if ["node_modules", ".git", "target", "dist", "build", ".venv", ".next", "runtime"].contains(&name.as_str()) { continue; }
                walk(base, &entry.path(), depth + 1, out);
            } else if ft.is_file() {
                if let Ok(rel) = entry.path().strip_prefix(base) {
                    if let Some(s) = rel.to_str() {
                        if safe_file(base.to_string_lossy().as_ref(), s).is_ok() { out.push(s.replace('\\', "/")); }
                    }
                }
            }
        }
    }
    walk(&base, &base, 0, &mut found);
    found.sort();
    Ok(found)
}
#[tauri::command]
pub fn read_project_file(root: String, relative: String) -> Result<String, String> {
    let path = safe_file(&root, &relative)?;
    if path.metadata().map_err(|e| e.to_string())?.len() > 1_000_000 { return Err("File is larger than the 1 MB editor limit.".into()); }
    fs::read_to_string(path).map_err(|e| format!("Cannot read UTF-8 text file: {e}"))
}
#[tauri::command]
pub fn write_project_file(root: String, relative: String, content: String, expected: String) -> Result<(), String> {
    let path = safe_file(&root, &relative)?;
    if content.len() > 1_000_000 || expected.len() > 1_000_000 { return Err("Editor limit is 1 MB.".into()); }
    let original = fs::read_to_string(&path).map_err(|e| e.to_string())?;
    if original != expected { return Err("File changed on disk. Reload it before saving.".into()); }
    // A .solarium.bak file is created on every save; never use raw model edits here.
    let backup = path.with_extension(format!("{}.solarium.bak", path.extension().and_then(|x| x.to_str()).unwrap_or("txt")));
    fs::copy(&path, &backup).map_err(|e| format!("Could not create backup: {e}"))?;
    fs::write(path, content).map_err(|e| e.to_string())
}

#[derive(Serialize)]
pub struct ProjectCheckResult {
    pub command: String,
    pub exit_code: Option<i32>,
    pub stdout: String,
    pub stderr: String,
    pub timed_out: bool,
}
/** No shell interpolation or arbitrary command strings. The model can only select a listed check. */
#[tauri::command]
pub async fn run_project_check(root: String, check: String) -> Result<ProjectCheckResult, String> {
    tauri::async_runtime::spawn_blocking(move || {
        use std::process::{Command, Stdio};
        use std::thread;
        use std::time::{Instant, SystemTime, UNIX_EPOCH};
        let base = safe_root(&root)?;
        let (program, args): (&str, &[&str]) = match check.as_str() {
            "npm_check" => (if cfg!(windows) { "npm.cmd" } else { "npm" }, &["run", "check"]),
            "npm_test" => (if cfg!(windows) { "npm.cmd" } else { "npm" }, &["test"]),
            "npm_build" => (if cfg!(windows) { "npm.cmd" } else { "npm" }, &["run", "build"]),
            "cargo_check" => ("cargo", &["check"]),
            "git_diff" => ("git", &["diff", "--stat"]),
            "git_status" => ("git", &["status", "--short"]),
            _ => return Err("Unsupported check. Choose npm_check, npm_test, npm_build, cargo_check or git_diff.".into()),
        };
        let id = SystemTime::now().duration_since(UNIX_EPOCH).map_err(|e| e.to_string())?.as_nanos();
        let log_dir = crate::runtime::ensure_runtime_dir()?.join("logs");
        fs::create_dir_all(&log_dir).map_err(|e| format!("Cannot create runtime logs: {e}"))?;
        let out_path = log_dir.join(format!("solarium-check-{id}-out.log"));
        let err_path = log_dir.join(format!("solarium-check-{id}-err.log"));
        let run = (|| -> Result<ProjectCheckResult, String> {
            let stdout = fs::OpenOptions::new().write(true).create_new(true).open(&out_path).map_err(|e| e.to_string())?;
            let stderr = fs::OpenOptions::new().write(true).create_new(true).open(&err_path).map_err(|e| e.to_string())?;
            let mut process = Command::new(program).args(args).current_dir(&base)
                .stdin(Stdio::null()).stdout(Stdio::from(stdout)).stderr(Stdio::from(stderr))
                .spawn().map_err(|e| format!("Cannot execute {program}: {e}"))?;
            let started = Instant::now();
            let (status, timed_out) = loop {
                if let Some(status) = process.try_wait().map_err(|e| e.to_string())? { break (status.code(), false); }
                if started.elapsed() > Duration::from_secs(180) {
                    let _ = process.kill(); let _ = process.wait(); break (None, true);
                }
                thread::sleep(Duration::from_millis(120));
            };
            let clipped = |path: &Path| -> String {
                match fs::read(path) {
                    Ok(mut bytes) => {
                        if bytes.len() > 80_000 { bytes.truncate(80_000); bytes.extend_from_slice(b"\n[Output truncated at 80 KB]\n"); }
                        String::from_utf8_lossy(&bytes).to_string()
                    },
                    Err(error) => format!("Could not read execution log: {error}"),
                }
            };
            Ok(ProjectCheckResult { command: format!("{} {}", program, args.join(" ")), exit_code: status,
                stdout: clipped(&out_path), stderr: clipped(&err_path), timed_out })
        })();
        let _ = fs::remove_file(&out_path); let _ = fs::remove_file(&err_path);
        run
    }).await.map_err(|e| format!("Check worker failed: {e}"))?
}

#[derive(Serialize)]
pub struct GeneratedFilePreview { pub exists: bool, pub current: String }
fn safe_generated_target(root: &str, relative: &str) -> Result<PathBuf, String> {
    if relative.is_empty() || relative.len() > 1024 { return Err("Invalid project-relative filename.".into()); }
    let base = safe_root(root)?;
    let rel = Path::new(relative);
    if rel.is_absolute() || rel.components().any(|c| !matches!(c, std::path::Component::Normal(_))) { return Err("Path traversal is not permitted.".into()); }
    let filename = rel.file_name().and_then(|x| x.to_str()).ok_or("Filename is not valid UTF-8")?;
    let ext = rel.extension().and_then(|x| x.to_str()).unwrap_or("").to_ascii_lowercase();
    let allowed = ["rs", "ts", "tsx", "js", "jsx", "json", "md", "txt", "css", "html", "py", "toml", "yml", "yaml", "xml", "svg", "c", "h", "cpp", "hpp", "java", "go", "sh", "ps1", "sql", "vue", "svelte", "csv", "tex"];
    if !allowed.contains(&ext.as_str()) && filename != ".gitignore" { return Err("Unsupported source file extension.".into()); }
    let parent = base.join(rel.parent().unwrap_or(Path::new(""))).canonicalize().map_err(|e| format!("Project directory does not exist: {e}"))?;
    if !parent.starts_with(&base) || !parent.is_dir() { return Err("File is outside the selected project.".into()); }
    let target = parent.join(filename);
    if target.exists() { return safe_file(root, relative); }
    Ok(target)
}
#[tauri::command]
pub fn inspect_generated_file(root: String, relative: String) -> Result<GeneratedFilePreview, String> {
    let target = safe_generated_target(&root, &relative)?;
    if target.exists() {
        let current = fs::read_to_string(&target).map_err(|e| format!("Cannot read existing source: {e}"))?;
        if current.len() > 1_000_000 { return Err("Existing file exceeds the 1 MB editor limit.".into()); }
        Ok(GeneratedFilePreview { exists: true, current })
    } else { Ok(GeneratedFilePreview { exists: false, current: String::new() }) }
}
#[tauri::command]
pub fn save_generated_file(root: String, relative: String, content: String, expected: Option<String>) -> Result<(), String> {
    use std::io::Write;
    if content.len() > 1_000_000 { return Err("Generated file exceeds the 1 MB limit.".into()); }
    let target = safe_generated_target(&root, &relative)?;
    if let Some(original) = expected {
        // Updates are subject to the same reviewed-diff and backup requirements as the editor.
        write_project_file(root, relative, content, original)
    } else {
        if target.exists() { return Err("File already exists. Review its content before overwriting.".into()); }
        let mut file = fs::OpenOptions::new().write(true).create_new(true).open(&target).map_err(|e| format!("Could not create source: {e}"))?;
        file.write_all(content.as_bytes()).map_err(|e| format!("Could not write source: {e}"))
    }
}

/// Only a user-selected parent folder may be used to create a new project.
#[tauri::command]
pub fn create_project_directory(parent: String, name: String) -> Result<String, String> {
    let clean = name.trim();
    if clean.is_empty() || clean.len() > 100 || clean == "." || clean == ".." ||
        clean.chars().any(|c| c.is_control() || "<>:\\/?*|\"".contains(c)) || (clean.ends_with('.') || clean.ends_with(' ')) {
        return Err("Choose a valid directory name (without path separators or reserved characters).".into());
    }
    let base = safe_root(&parent)?;
    let target = base.join(clean);
    if target.exists() { return Err("The project directory already exists. Choose Existing Project instead.".into()); }
    fs::create_dir(&target).map_err(|e| format!("Could not create project directory: {e}"))?;
    Ok(target.to_string_lossy().to_string())
}

#[derive(Serialize)]
pub struct CodeMatch { pub path: String, pub line: usize, pub text: String }
#[tauri::command]
pub fn search_project_code(root: String, query: String) -> Result<Vec<CodeMatch>, String> {
    if query.trim().len() < 2 || query.len() > 160 { return Err("Search query must have 2–160 characters.".into()); }
    let needle = query.to_lowercase();
    let mut matches = Vec::new();
    for relative in list_project_files(root.clone())? {
        if matches.len() >= 80 { break; }
        let path = safe_file(&root, &relative)?;
        if path.metadata().map_err(|e| e.to_string())?.len() > 250_000 { continue; }
        let Ok(text) = fs::read_to_string(path) else { continue; };
        for (line, value) in text.lines().enumerate() {
            if value.to_lowercase().contains(&needle) {
                matches.push(CodeMatch { path: relative.clone(), line: line + 1, text: value.chars().take(240).collect() });
                if matches.len() >= 80 { break; }
            }
        }
    }
    Ok(matches)
}

/// Precise reviewed edit for an existing file; the model does not need to
/// copy an entire large source file into its context to change one function.
#[tauri::command]
pub fn replace_project_text(root: String, relative: String, expected_fragment: String, replacement: String) -> Result<usize, String> {
    if expected_fragment.is_empty() || expected_fragment.len() > 200_000 || replacement.len() > 200_000 {
        return Err("The reviewed edit must replace a non-empty fragment below 200KB.".into());
    }
    let old = read_project_file(root.clone(), relative.clone())?;
    let matches = old.matches(&expected_fragment).count();
    if matches != 1 { return Err(format!("Expected code fragment occurs {matches} times; narrow the selection before editing.")); }
    let updated = old.replacen(&expected_fragment, &replacement, 1);
    write_project_file(root, relative, updated, old)?;
    Ok(1)
}

#[derive(serde::Deserialize)]
pub struct ProjectFileChange { pub path: String, pub content: String, pub expected: Option<String> }
#[derive(Serialize)]
pub struct AppliedChange { pub path: String, pub operation: String }

/// Apply reviewed edits after a Tauri frontend approval. Never accept absolute paths,
/// traverse out of the chosen project, follow symlinked directories, or silently overwrite.
#[tauri::command]
pub fn apply_project_changes(root: String, files: Vec<ProjectFileChange>) -> Result<Vec<AppliedChange>, String> {
    if files.is_empty() || files.len() > 12 { return Err("Provide between 1 and 12 files per reviewed change set.".into()); }
    let base = safe_root(&root)?;
    let mut validated = Vec::new();
    let mut seen = std::collections::HashSet::new();
    for change in files {
        if change.path.is_empty() || change.path.len() > 512 || change.content.len() > 1_000_000 { return Err("Invalid filename or file exceeds 1MB.".into()); }
        let rel = Path::new(&change.path);
        if rel.is_absolute() || rel.components().any(|component| !matches!(component, std::path::Component::Normal(_))) { return Err("Only project-relative filenames are permitted.".into()); }
        let filename = rel.file_name().and_then(|x| x.to_str()).ok_or("Invalid filename encoding")?;
        let ext = rel.extension().and_then(|x| x.to_str()).unwrap_or("").to_ascii_lowercase();
        let allowed = ["rs", "ts", "tsx", "js", "jsx", "json", "md", "txt", "css", "html", "py", "toml", "yml", "yaml", "xml", "svg", "c", "h", "cpp", "hpp", "java", "go", "sh", "ps1", "sql", "vue", "svelte", "csv", "tex"];
        if !allowed.contains(&ext.as_str()) && filename != ".gitignore" { return Err(format!("Unsupported source file extension: {filename}")); }
        let key = change.path.to_lowercase().replace('\\', "/");
        if !seen.insert(key) { return Err("Duplicated target in change set.".into()); }
        // Verify every existing ancestor of a proposed new file isn't a junction/symlink.
        let mut cursor = base.clone();
        for component in rel.parent().unwrap_or(Path::new("")).components() {
            cursor.push(component);
            if cursor.exists() {
                let metadata = fs::symlink_metadata(&cursor).map_err(|e| e.to_string())?;
                if metadata.file_type().is_symlink() || !metadata.is_dir() || !cursor.canonicalize().map_err(|e| e.to_string())?.starts_with(&base) { return Err("File parent is outside the project or is a symlink.".into()); }
            }
        }
        let target = base.join(rel);
        let original = if target.exists() { Some(fs::read_to_string(safe_file(&root, &change.path)?).map_err(|e| e.to_string())?) } else { None };
        if original.as_deref() != change.expected.as_deref() { return Err(format!("{} changed since inspection. Review the current version before saving.", change.path)); }
        validated.push((change.path, target, change.content, original));
    }
    // Validate the complete batch before writing any files. If one write fails,
    // restore already-touched files to their original bytes and report the failure.
    let mut written: Vec<(PathBuf, Option<String>)> = Vec::new();
    for (relative, target, content, original) in validated {
        let attempt = (|| -> Result<(), String> {
            if let Some(parent) = target.parent() { fs::create_dir_all(parent).map_err(|e| e.to_string())?; }
            if original.is_some() {
                let backup = target.with_extension(format!("{}.solarium.bak", target.extension().and_then(|e| e.to_str()).unwrap_or("txt")));
                fs::copy(&target, backup).map_err(|e| format!("Backup failed: {e}"))?;
            }
            let mut options = fs::OpenOptions::new();
            if original.is_some() { options.write(true).truncate(true); } else { options.write(true).create_new(true); }
            use std::io::Write;
            options.open(&target).map_err(|e| e.to_string())?.write_all(content.as_bytes()).map_err(|e| e.to_string())
        })();
        if let Err(error) = attempt {
            // Include current target; partial writes must not survive errors.
            if let Some(previous) = &original { let _ = fs::write(&target, previous); } else { let _ = fs::remove_file(&target); }
            for (path, prior) in written.into_iter().rev() { if let Some(bytes) = prior { let _ = fs::write(path, bytes); } else { let _ = fs::remove_file(path); } }
            return Err(format!("Could not apply {relative}: {error}. Previously written files were rolled back."));
        }
        written.push((target, original));
    }
    Ok(written.into_iter().map(|(path, original)| AppliedChange { path: path.strip_prefix(&base).unwrap_or(&path).to_string_lossy().replace('\\', "/"), operation: if original.is_some() { "updated".into() } else { "created".into() } }).collect())
}

#[derive(Serialize)]
pub struct WebResult { pub title: String, pub url: String, pub excerpt: String }
fn public_https(input: &str) -> Result<(reqwest::Url, Vec<IpAddr>), String> {
    let url = reqwest::Url::parse(input).map_err(|e| e.to_string())?;
    if url.scheme() != "https" || url.username() != "" || url.password().is_some() || url.port_or_known_default() != Some(443) {
        return Err("Only public HTTPS URLs on port 443 can be opened.".into());
    }
    let host = url.host_str().ok_or("URL has no hostname")?;
    if host.eq_ignore_ascii_case("localhost") || host.ends_with(".localhost") || host.ends_with(".local") || host.ends_with(".internal") { return Err("Local network hosts are blocked.".into()); }
    let addresses: Vec<IpAddr> = (host, 443).to_socket_addrs().map_err(|e| format!("Cannot resolve host: {e}"))?.map(|s| s.ip()).collect();
    if addresses.is_empty() || addresses.iter().any(|ip| match ip {
        IpAddr::V4(v) => v.is_private() || v.is_loopback() || v.is_link_local() || v.is_multicast() || v.is_unspecified() || v.octets() == [255, 255, 255, 255] || v.octets()[0] == 0 || v.octets()[0] >= 240 || (v.octets()[0] == 100 && (64..128).contains(&v.octets()[1])),
        IpAddr::V6(v) => v.is_loopback() || v.is_unspecified() || v.is_multicast() || v.is_unique_local() || v.is_unicast_link_local() || v.to_ipv4_mapped().is_some_and(|v| v.is_private() || v.is_loopback() || v.is_link_local()),
    }) { return Err("Website resolves to a non-public address.".into()); }
    Ok((url, addresses))
}
fn client_for(url: &reqwest::Url, ips: &[IpAddr]) -> Result<reqwest::blocking::Client, String> {
    let mut builder = reqwest::blocking::Client::builder()
        .timeout(Duration::from_secs(18)).connect_timeout(Duration::from_secs(8))
        .redirect(reqwest::redirect::Policy::none()).user_agent("Solarium/0.1 (+local research)");
    if let Some(host) = url.host_str() { for ip in ips { builder = builder.resolve(host, std::net::SocketAddr::new(*ip, 443)); } }
    builder.build().map_err(|e| e.to_string())
}
fn decode_entities(input: &str) -> String {
    input.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&#39;", "'").replace("&nbsp;", " ")
}
fn element(fragment: &str, tag: &str) -> String {
    let open = format!("<{tag}>"); let close = format!("</{tag}>");
    fragment.split_once(&open).and_then(|(_, tail)| tail.split_once(&close).map(|(text, _)| decode_entities(text))).unwrap_or_default()
}
#[tauri::command]
fn search_web_inner(query: String) -> Result<Vec<WebResult>, String> {
    let q = query.trim();
    if q.is_empty() || q.len() > 300 { return Err("Search query must contain 1–300 characters.".into()); }
    let mut url = reqwest::Url::parse("https://www.bing.com/search").map_err(|e| e.to_string())?;
    url.query_pairs_mut().append_pair("format", "rss").append_pair("q", q);
    let (url, ips) = public_https(url.as_str())?;
    let mut response = client_for(&url, &ips)?.get(url).send().map_err(|e| format!("Search unavailable: {e}"))?.error_for_status().map_err(|e| e.to_string())?;
    let mut raw = Vec::new(); response.by_ref().take(250_000).read_to_end(&mut raw).map_err(|e| e.to_string())?;
    let feed = String::from_utf8_lossy(&raw);
    let mut results = Vec::new();
    for item in feed.split("<item>").skip(1).take(12) {
        let link = element(item, "link");
        if public_https(&link).is_err() { continue; }
        results.push(WebResult { title: element(item, "title"), url: link, excerpt: element(item, "description") });
    }
    if results.is_empty() { return Err("The search provider returned no usable public results. Try a different query or URL.".to_string()); }
    Ok(results)
}
#[tauri::command]
fn read_web_inner(url: String) -> Result<String, String> {
    let (url, ips) = public_https(&url)?;
    let mut response = client_for(&url, &ips)?.get(url).send().map_err(|e| e.to_string())?.error_for_status().map_err(|e| e.to_string())?;
    let mime = response.headers().get(reqwest::header::CONTENT_TYPE).and_then(|x| x.to_str().ok()).unwrap_or("").to_string();
    if !mime.contains("text/html") && !mime.contains("text/plain") && !mime.contains("application/xhtml+xml") { return Err("Only HTML and text pages are supported in website reader.".into()); }
    let mut data = Vec::new(); response.by_ref().take(500_000).read_to_end(&mut data).map_err(|e| e.to_string())?;
    let page = String::from_utf8_lossy(&data);
    if mime.contains("text/plain") { return Ok(page.chars().take(24_000).collect()); }
    let mut result = String::new(); let mut tag = String::new(); let mut inside = false; let mut skip = false;
    for ch in page.chars() {
        if ch == '<' { inside = true; tag.clear(); continue; }
        if ch == '>' && inside {
            let t = tag.trim().to_lowercase();
            if t.starts_with("script") || t.starts_with("style") || t.starts_with("nav") { skip = true; }
            if t.starts_with("/script") || t.starts_with("/style") || t.starts_with("/nav") { skip = false; }
            if t.starts_with("p") || t.starts_with("/p") || t.starts_with("h1") || t.starts_with("h2") || t.starts_with("/li") || t.starts_with("br") { result.push('\n'); }
            inside = false; continue;
        }
        if inside { if tag.len() < 100 { tag.push(ch); } } else if !skip { result.push(ch); }
        if result.len() > 100_000 { break; }
    }
    Ok(decode_entities(&result).split_whitespace().collect::<Vec<_>>().join(" ").chars().take(24_000).collect())
}

#[tauri::command]
pub async fn search_public_web(query: String) -> Result<Vec<WebResult>, String> {
    tauri::async_runtime::spawn_blocking(move || search_web_inner(query))
        .await.map_err(|e| format!("Search worker failed: {e}"))?
}
#[tauri::command]
pub async fn read_public_webpage(url: String) -> Result<String, String> {
    tauri::async_runtime::spawn_blocking(move || read_web_inner(url))
        .await.map_err(|e| format!("Website worker failed: {e}"))?
}

/// Real stdout/stderr produced by an approved project check. An event is sent
/// only when bytes were actually received from the child process.
#[derive(Clone, Serialize)]
pub struct ProjectCheckStreamEvent { pub stream: String, pub chunk: String }

#[tauri::command]
pub async fn run_project_check_stream(
    root: String,
    check: String,
    on_event: tauri::ipc::Channel<ProjectCheckStreamEvent>,
) -> Result<ProjectCheckResult, String> {
    tauri::async_runtime::spawn_blocking(move || {
        use std::io::Read;
        use std::process::{Command, Stdio};
        use std::sync::mpsc;
        use std::thread;
        use std::time::Instant;
        let base = safe_root(&root)?;
        // Explicit allowlist, identical to the non-streaming command.
        let (program, args): (&str, &[&str]) = match check.as_str() {
            "npm_check" => (if cfg!(windows) { "npm.cmd" } else { "npm" }, &["run", "check"]),
            "npm_test" => (if cfg!(windows) { "npm.cmd" } else { "npm" }, &["test"]),
            "npm_build" => (if cfg!(windows) { "npm.cmd" } else { "npm" }, &["run", "build"]),
            "cargo_check" => ("cargo", &["check"]),
            "git_diff" => ("git", &["diff", "--stat"]),
            "git_status" => ("git", &["status", "--short"]),
            _ => return Err("Unsupported project check.".into()),
        };
        let mut child = Command::new(program).args(args).current_dir(base)
            .stdin(Stdio::null()).stdout(Stdio::piped()).stderr(Stdio::piped())
            .spawn().map_err(|e| format!("Could not run {program}: {e}"))?;
        let stdout = child.stdout.take().ok_or("Child stdout could not be captured")?;
        let stderr = child.stderr.take().ok_or("Child stderr could not be captured")?;
        let (sender, receiver) = mpsc::channel::<(String, String)>();
        let reader = |mut pipe: Box<dyn Read + Send>, label: &'static str, sender: mpsc::Sender<(String, String)>| {
            thread::spawn(move || {
                let mut buffer = [0u8; 4096];
                while let Ok(n) = pipe.read(&mut buffer) {
                    if n == 0 { break; }
                    if sender.send((label.into(), String::from_utf8_lossy(&buffer[..n]).into_owned())).is_err() { break; }
                }
            })
        };
        let out_thread = reader(Box::new(stdout), "stdout", sender.clone());
        let err_thread = reader(Box::new(stderr), "stderr", sender);
        let mut output = String::new();
        let mut errors = String::new();
        let started = Instant::now();
        let mut completed = None;
        let mut timed_out = false;
        // A bounded 180s process lifetime is a safety property of the native
        // execution tool, not an LLM token or reasoning allowance.
        loop {
            while let Ok((stream, chunk)) = receiver.try_recv() {
                let target = if stream == "stderr" { &mut errors } else { &mut output };
                if target.len() < 80_000 {
                    let keep = chunk.len().min(80_000 - target.len());
                    // Avoid truncating UTF-8 between codepoints.
                    let mut boundary = keep;
                    while !chunk.is_char_boundary(boundary) { boundary -= 1; }
                    target.push_str(&chunk[..boundary]);
                }
                let _ = on_event.send(ProjectCheckStreamEvent { stream, chunk });
            }
            if let Some(status) = child.try_wait().map_err(|e| format!("Cannot check process: {e}"))? {
                completed = status.code();
                break;
            }
            if started.elapsed() >= Duration::from_secs(180) {
                timed_out = true;
                let _ = child.kill();
                let _ = child.wait();
                break;
            }
            thread::sleep(Duration::from_millis(60));
        }
        let _ = out_thread.join();
        let _ = err_thread.join();
        while let Ok((stream, chunk)) = receiver.try_recv() {
            let target = if stream == "stderr" { &mut errors } else { &mut output };
            if target.len() < 80_000 {
                let keep = chunk.len().min(80_000 - target.len());
                let mut boundary = keep;
                while !chunk.is_char_boundary(boundary) { boundary -= 1; }
                target.push_str(&chunk[..boundary]);
            }
            let _ = on_event.send(ProjectCheckStreamEvent { stream, chunk });
        }
        Ok(ProjectCheckResult { command: format!("{} {}", program, args.join(" ")),
            exit_code: completed, stdout: output, stderr: errors, timed_out })
    }).await.map_err(|e| format!("Project check worker failed: {e}"))?
}
