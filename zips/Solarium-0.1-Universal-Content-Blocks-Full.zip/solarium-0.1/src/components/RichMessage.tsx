import { useMemo, useRef, useState } from 'react';
import { Box, Button, Chip, Dialog, DialogContent, Stack, Typography } from '@mui/material';
import CloseRounded from '@mui/icons-material/CloseRounded';
import type { ChatAttachment, ChatSource, TerminalRun } from '../domain/types';
import type { ContentBlock } from '../blocks/protocol';
import { BlockStreamAssembler, groupCodeFiles } from '../blocks/protocol';
import { CodeCollection } from '../blocks/CodeCollection';
import { BlockCard } from '../blocks/BlockCard';
import { MarkdownBody } from './MarkdownBody';

/** Stable streaming blocks render from the entire accumulated answer; stream boundaries never close fences. */
export function RichMessage({ text, attachments = [], sources = [], assets = {}, terminalRuns = [], onOpenBlock, onSaveAsset }:
  { text: string; attachments?: ChatAttachment[]; sources?: ChatSource[]; assets?: Record<string, string>; terminalRuns?: TerminalRun[];
    onOpenBlock?: (block: ContentBlock) => void; onSaveAsset?: (block: ContentBlock) => void }) {
  const [lightbox, setLightbox] = useState<string | null>(null);
  const assembler = useRef(new BlockStreamAssembler());
  const parts = useMemo(() => {
    if (!text.startsWith(assembler.current.text)) assembler.current.reset();
    assembler.current.push(text.slice(assembler.current.text.length));
    return groupCodeFiles(assembler.current.snapshot());
  }, [text]);
  return <div className="rich-message">
    {parts.map((part, i) => part.type === 'markdown'
      ? <MarkdownBody key={`md-${i}`} text={part.text}/>
      : part.type === 'collection' ? <CodeCollection key={part.id} blocks={part.blocks} assets={assets} onOpen={onOpenBlock} onSaveAsset={onSaveAsset}/>
      : <BlockCard key={part.block.id} block={assets[part.block.id] !== undefined ? { ...part.block, content: assets[part.block.id]! } : part.block} onOpen={onOpenBlock} onSaveAsset={onSaveAsset}/>)}
    {terminalRuns.map((run, index) => <BlockCard key={`terminal-${index}`} block={{ id: `tool-terminal-${index}`, kind: 'terminal', title: `${run.command} · ${run.timedOut ? 'Timed out' : `Exit ${run.exitCode ?? 'unknown'}`}`, language: 'text', content: `${run.stdout}${run.stderr ? `\n[stderr]\n${run.stderr}` : ''}`, provenance: 'tool', status: 'complete' }} />)}
    {attachments.length > 0 && <div className="message-attachments">{attachments.map((attachment) => <div className="attachment-card" key={attachment.id}>
      {attachment.kind === 'image' && attachment.dataUrl ? <button className="attachment-image" onClick={() => setLightbox(attachment.dataUrl!)}><img src={attachment.dataUrl} alt={attachment.name} loading="lazy" /></button> : <span className="attachment-file-icon">▤</span>}
      <Stack minWidth={0}><Typography fontSize={11} fontWeight={700} noWrap>{attachment.name}</Typography><Typography fontSize={9} color="text.secondary">{attachment.kind} · {(attachment.size / 1024).toFixed(0)} KB</Typography></Stack>
    </div>)}</div>}
    {sources.length > 0 && <Box className="message-sources"><Typography fontSize={10.5} color="text.secondary" fontWeight={750} mb={.8}>Sources read or searched</Typography><Stack direction="row" gap={.6} flexWrap="wrap">{sources.map((s, i) => <Chip key={s.url + i} clickable component="a" href={s.url} target="_blank" rel="noopener noreferrer" size="small" variant="outlined" label={`${i + 1}. ${s.title || s.url}`} title={s.excerpt}/>)}</Stack></Box>}
    <Dialog open={Boolean(lightbox)} onClose={() => setLightbox(null)} maxWidth="xl"><DialogContent sx={{ position: 'relative', p: 1, bgcolor: '#111827' }}><Button onClick={() => setLightbox(null)} sx={{ position: 'absolute', right: 8, top: 8 }}><CloseRounded/></Button>{lightbox && <img src={lightbox} alt="Expanded attachment" className="image-lightbox"/>}</DialogContent></Dialog>
  </div>;
}
