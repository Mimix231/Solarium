# SPICA Canon Round Status — 2026-11-12

```yaml
canonical_input: "Solarium_SPICA_Phase07_TS2769_TS6133_Fixed.zip"
round: 8
phase: "08 — Evidence-Driven Research and Central Tool Discovery"
state: "implemented_focused_validation_passed_desktop_unverified"
legacy_schema: 1
universal_authoring_schema: 2
legacy_registry_modules: 26
runtime_registry_modules: 103
registry_categories_builtin: 35
catalog_capacity_proposed: 350000
warehouse_drafts_non_executable: true
central_registration: "SPICA callable tools included in codingToolDefinitions and central toolDefinitions; web research dispatches through existing ConversationResearch.run"
tool_vs_block_id: "spica.runtime.* IDs are block inputs, never callable tool names"
canonical_graph_reader: "read_spica_graph(view:schema1|v2|both)"
removed_callable: "read_spica_v2_graph"
tool_inspection: "list_solarium_tools (paged), inspect_solarium_tool, inspect_spica_identifier, inspect_spica_tool, check_spica_tool_call"
research_tools: 10
research_action_flow: "status -> explicit search -> read -> inspect links -> follow -> compare -> assess -> permissioned save -> stop"
hidden_research_provider_fallback: false
feature_specific_fallbacks: false
compatibility_argument_coercion: false
verified_checks:
  phase01: "12/12"
  phase02: "9/9"
  phase03: "12/12"
  phase04: "14/14"
  phase05: "10/10"
  phase06: "7/7"
  phase07: "13/13"
  phase08: "8/8"
  all_focused: "85/85"
  registry_legacy: pass
  registry_runtime: pass
  source_syntax: "428 source files parsed"
remaining_release_gate:
  - "Install frontend dependencies and run complete npm check, lint and production build"
  - "Run native Rust/Tauri compilation and full functional desktop tests"
  - "Test real GGUF Spark tool selections and permission UI"
  - "Test real external web provider, network and Source persistence"
  - "Standalone export/compiler for arbitrary V2 graphs remains future phase"
next_phase: "09 — Standalone Export"
```

See [Phase 08 implementation report](21_PHASE08_IMPLEMENTATION_REPORT.md) and [Tool Discovery and Research Protocol](22_PHASE08_TOOL_DISCOVERY_AND_RESEARCH_PROTOCOL.md).
