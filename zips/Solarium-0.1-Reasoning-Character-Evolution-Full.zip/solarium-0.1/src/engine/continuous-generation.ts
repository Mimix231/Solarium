import type { Capabilities, GenerationMetrics, LocalModel } from '../domain/types';
import type { InferenceAdapter } from './backends';
import { generationMetrics } from './backends';
import { createContinuationMessages, prepareGeneration, CHUNK_SIZE } from './context-window';
import { ModelContextError, type GenerationRequestOptions, type LlamaMessage, type LlamaTurnResult } from './llama';

/** Each request reuses an output allowance, NOT a newly loaded model or KV allocation. */
export const OUTPUT_SEGMENT_TOKENS = CHUNK_SIZE;

export interface ContinuousAnswerOptions {
  adapter: InferenceAdapter;
  model: LocalModel;
  capabilities: Capabilities;
  messages: LlamaMessage[];
  signal: AbortSignal;
  request?: GenerationRequestOptions;
  onAnswer(delta: string): void;
  onReasoning(delta: string): void;
  onReasoningState?(active: boolean): void;
  onMetrics?(metrics: GenerationMetrics): void;
}

export interface ContinuousAnswerResult {
  answer: string;
  result: LlamaTurnResult;
  segments: number;
  /** Inference-level limitation; already streamed content is always retained. */
  warning?: string;
}

/** True while a streamed prefix could be a repeat of the existing suffix. */
export function mayContinuePreviousSuffix(existing: string, incoming: string): boolean {
  const maximum = Math.min(1200, existing.length);
  if (incoming.length > maximum) return false;
  for (let length = maximum; length >= Math.max(8, incoming.length); length--) {
    if (existing.slice(-length).startsWith(incoming)) return true;
  }
  return false;
}

export function overlapLength(existing: string, incoming: string): number {
  const limit = Math.min(1200, existing.length, incoming.length);
  for (let count = limit; count >= 8; count--) {
    if (existing.endsWith(incoming.slice(0, count))) return count;
  }
  return 0;
}

/**
 * Stream one logical assistant turn, potentially containing many 2048-token
 * inference requests. Both reasoning and visible answer count as progress.
 * No artificial reasoning timeout, per-turn token ceiling or cycle counter.
 * The only exits are a server stop/tool call, cancellation, a real error, or
 * a server that says "length" but emits no tokens whatsoever.
 */
export async function streamContinuousAnswer(options: ContinuousAnswerOptions): Promise<ContinuousAnswerResult> {
  const { adapter, model, capabilities, messages, signal, request, onMetrics } = options;
  let answer = '';
  let reasoning = '';
  let segments = 0;
  let history = messages;
  let lastResult: LlamaTurnResult | undefined;
  let warning: string | undefined;
  let thinking = false;
  const setThinking = (active: boolean): void => {
    if (thinking === active) return;
    thinking = active;
    options.onReasoningState?.(active);
  };

  try {
    while (true) {
      if (signal.aborted) throw new DOMException('Stopped', 'AbortError');
      const answerBefore = answer.length;
      const reasoningBefore = reasoning.length;
      const started = performance.now();
      let firstToken: number | null = null;
      let answerPending = '';
      let reasoningPending = '';
      let checkingAnswerOverlap = segments > 0 && !!answer;
      let checkingThoughtOverlap = segments > 0 && !!reasoning;
      let lastChannel: 'reasoning' | 'answer' | null = null;
      const emitAnswerRaw = (delta: string): void => {
        if (!delta) return;
        answer += delta;
        options.onAnswer(delta);
      };
      const emitThoughtRaw = (delta: string): void => {
        if (!delta) return;
        reasoning += delta;
        options.onReasoning(delta);
      };
      const flushReasoning = (): void => {
        if (!reasoningPending) return;
        emitThoughtRaw(reasoningPending.slice(overlapLength(reasoning, reasoningPending)));
        reasoningPending = '';
        checkingThoughtOverlap = false;
      };
      const flushAnswer = (): void => {
        if (!answerPending) return;
        emitAnswerRaw(answerPending.slice(overlapLength(answer, answerPending)));
        answerPending = '';
        checkingAnswerOverlap = false;
      };
      const readReasoning = (delta: string): void => {
        if (!delta) return;
        if (firstToken === null) firstToken = performance.now();
        lastChannel = 'reasoning';
        setThinking(true);
        if (!checkingThoughtOverlap) { emitThoughtRaw(delta); return; }
        reasoningPending += delta;
        if (mayContinuePreviousSuffix(reasoning, reasoningPending)) return;
        flushReasoning();
      };
      const readAnswer = (delta: string): void => {
        if (!delta) return;
        if (firstToken === null) firstToken = performance.now();
        flushReasoning();
        lastChannel = 'answer';
        setThinking(false);
        if (!checkingAnswerOverlap) { emitAnswerRaw(delta); return; }
        answerPending += delta;
        if (mayContinuePreviousSuffix(answer, answerPending)) return;
        flushAnswer();
      };
      let extraHeadroom = 0;
      let activeCapabilities = capabilities;
      let result: LlamaTurnResult;
      for (let attempt = 0; ; attempt++) {
        const prepared = await prepareGeneration(adapter, model, activeCapabilities, history, signal, request, extraHeadroom);
        try {
          result = await adapter.generate(model, prepared.messages, activeCapabilities, {
            answer: readAnswer, reasoning: readReasoning,
          }, signal, { ...request, tools: prepared.tools, outputTokens: prepared.outputTokens });
          break;
        } catch (error) {
          // This retry is only for rejected requests, never for unfinished thought.
          if (!(error instanceof ModelContextError) || attempt >= 2 || answer.length !== answerBefore || reasoning.length !== reasoningBefore || signal.aborted) throw error;
          if (error.contextSize && error.contextSize > 0) {
            activeCapabilities = { ...activeCapabilities, contextSize: Math.min(prepared.contextSize, error.contextSize) };
          }
          extraHeadroom += Math.max(512, (error.promptTokens ?? prepared.promptTokens + 512) - prepared.promptTokens + 128);
        }
      }
      flushReasoning();
      flushAnswer();
      if (result.finishReason === 'content_filter') throw new Error('The inference backend stopped generation due to a content filter.');
      onMetrics?.(generationMetrics(adapter.kind, model.modelId, started, firstToken, performance.now(), result.answer,
        result.usage?.completionTokens));
      segments++;
      lastResult = result;
      if (result.calls.length || result.finishReason !== 'length') break;

      const answered = answer.length > answerBefore;
      const thought = reasoning.length > reasoningBefore;
      if (!answered && !thought) {
        warning = 'The backend reported a token-limit stop but emitted no new reasoning or answer tokens; the generated content was preserved.';
        break;
      }
      // A reasoning-only segment is *valid*, no matter how many times it occurs.
      // Preserve its real emitted contents in the next request, including when
      // the model has not yet produced a single character of visible answer.
      const continuingThought = lastChannel === 'reasoning' || (!answer.trim() && thought);
      history = createContinuationMessages(messages, answer, reasoning, continuingThought ? 'reasoning' : 'answer');
    }
  } finally {
    setThinking(false);
  }
  if (!lastResult) throw new Error('Inference returned no result.');
  return { answer, result: lastResult, segments, ...(warning ? { warning } : {}) };
}
