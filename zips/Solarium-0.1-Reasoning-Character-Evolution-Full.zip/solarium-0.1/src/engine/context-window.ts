import type { Capabilities, LocalModel } from '../domain/types';
import type { InferenceAdapter } from './backends';
import type { GenerationRequestOptions, LlamaMessage } from './llama';

/** A new request reuses an existing model; the output budget never increases its KV-cache capacity. */
export const CHUNK_SIZE = 2048;
export const CONTEXT_HEADROOM = 96;
export const MIN_OUTPUT = 64;

export interface PreparedGeneration {
  messages: LlamaMessage[];
  outputTokens: number;
  promptTokens: number;
  contextSize: number;
  discardedHistory: number;
  tokenCountSource: 'server' | 'estimate';
  tools: NonNullable<GenerationRequestOptions['tools']>;
}

export function effectiveContextSize(model: LocalModel, capabilities: Capabilities): number {
  const limits = [model.contextSize, capabilities.contextSize].filter((v): v is number => typeof v === 'number' && Number.isFinite(v) && v > 0);
  return Math.floor(Math.min(...(limits.length ? limits : [4096])));
}

export function conservativeTokenEstimate(messages: LlamaMessage[]): number {
  let tokens = 0;
  for (const message of messages) {
    // Conservative for mixed code/non-English text. Never treat a data URL as prompt text.
    tokens += 32 + message.role.length;
    if (typeof message.content === 'string') {
      tokens += Math.ceil(new TextEncoder().encode(message.content).length / 2);
    } else {
      for (const part of message.content) {
        tokens += part.type === 'text' ? Math.ceil(new TextEncoder().encode(part.text).length / 2) : 1400;
      }
    }
    if (message.tool_calls?.length) tokens += Math.ceil(new TextEncoder().encode(JSON.stringify(message.tool_calls)).length / 2);
  }
  return tokens + 32;
}

function latestUserIndex(messages: LlamaMessage[]): number {
  for (let i = messages.length - 1; i >= 0; i--) if (messages[i]?.role === 'user') return i;
  return -1;
}

function isOptionalSystem(message: LlamaMessage): boolean {
  return message.role === 'system' && typeof message.content === 'string' && /^(?:WEB RESEARCH MATERIAL|PROJECT INSTRUCTIONS) \(/.test(message.content);
}

/**
 * Fits a real inference request into the currently loaded model's context window.
 * - No chat-history deletion: only the temporary request gets pruned.
 * - The primary Spark instructions and user request are kept unchanged.
 * - Runtime tokenizer is preferred; we reserve template/output headroom even then.
 */
export async function prepareGeneration(
  adapter: InferenceAdapter,
  model: LocalModel,
  capabilities: Capabilities,
  original: LlamaMessage[],
  signal: AbortSignal,
  request: GenerationRequestOptions = {},
  extraHeadroom = 0,
): Promise<PreparedGeneration> {
  if (signal.aborted) throw new DOMException('Stopped', 'AbortError');
  if (!original.some((m) => m.role === 'user')) throw new Error('A user message is required for inference.');
  const contextSize = effectiveContextSize(model, capabilities);
  const headroom = CONTEXT_HEADROOM + Math.max(0, Math.floor(extraHeadroom));
  const messages = [...original];
  let discardedHistory = 0;
  let tools = [...(request.tools ?? [])];
  let source: 'server' | 'estimate' = 'estimate';
  const count = async (): Promise<number> => {
    if (signal.aborted) throw new DOMException('Stopped', 'AbortError');
    try {
      const tokens = await adapter.countTokens(model, messages, signal);
      if (tokens !== null && Number.isSafeInteger(tokens) && tokens >= 0) {
        source = 'server';
        return tokens + (tools.length ? Math.ceil(JSON.stringify(tools).length / 2) + 64 : 0);
      }
    } catch (error) {
      if (signal.aborted) throw error;
      // Older backends may not implement tokenizer APIs. Conservatively estimate instead.
    }
    source = 'estimate';
    return conservativeTokenEstimate(messages) + (tools.length ? Math.ceil(JSON.stringify(tools).length / 2) + 64 : 0);
  };
  let promptTokens = await count();

  // Prefer a full 2048-token generation allowance. Prune oldest nonessential
  // turns *before* trimming the model's recent answer or reducing that allowance.
  while (promptTokens + CHUNK_SIZE + headroom > contextSize) {
    const latestUser = latestUserIndex(messages);
    const hasContinuation = messages.some((m) => m.role === 'assistant' && typeof m.content === 'string' && /^(?:\[CONTINUATION TAIL\]|\[UNFINISHED REASONING TAIL\])\n/.test(m.content));
    const userIndexes = messages.flatMap((m, i) => m.role === 'user' ? [i] : []);
    const keepFrom = hasContinuation && userIndexes.length > 1 ? userIndexes[userIndexes.length - 2]! : latestUser;
    const oldest = messages.findIndex((message, index) => index < keepFrom && message.role !== 'system');
    if (oldest < 0) break;
    // Drop one historical turn at a time; never remove the most recent user prompt.
    messages.splice(oldest, 1);
    discardedHistory++;
    promptTokens = await count();
  }

  // Optional research and project snippets can be left out of THIS request.
  // They remain intact in workspace/project storage.
  while (promptTokens + CHUNK_SIZE + headroom > contextSize) {
    const optional = messages.findIndex(isOptionalSystem);
    if (optional < 0) break;
    messages.splice(optional, 1);
    discardedHistory++;
    promptTokens = await count();
  }

  // Continuation responses can exceed the entire context size. Shrink only the
  // temporary assistant tail, never the persona or the original user request.
  const tailIndex = messages.findIndex((message) => message.role === 'assistant' && typeof message.content === 'string' && /^(?:\[CONTINUATION TAIL\]|\[UNFINISHED REASONING TAIL\])\n/.test(message.content));
  if (tailIndex >= 0) {
    const marker = (messages[tailIndex]!.content as string).startsWith('[UNFINISHED REASONING TAIL]')
      ? '[UNFINISHED REASONING TAIL]\n' : '[CONTINUATION TAIL]\n';
    const current = messages[tailIndex]!;
    let tailText = (current.content as string).slice(marker.length);
    while (promptTokens + CHUNK_SIZE + headroom > contextSize && tailText.length > 192) {
      tailText = tailText.slice(-Math.max(192, Math.floor(tailText.length * 0.65)));
      messages[tailIndex] = { ...current, content: `${marker}${tailText}` };
      promptTokens = await count();
    }
  }

  // Tool schemas are optional for answering an ordinary message. If they cannot
  // fit alongside the essential prompt, omit tool definitions for this request.
  if (promptTokens + MIN_OUTPUT + headroom > contextSize && tools.length) {
    tools = [];
    promptTokens = await count();
  }
  const outputTokens = Math.min(CHUNK_SIZE, contextSize - promptTokens - headroom);
  if (outputTokens < MIN_OUTPUT) {
    throw new Error(
      `The active model has a ${contextSize}-token context window, but essential Spark instructions and the latest request need about ${promptTokens} tokens. ` +
      'Increase the loaded model context (and restart its inference server), or shorten the latest request/personality. Older chat turns were already excluded from this inference request.',
    );
  }
  return { messages, outputTokens, promptTokens, contextSize, discardedHistory, tokenCountSource: source, tools };
}

/**
 * Next request reuses the same loaded model and bounded context. Maintain the
 * model's *actual* reasoning tail when generation hit a limit mid-thought.
 * This is a best-effort reconstruction: OpenAI-compatible chat endpoints do
 * not promise that an unfinished internal inference state can be resumed.
 * Never invent a reasoning string or discard the latest actual user input.
 */
export function createContinuationMessages(
  original: LlamaMessage[], answer: string, reasoning = '', phase: 'reasoning' | 'answer' = 'answer',
): LlamaMessage[] {
  const systems = original.filter((m) => m.role === 'system');
  const user = [...original].reverse().find((m) => m.role === 'user');
  if (!user) throw new Error('Cannot continue without a user request.');
  const unfinishedReasoning = phase === 'reasoning' && !!reasoning.trim();
  const contextTail = unfinishedReasoning
    ? `[UNFINISHED REASONING TAIL]\n${reasoning.slice(-24000)}`
    : `[CONTINUATION TAIL]\n${answer.slice(-24000)}`;
  const direction = unfinishedReasoning
    ? 'Your previous reasoning was interrupted by the inference request token boundary. Continue working from the unfinished reasoning above, and then answer the original user request. Do not restart your reasoning or repeat prior content.'
    : 'Continue the previous answer exactly where it stopped. Do not repeat, restart or introduce it again. Stop naturally when finished.';
  return [...systems, user, { role: 'assistant', content: contextTail }, { role: 'user', content: direction }];
}
