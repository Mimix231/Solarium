# Solarium 0.1 — Seamless Continuation, Thinking and Relevant Web Research

## What changed

- Chat generation requests use a **reusable maximum of 2,048 completion tokens per request**. No output-mode selector, Yes/No continuation dialog, or manual "Continue" action.
- `streamLlamaTurn()` captures **`finish_reason`** (`stop`, `length`, `tool_calls`, `content_filter`, `unknown`), reasoning text, tool calls and usage. It does not confuse `stream: [DONE]` with the finish reason.
- `streamContinuousAnswer()` restarts **only** on `length`, keeps the same connected backend and loaded model, and streams one visible message. It stops on natural completion, cancellation, context errors, or no-progress loops. Native reasoning can reappear on any continuation; it is never simulated.
- Each continuation request keeps the Spark system instruction, the latest user request and a bounded tail of the existing answer, so the request will not append an ever-growing entire response to the input context. This is a minimal safety measure, **not** a semantic memory-reconstruction feature.
- The existing local model server is reused: **no new process, weights, or model instance is started for each 2,048-token segment**. Whether context caching works and how much GPU memory is reserved still depends on the runtime.
- The former Max Tokens box in Models is replaced by an informational fixed-segment label; the stored `maxTokens` field is retained solely for backward compatibility and unrelated model tests.
- The compact theme-aware **Thinking** strip appears inside the assistant message. It accumulates genuine model-supplied `reasoning_content` or `<think>` segments and shows one formatted duration. It **never shows cycle labels**. For models with no reasoning output, it shows a truthful **Generating** timer instead.
- Generated thoughts (when the model exposes them) can be expanded, and are saved with the assistant message locally. No external reasoning endpoint is used.
- The Web Search switch gates automatic research **and** available model-callable web tools. A native tool that somehow gets invoked while Web is off is denied even if a global tool preference was set to `allow`.
- Research searches for the user's **software-development objective**, e.g. *video editing app with Rust and Tauri*, instead of blindly submitting conversational prose. Cinema/showtime results are filtered from software results.
- UI chat text and reasoning use animation-frame batching so long streamed answers do not force one full Markdown rerender per token.

## Relevant code

| Responsibility | File or symbol |
| --- | --- |
| Single backend request | `streamLlamaTurn()` in `src/engine/llama.ts` |
| Continuous generation | `streamContinuousAnswer()` / `continuationMessages()` in `src/engine/continuous-generation.ts` |
| Shared adapter interface | `InferenceAdapter.generate()` in `src/engine/backends.ts` |
| Reasoning & tool integration | `runAgent()` in `src/engine/agent.ts` |
| Research objective extraction | `buildSearchIntent()` in `src/engine/search-intent.ts` |
| Research result filtering | `rankResearchResults()` in `src/engine/search-intent.ts` |
| Permissions | `allowedToolDefinitions()` in `src/engine/tools.ts` |
| Thinking display | `ThinkingPanel()` in `src/components/ThinkingPanel.tsx` |
| Persist raw model reasoning | `ChatMessage.reasoning` and `validateMessage()` |

## Important limitations

1. **2,048 tokens is an output ceiling, not a fixed VRAM block.** The model's weights load once, but the KV cache, context window and inference engine still control memory. New continuation requests may recompute prompt tokens. Exactly flat GPU memory and throughput are not guaranteed.
2. **Reasoning tokens may count toward the 2,048-token allowance.** Some reasoning-capable models may spend most of a segment on thinking, leaving little visible answer. The no-progress guard eventually reports this instead of looping forever.
3. **A finite context window cannot support perfect infinite memory.** Very long answers may lose earlier details when the tail moves forward. Repeated continuation prompts can still cause stylistic discontinuity or repetition. The controller removes exact overlapping prefixes where feasible but cannot guarantee flawless coherence.
4. **The server must distinguish natural completion from the length limit.** Without a `finish_reason`, Solarium does not guess that a response must continue. The Activity panel explicitly notes that completeness is uncertain.
5. Web research quality remains limited by the public search provider. Query extraction and filtering are deterministic, local and conservative, not a new planning or context-management agent.
6. Local model reasoning is **model- and chat-template-dependent**; text without an exposed reasoning channel is not invented.
7. User-approved tool execution remains permission-gated. Changing web toggle or permissions mid-response is not supported; permissions are checked against the active request state.

## Verification

From the extracted project root, after `npm install`:

`npm run check`  
`npm run lint`  
`npm run build`  
`npm test`  
`npm run desktop:dev`

For actual hardware validation, load a local GGUF on your RTX 3060. Ask for a response longer than 2,048 tokens and inspect the model's `/v1/chat/completions` finish reasons and VRAM in `nvidia-smi`. Test with a model that emits `reasoning_content`, one that emits `<think>` tags, and one without reasoning. Try both llama.cpp and vLLM separately and together only if VRAM allows.
