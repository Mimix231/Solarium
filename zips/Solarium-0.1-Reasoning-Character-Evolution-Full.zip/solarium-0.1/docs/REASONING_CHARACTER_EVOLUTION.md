# Solarium 0.1 — Reasoning & Character Evolution

This patch builds on **Rendering Engine 2.0**. It does not modify engine installation paths, saved chats, GGUF file locations, themes, or runtime binaries.

## Reusable inference allowance

- `src/engine/continuous-generation.ts` keeps one local model/server endpoint and requests at most **2,048 output tokens per request**. The allowance is reused on every subsequent request; it is **not** a total answer or reasoning limit.
- A segment that streams only native reasoning or text from `<think>` is valid progress. The old arbitrary **two empty-answer-segment** failure rule was removed. Reasoning can span any number of successful streaming requests.
- The accumulated real reasoning text is passed to `createContinuationMessages()` when a request hits its token boundary before the answer phase. The next prompt contains the real previous reasoning tail, not fabricated activity text. Once the model streams an answer, continuation carries forward the answer tail.
- `streamLlamaTurn()` now returns `reasoning` and `reasoningOpen` as well as the normal response and finish reason. `ReasoningSplitter` exposes whether a textual thought region was still open.
- The existing compact **Thinking** panel remains the sole viewer. No chunk or cycle cards, output-mode toggles, manual Continue buttons, or additional reasoning budgets were added.
- A server that explicitly finishes the request is respected. If a server claims an output-limit stop but sends **no new reasoning or answer data**, the app preserves generated content and issues an explicit diagnostic rather than spinning endlessly on an empty stream. Cancellation and true context/hardware errors also remain observable.

### Inference limitation

This implementation **does not load a second model** between segments. However, the OpenAI-compatible `chat/completions` interface does not offer portable snapshot-and-resume of a model's unfinished hidden KV state; passing the prior *model-emitted* reasoning to a new request is a best-effort continuation strategy. It is not equivalent to native in-place resumption for every GGUF/chat template. Model weights are reused, while GPU KV-cache usage remains governed by the server context configuration. A 2,048-token output allowance is not an 8 GB memory allocation that can be reset to free the same number of bytes.

## Spark Avatar Studio

- `src/avatar/layer-system.ts`: stable back-to-front layer registry and independently adjustable visibility, position, and scale. The registry prevents user-provided layer keys from injecting arbitrary SVG operations.
- `src/components/AvatarDetails.tsx`: reusable detailed irises, hair, clothing highlights and expression overlay artwork.
- `src/components/AvatarEvolutionControls.tsx`: compact **Art Styles**, **Layers**, and per-expression customization panels, keeping `AvatarStudio.tsx` reasonably focused.
- `src/components/AnimeAvatar.tsx`: integrated layered illustration rendering. New **Modern Anime**, **Classic Cel**, and **Chibi** rendering modes vary face/eye proportions, silhouette, lineweight and material treatment (not just colors).
- More hairstyle, fringe, side-hair, eye, iris, pupil, outfit, hat/mask, and accessory variants. Left and right irises can have different colors.
- Expression-specific mouth, eye shape, eyebrow and blush overrides; these are saved on the Spark. Existing expression-image imports, PNG export, undo/redo, and locally rendered blinking continue to work.
- Avatar preset export now writes `solarium-anime-avatar-v2`. The importer accepts **both v1 and v2**. Workspace validation migrates avatars without deleting existing selections.

### Artwork scope

Characters are detailed **editable 2D vector portraits**. They are not externally generated full-body anime illustrations, Live2D meshes, or character rigs. More asset packs can be introduced without changing the serialized layer schema.

## Suggested local verification

From the Solarium root in PowerShell:

1. `npm install`
2. `npm test`
3. `npm run check`
4. `npm run build`
5. `npm run lint`
6. `npm run desktop:dev`

On your RTX 3060, test a reasoning model producing **at least three reasoning-only 2,048-token requests** before answering. Confirm one visible Thinking panel, then a completed message. Verify output remains visible on Stop or a backend error. Check peak VRAM with `nvidia-smi`: actual memory behavior depends on the loaded GGUF, context window and the backend.

In Avatar Studio, test all three art styles, layer visibility, layer transforms, heterochromia, masks over facial features, and importing a previously exported v1 preset.

## Test status in the build environment

Available automated Node/TypeScript tests, source syntax checks, focused React/TSX semantic checks using temporary dependency stubs, and SVG raster smoke renders passed. This environment cannot install npm frontend dependencies or compile Rust/Tauri, and it has no RTX 3060; **a full Windows build and live local inference remain unverified**.
