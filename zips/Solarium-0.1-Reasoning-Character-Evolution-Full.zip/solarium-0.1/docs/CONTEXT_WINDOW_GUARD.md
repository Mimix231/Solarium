# Solarium 0.1 — Context Window Guard & Continuous Queue 2.0

## What changed

The error `request (5105 tokens) exceeds the available context size (4096 tokens)` described a **prompt** that was already too large for the loaded model. A 2,048-token output budget is independent of the model's total context size. Resetting the output budget cannot make an oversized prompt fit.

Before **every** inference request, including the very first message and every automatic continuation, Solarium now runs `prepareGeneration()` from `src/engine/context-window.ts`.

The context guard:

1. Uses the **smaller** of the model's configured and server-reported context sizes. This avoids trusting an outdated UI context setting.
2. Attempts **backend-native token counting**: llama.cpp `/apply-template` followed by `/tokenize`; vLLM `/tokenize` with chat messages. If unavailable, it uses a conservative UTF-8 estimate. Server-side counting is still not a guarantee for every multimodal/tool template, so the engine retains error recovery.
3. Reserves additional tokens for chat-template/tool overhead and a positive output allowance.
4. Removes **older conversation turns from the inference payload only** until a 2,048-token allowance fits, preserving the Spark's system identity and latest user request. Stored chat history is untouched.
5. If necessary, excludes optional web extracts or project hints **from that one request**, without removing them from user storage.
6. On continuation, keeps a recent suffix of the already-streamed answer, trims it to the active window, and includes the original user request and Spark instructions.
7. If all essential text fits but 2,048 new tokens would not, issues a **smaller output segment**, then automatically continues when the backend reports `finish_reason: length`.
8. If the essential user prompt and Spark instructions cannot fit even with a small output allowance, reports a clear error instructing the user to increase `n_ctx` / `--max-model-len` or shorten that essential input.
9. If llama.cpp/vLLM returns a context-overflow HTTP 400 despite preflight sizing, retries preflight (at most twice) with additional reserve based on the **reported prompt size**. It only retries if no answer tokens have been streamed, to avoid duplicating visible output.

## Continuous streaming

One visible assistant message is streamed while internal requests each receive **up to** 2,048 output tokens. Reaching that limit starts another request automatically. When the backend stops normally, Solarium finishes. The existing loaded model is reused — it is **not loaded again** between segments.

This does **not** make the KV context unlimited, magically free old tokens, or guarantee perfectly flat VRAM allocation. The runtime manages a bounded cache according to its actual context configuration. When the continuation context no longer fits, Solarium drops older content from the *temporary request*; the model can no longer attend to what was dropped.

Users do not see internal segment cards, control modes or queue buttons. Existing Stop, Thinking, Spark voice, message streaming and Ollama/vLLM/llama.cpp selection remain unchanged.

## Relevant modules

- `src/engine/context-window.ts`: `prepareGeneration()`, `createContinuationMessages()`, `effectiveContextSize()`.
- `src/engine/llama.ts`: `countInputTokens()`, `ModelContextError`, `streamLlamaTurn()`.
- `src/engine/backends.ts`: `InferenceAdapter.countTokens()`.
- `src/engine/continuous-generation.ts`: `streamContinuousAnswer()`.
- `src/engine/agent.ts`: system / optional project / optional research prompt composition.
- `tests/context-window.test.cjs`: context-overflow, tokenizer, streaming and retry regression tests.

## Limitations

- Native counting is most reliable for text-only llama.cpp chat templates. Image/media token allocation and tool-specific rendering can differ from standalone tokenizer counts. The automatic safety reserve and HTTP 400 recovery compensate where possible.
- Some vLLM deployments do not enable or support chat-mode `/tokenize`; fallback estimation is then used.
- Continuing on length can be slower than one uninterrupted generation because another request may need to process the prompt again. Prompt caching depends on the inference backend.
- A model may repeat or change direction after older tokens have been excluded. No memory reconstruction or advanced summarization is included here, as requested.

## Verification on Windows

From your Solarium folder:

```powershell
npm install
npm run check
npm run lint
npm run build
npm test
npm run desktop:dev
```

Test first with a long existing conversation on a model configured for a 4,096-token context, then a response that spans more than 2,048 tokens. Check that the model continues without an HTTP 400, the chat shows only one answer, Stop interrupts correctly and VRAM remains within the configured runtime's normal model/cache footprint. If essential instructions genuinely exceed the context, increase the model/server context setting and restart the inference server.
