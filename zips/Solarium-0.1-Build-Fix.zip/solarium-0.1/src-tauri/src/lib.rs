use std::fs::{self, File};
use std::io::Write;
use std::path::Path;
use std::process::{Child, Command, Stdio};
use std::sync::Mutex;
use std::thread;
use std::time::Duration;
use serde::Serialize;
use tauri::{Manager, State};

mod runtime;
mod llama_installer;
mod gguf_catalog;
mod install_jobs;
use install_jobs::{InstallJob, InstallJobs};
use runtime::{ensure_runtime_dir, runtime_dir};

#[derive(Default)]
struct EngineProcesses {
    llama: Mutex<Option<Child>>,
    llama_model: Mutex<Option<String>>,
    llama_port: Mutex<Option<u16>>,
    vllm: Mutex<Option<Child>>,
}

impl Drop for EngineProcesses {
    fn drop(&mut self) {
        for slot in [&self.llama, &self.vllm] {
            if let Ok(mut guard) = slot.lock() {
                if let Some(mut process) = guard.take() {
                    let _ = process.kill();
                    let _ = process.wait();
                }
            }
        }
    }
}

fn start_managed(slot: &Mutex<Option<Child>>, command: &mut Command, label: &str, log_path: &Path) -> Result<String, String> {
    let mut guard = slot.lock().map_err(|_| "Engine lock unavailable")?;
    if let Some(child) = guard.as_mut() {
        if child.try_wait().map_err(|e| e.to_string())?.is_none() {
            return Err(format!("A Solarium-managed {label} server is already running."));
        }
    }
    if let Some(folder) = log_path.parent() { fs::create_dir_all(folder).map_err(|e| e.to_string())?; }
    let stdout = File::create(log_path).map_err(|e| e.to_string())?;
    let stderr = stdout.try_clone().map_err(|e| e.to_string())?;
    let process = command.stdin(Stdio::null()).stdout(Stdio::from(stdout)).stderr(Stdio::from(stderr))
        .spawn().map_err(|e| format!("Unable to start {label}: {e}"))?;
    let pid = process.id();
    *guard = Some(process);
    Ok(format!("Started {label} (PID {pid}). Check the endpoint after model loading completes. Log: {}", log_path.display()))
}

fn stop_managed(slot: &Mutex<Option<Child>>, label: &str) -> Result<String, String> {
    let mut guard = slot.lock().map_err(|_| "Engine lock unavailable")?;
    match guard.take() {
        Some(mut process) => {
            let _ = process.kill();
            let _ = process.wait();
            Ok(format!("Stopped Solarium-managed {label} process."))
        }
        None => Err(format!("No Solarium-managed {label} process is running.")),
    }
}

#[tauri::command]
fn start_llama_server(
    state: State<'_, EngineProcesses>, executable: String, gguf: String,
    port: u16, context: u32, gpu_layers: i32,
) -> Result<String, String> {
    let path = Path::new(&executable);
    let model = Path::new(&gguf);
    if !path.is_file() { return Err("llama-server executable does not exist.".into()); }
    if !model.is_file() || !model.extension().and_then(|x| x.to_str()).is_some_and(|x| x.eq_ignore_ascii_case("gguf")) {
        return Err("Select an existing GGUF model file.".into());
    }
    let filename = path.file_stem().and_then(|s| s.to_str()).unwrap_or("").to_lowercase();
    if filename != "llama-server" { return Err("Only an executable named llama-server may be launched.".into()); }
    if port < 1024 || context < 256 || context > 262_144 || !(-1..=999).contains(&gpu_layers) {
        return Err("Invalid port, GPU layers, or context length.".into());
    }
    let mut command = Command::new(path);
    command.args(["-m", &gguf, "--host", "127.0.0.1", "--port", &port.to_string(),
        "-c", &context.to_string(), "--n-gpu-layers", &gpu_layers.to_string(), "--no-webui"]);
    if let Some(folder) = path.parent() { command.current_dir(folder); }
    let log = ensure_runtime_dir()?.join("logs/llama.log");
    let outcome = start_managed(&state.llama, &mut command, "llama.cpp", &log)?;
    *state.llama_model.lock().map_err(|_| "Model state lock unavailable")? = Some(gguf);
    *state.llama_port.lock().map_err(|_| "Engine port lock unavailable")? = Some(port);
    Ok(outcome)
}

#[tauri::command]
fn stop_llama_server(state: State<'_, EngineProcesses>) -> Result<String, String> {
    let result = stop_managed(&state.llama, "llama.cpp");
    *state.llama_model.lock().map_err(|_| "Model state lock unavailable")? = None;
    *state.llama_port.lock().map_err(|_| "Engine port lock unavailable")? = None;
    result
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct ModelActivation { model_id: String, detail: String }

/// A catalog selection *actually loads* its GGUF before a conversation uses it.
/// A successful return requires an online `/v1/models` response; errors never
/// masquerade as a selected model. This replaces old single-server state.
fn activate_gguf_model_inner(state: &EngineProcesses, executable: String, gguf: String,
    port: u16, context: u32, gpu_layers: i32) -> Result<ModelActivation, String> {
    if !Path::new(&executable).is_file() ||
       Path::new(&executable).file_stem().and_then(|s| s.to_str()) != Some("llama-server") {
        return Err("Install llama.cpp or choose llama-server.exe in Models first.".into());
    }
    if !Path::new(&gguf).is_file() || !Path::new(&gguf).extension().and_then(|s| s.to_str()).is_some_and(|s| s.eq_ignore_ascii_case("gguf")) {
        return Err("GGUF file is missing. Rescan your configured model folder.".into());
    }
    if port < 1024 || !(256..=262_144).contains(&context) || !(-1..=999).contains(&gpu_layers) {
        return Err("Invalid llama.cpp runtime settings.".into());
    }
    let same = state.llama_model.lock().map_err(|_| "Model state lock unavailable")?
        .as_deref() == Some(gguf.as_str()) &&
        *state.llama_port.lock().map_err(|_| "Engine port lock unavailable")? == Some(port);
    let alive = {
        let mut child = state.llama.lock().map_err(|_| "Engine state lock unavailable")?;
        child.as_mut().is_some_and(|c| c.try_wait().ok().flatten().is_none())
    };
    if !(same && alive) {
        let current_port = *state.llama_port.lock().map_err(|_| "Engine port lock unavailable")?;
        if std::net::TcpStream::connect_timeout(&format!("127.0.0.1:{port}").parse().map_err(|e| format!("Invalid port: {e}"))?, Duration::from_millis(500)).is_ok() && !(alive && current_port == Some(port)) {
            return Err(format!("Port {port} is already in use. Stop the existing server or choose another port in Models."));
        }
        if alive { let _ = stop_managed(&state.llama, "llama.cpp"); }
        let mut command = Command::new(&executable);
        command.args(["-m", &gguf, "--host", "127.0.0.1", "--port", &port.to_string(),
            "-c", &context.to_string(), "--n-gpu-layers", &gpu_layers.to_string(), "--no-webui"]);
        if let Some(folder) = Path::new(&executable).parent() { command.current_dir(folder); }
        start_managed(&state.llama, &mut command, "llama.cpp", &ensure_runtime_dir()?.join("logs/llama.log"))?;
        *state.llama_model.lock().map_err(|_| "Model state lock unavailable")? = Some(gguf.clone());
        *state.llama_port.lock().map_err(|_| "Engine port lock unavailable")? = Some(port);
    }
    let client = reqwest::blocking::Client::builder().timeout(Duration::from_secs(3))
        .build().map_err(|e| e.to_string())?;
    let url = format!("http://127.0.0.1:{port}/v1/models");
    for _ in 0..90 {
        if let Ok(response) = client.get(&url).send() {
            if let Ok(response) = response.error_for_status() {
                if let Ok(body) = response.json::<serde_json::Value>() {
                    if let Some(identifier) = body.get("data").and_then(|v| v.as_array())
                        .and_then(|v| v.first()).and_then(|v| v.get("id")).and_then(|v| v.as_str()) {
                        return Ok(ModelActivation { model_id: identifier.to_owned(),
                            detail: format!("llama.cpp is ready with {}", Path::new(&gguf).file_name().and_then(|name| name.to_str()).unwrap_or("model")) });
                    }
                }
            }
        }
        let exited = {
            let mut child = state.llama.lock().map_err(|_| "Engine state lock unavailable")?;
            child.as_mut().is_some_and(|c| c.try_wait().ok().flatten().is_some())
        };
        if exited { break; }
        thread::sleep(Duration::from_secs(1));
    }
    let _ = stop_managed(&state.llama, "llama.cpp");
    *state.llama_model.lock().map_err(|_| "Model state lock unavailable")? = None;
    *state.llama_port.lock().map_err(|_| "Engine port lock unavailable")? = None;
    Err("llama.cpp failed to become ready within 90 seconds. Check Models → View logs for DLL, CUDA or memory errors.".into())
}

#[tauri::command]
async fn activate_gguf_model(app: tauri::AppHandle, executable: String, gguf: String,
    port: u16, context: u32, gpu_layers: i32) -> Result<ModelActivation, String> {
    // Loading a GGUF may take tens of seconds. Never hold up Tauri's UI thread.
    tauri::async_runtime::spawn_blocking(move || {
        let engines = app.state::<EngineProcesses>();
        activate_gguf_model_inner(&engines, executable, gguf, port, context, gpu_layers)
    }).await.map_err(|e| e.to_string())?
}

#[tauri::command]
fn start_vllm_server(
    state: State<'_, EngineProcesses>, distro: String, model: String,
    port: u16, context: u32, gpu_memory_utilization: f32,
) -> Result<String, String> {
    if !cfg!(target_os = "windows") { return Err("WSL2 launch is currently supported on Windows hosts only. On Linux, start vLLM manually and register its endpoint.".into()); }
    if distro.is_empty() || !distro.chars().all(|c| c.is_ascii_alphanumeric() || "._-".contains(c)) {
        return Err("Invalid WSL distribution name.".into());
    }
    if model.is_empty() || model.len() > 400 || model.starts_with('-') || model.chars().any(char::is_control) {
        return Err("Enter a valid Hugging Face model ID or Linux model path.".into());
    }
    if !(1024..=65535).contains(&port) || !(512..=65_536).contains(&context) ||
        !gpu_memory_utilization.is_finite() || !(0.2..=0.7).contains(&gpu_memory_utilization) {
        return Err("Invalid port, context size, or GPU memory fraction.".into());
    }
    // Explicit arguments rather than a shell: model names and paths are not executed as code.
    let managed = "Solarium-vLLM";
    let linux_runtime = "/opt/solarium";
    let venv_binary = format!("{linux_runtime}/vllm/venv/bin/vllm");
    let installed = Command::new("wsl.exe").args(["-d", managed, "--", "test", "-x", &venv_binary])
        .status().is_ok_and(|status| status.success());
    if !installed {
        return Err(format!("vLLM is not installed in {linux_runtime}/vllm/venv. Run Install vLLM in WSL2 first."));
    }
    // WSL receives separate arguments. No shell interpolation of model IDs or Windows paths.
    let mut command = Command::new("wsl.exe");
    command.args(["-d", managed, "--", "env"])
        .arg(format!("HF_HOME={linux_runtime}/huggingface"))
        .arg(format!("XDG_CACHE_HOME={linux_runtime}/cache"))
        .arg(format!("VLLM_CACHE_ROOT={linux_runtime}/cache/vllm"))
        .arg(format!("CUDA_CACHE_PATH={linux_runtime}/cache/cuda"))
        .arg(format!("TRITON_CACHE_DIR={linux_runtime}/cache/triton"))
        .arg(format!("TMPDIR={linux_runtime}/tmp"))
        .arg(&venv_binary)
        .args(["serve", &model, "--host", "127.0.0.1", "--port", &port.to_string(),
            "--max-model-len", &context.to_string(),
            "--gpu-memory-utilization", &gpu_memory_utilization.to_string()]);
    let log = ensure_runtime_dir()?.join("logs/vllm.log");
    start_managed(&state.vllm, &mut command, "vLLM (WSL2)", &log)
}

#[tauri::command]
fn stop_vllm_server(state: State<'_, EngineProcesses>) -> Result<String, String> {
    let result = stop_managed(&state.vllm, "vLLM (WSL2)");
    if cfg!(target_os = "windows") {
        // WSL2 is a separate Linux VM. Killing wsl.exe does not reliably terminate
        // the forwarded Linux service. The managed distro is dedicated to Solarium.
        let _ = Command::new("wsl.exe").args(["--terminate", "Solarium-vLLM"]).status();
    }
    result
}

fn install_vllm_into_wsl(distro: String, progress: impl Fn(&str), cancelled: impl Fn() -> bool) -> Result<String, String> {
    if !cfg!(target_os = "windows") { return Err("WSL installer is available on Windows only.".into()); }
    if distro.is_empty() || !distro.chars().all(|c| c.is_ascii_alphanumeric() || "._-".contains(c)) {
        return Err("Invalid WSL distribution name.".into());
    }
    if cancelled() { return Err("Installation cancelled".into()); }
    progress("Checking managed vLLM WSL2 distro");
    let managed = "Solarium-vLLM";
    let root = ensure_runtime_dir()?;
    let vhd_folder = root.join("wsl").join(managed);
    // wsl --export/--import avoids a Python environment on /mnt/c (NTFS).
    // The managed distro's ext4.vhdx is stored next to Solarium on its drive.
    if !Command::new("wsl.exe").args(["-d", managed, "--", "true"]).status()
        .is_ok_and(|status| status.success()) {
        fs::create_dir_all(&vhd_folder).map_err(|e| e.to_string())?;
        let archive = root.join("wsl").join("source-export.tar");
        if cancelled() { return Err("Installation cancelled".into()); }
        progress("Exporting source Ubuntu distribution (may require several GB)");
        let exported = Command::new("wsl.exe").arg("--export").arg(&distro).arg(&archive)
            .status().map_err(|e| format!("Unable to export {distro}: {e}"))?;
        if !exported.success() { return Err(format!("WSL could not export the installed '{distro}' distro. Install Ubuntu in WSL2 first and ensure there is enough drive space.")); }
        if cancelled() { let _ = fs::remove_file(&archive); return Err("Installation cancelled".into()); }
        progress("Importing private Linux filesystem to ./runtime/wsl");
        let imported = Command::new("wsl.exe").arg("--import").arg(managed).arg(&vhd_folder).arg(&archive)
            .args(["--version", "2"]).status().map_err(|e| format!("WSL import failed: {e}"))?;
        let _ = fs::remove_file(archive);
        if !imported.success() { return Err(format!("WSL could not create the Solarium-vLLM distro in {}", vhd_folder.display())); }
    }
    if cancelled() { return Err("Installation cancelled".into()); }
    progress("Installing and verifying vLLM inside managed Linux environment");
    let mut child = Command::new("wsl.exe").args(["-d", managed, "--", "bash", "-s", "--", "/opt/solarium"])
        .stdin(Stdio::piped()).stdout(Stdio::piped()).stderr(Stdio::piped())
        .spawn().map_err(|e| format!("Unable to reach WSL2: {e}"))?;
    let script = include_bytes!("../../scripts/install-vllm-wsl.sh");
    child.stdin.take().ok_or("Unable to send installer script")?.write_all(script).map_err(|e| e.to_string())?;
    let output = child.wait_with_output().map_err(|e| e.to_string())?;
    if cancelled() { return Err("Installation cancelled after WSL installation stage".into()); }
    if !output.status.success() {
        // pip frequently writes the useful failure to stdout, not stderr.
        let stdout = String::from_utf8_lossy(&output.stdout);
        let stderr = String::from_utf8_lossy(&output.stderr);
        let stdout_tail: String = stdout.chars().rev().take(1000).collect::<String>().chars().rev().collect();
        let stderr_tail: String = stderr.chars().rev().take(1600).collect::<String>().chars().rev().collect();
        return Err(format!("vLLM installation failed (exit {}): {} {}", output.status, stderr_tail, stdout_tail));
    }
    progress("Verified vLLM installation");
    Ok(format!("vLLM installed inside the Solarium-vLLM WSL2 distro. Its ext4 virtual disk is under {}/wsl/Solarium-vLLM; Linux environment: /opt/solarium/vllm/venv.", ensure_runtime_dir()?.display()))
}

#[tauri::command]
fn cancel_install_job(app: tauri::AppHandle, jobs: State<'_, InstallJobs>, id: String) -> Result<(), String> {
    jobs.request_cancel(&app, &id)
}

#[tauri::command]
fn get_install_jobs(state: State<'_, InstallJobs>) -> Vec<InstallJob> { state.list() }

/// Returns immediately with a job ID; actual installation is owned by Rust,
/// not by a mounted React component or an awaited browser event listener.
#[tauri::command]
fn start_install_job(app: tauri::AppHandle, jobs: State<'_, InstallJobs>, engine: String,
                     cuda: Option<bool>, distro: Option<String>) -> Result<String, String> {
    if engine != "llama.cpp" && engine != "vllm" { return Err("Unknown installer engine".into()); }
    let id = jobs.begin(&engine)?;
    let manager = (*jobs).clone();
    let job_id = id.clone();
    tauri::async_runtime::spawn_blocking(move || {
        let result = if engine == "llama.cpp" {
            match ensure_runtime_dir() {
                Ok(root) => llama_installer::install_windows(root.join("engines"), cuda.unwrap_or(true), |phase, downloaded, total| {
                    manager.progress(&app, &job_id, phase, downloaded, total);
                }, || manager.cancellation_requested(&job_id)),
                Err(error) => Err(error),
            }
        } else {
            install_vllm_into_wsl(distro.unwrap_or_else(|| "Ubuntu".into()), |phase| {
                manager.progress(&app, &job_id, phase, 0, 0);
            }, || manager.cancellation_requested(&job_id))
        };
        manager.finish(&app, &job_id, result);
    });
    Ok(id)
}

#[tauri::command]
fn nvidia_gpu_status() -> Result<String, String> {
    let output = Command::new("nvidia-smi")
        .args(["--query-gpu=name,memory.total,memory.used,memory.free", "--format=csv,noheader,nounits"])
        .output().map_err(|_| "nvidia-smi is unavailable. Check that NVIDIA drivers are installed.".to_owned())?;
    if !output.status.success() { return Err("nvidia-smi was unable to read GPU memory.".into()); }
    Ok(String::from_utf8_lossy(&output.stdout).trim().to_string())
}

#[tauri::command]
fn read_engine_log(engine: String) -> Result<String, String> {
    let filename = match engine.as_str() {
        "llama.cpp" => "llama.log",
        "vllm" => "vllm.log",
        _ => return Err("Unsupported engine log.".into()),
    };
    let path = runtime_dir()?.join("logs").join(filename);
    let bytes = fs::read(path).map_err(|e| format!("No log found for {engine}: {e}"))?;
    Ok(String::from_utf8_lossy(&bytes[bytes.len().saturating_sub(16_000)..]).to_string())
}

#[tauri::command]
fn get_runtime_location() -> Result<String, String> {
    Ok(ensure_runtime_dir()?.display().to_string())
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .manage(EngineProcesses::default())
        .manage(InstallJobs::new(ensure_runtime_dir().expect("runtime directory unavailable").join("installer/jobs.json")))
        .plugin(tauri_plugin_sql::Builder::default().build())
        .plugin(tauri_plugin_dialog::init())
        .invoke_handler(tauri::generate_handler![
            start_llama_server, stop_llama_server, start_vllm_server, stop_vllm_server,
            nvidia_gpu_status, read_engine_log,
            start_install_job, get_install_jobs, cancel_install_job,
            get_runtime_location, gguf_catalog::scan_gguf_directory, activate_gguf_model,
        ])
        .run(tauri::generate_context!())
        .expect("failed to initialize Solarium");
}

