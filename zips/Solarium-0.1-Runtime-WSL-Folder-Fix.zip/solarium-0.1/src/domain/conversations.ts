import { now, uid, type ChatSession } from './types';

/** Fork a conversation at an existing message without modifying the original. */
export function forkChatSession(source: ChatSession, messageId: string): ChatSession | null {
  const messageIndex = source.messages.findIndex((message) => message.id === messageId);
  if (messageIndex < 0) return null;

  const timestamp = now();
  return {
    id: uid(),
    parentSessionId: source.id,
    forkMessageId: messageId,
    title: `${source.title} (branch)`,
    sparkId: source.sparkId,
    modelId: source.modelId,
    mode: source.mode,
    createdAt: timestamp,
    updatedAt: timestamp,
    // A branch gets its own copy, even when later edits change past messages.
    messages: structuredClone(source.messages.slice(0, messageIndex + 1)),
  };
}
