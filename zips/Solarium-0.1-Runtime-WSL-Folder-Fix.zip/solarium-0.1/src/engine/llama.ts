import type { Capabilities, LocalModel } from '../domain/types';
import { detectCapabilities } from './capabilities';
import { ReasoningSplitter } from './reasoning';
import { SSEDecoder } from './sse';
import { toolDefinitions } from './tools';

interface ChatToolCall { id: string; type: 'function'; function: { name: string; arguments: string } }
export interface LlamaMessage { role: 'system' | 'user' | 'assistant' | 'tool'; content: string; tool_call_id?: string; tool_calls?: ChatToolCall[] }
export interface LlamaCallbacks { answer: (text: string) => void; reasoning: (text: string) => void }
interface DeltaCall { index?: number; id?: string; type?: string; function?: { name?: string; arguments?: string } }
interface StreamChunk {
  error?: { message?: string };
  usage?: { completion_tokens?: number };
  choices?: { delta?: { content?: string | null; reasoning_content?: string | null; reasoning?: string | null; tool_calls?: DeltaCall[] }; finish_reason?: string | null }[];
}
function baseUrl(endpoint: string): URL {
  const url = new URL(endpoint);
  if (!['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname) || url.protocol !== 'http:' || url.username || url.password || url.search || url.hash) {
    throw new Error('Only local HTTP inference servers are permitted (127.0.0.1 or localhost).');
  }
  if (!url.pathname.endsWith('/')) url.pathname += '/';
  return url;
}
const pathFor = (endpoint: string, path: string): string => new URL(path.replace(/^\//, ''), baseUrl(endpoint)).toString();
async function readJson(url: string, signal?: AbortSignal): Promise<unknown> {
  const response = await fetch(url, { signal });
  if (!response.ok) throw new Error(`Inference server responded ${response.status}.`);
  return response.json() as Promise<unknown>;
}
export async function inspectModel(model: LocalModel, signal?: AbortSignal): Promise<{ ids: string[]; capabilities: Capabilities }> {
  const [models, props] = await Promise.all([
    readJson(pathFor(model.endpoint, '/v1/models'), signal),
    readJson(pathFor(model.endpoint, '/props'), signal).catch(() => null),
  ]);
  const collection = models as { data?: { id?: string }[] };
  return {
    ids: (collection?.data ?? []).map((item) => item.id).filter((id): id is string => typeof id === 'string'),
    capabilities: detectCapabilities(props),
  };
}
export async function streamLlamaTurn(
  model: LocalModel,
  messages: LlamaMessage[],
  capabilities: Capabilities,
  callbacks: LlamaCallbacks,
  signal: AbortSignal,
): Promise<{ answer: string; calls: ChatToolCall[]; usage?: { completionTokens: number } }> {
  const response = await fetch(pathFor(model.endpoint, '/v1/chat/completions'), {
    method: 'POST', signal, headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: model.modelId, messages, stream: true,
      temperature: model.temperature, max_tokens: model.maxTokens,
      ...(model.backend === 'vllm' ? { stream_options: { include_usage: true } } : {}),
      ...(capabilities.tools === 'supported' ? { tools: toolDefinitions, tool_choice: 'auto' } : {}),
    }),
  });
  if (!response.ok) {
    const detail = (await response.text()).slice(0, 320);
    throw new Error(`Model request failed (${response.status}): ${detail}`);
  }
  if (!response.body) throw new Error('Inference server returned no response stream.');
  const reader = response.body.getReader();
  const utf8 = new TextDecoder();
  const sse = new SSEDecoder();
  const splitter = new ReasoningSplitter();
  const toolCalls = new Map<number, ChatToolCall>();
  let answer = '';
  let completionTokens: number | undefined;
  function parseEvent(payload: string): void {
    if (payload === '[DONE]') return;
    let event: StreamChunk;
    try { event = JSON.parse(payload) as StreamChunk; }
    catch { throw new Error('Inference server returned malformed streamed JSON.'); }
    if (event.error) throw new Error(event.error.message || 'Inference server failed.');
    if (typeof event.usage?.completion_tokens === 'number') completionTokens = event.usage.completion_tokens;
    const delta = event.choices?.[0]?.delta;
    if (!delta) return;
    const reasoning = delta.reasoning_content ?? delta.reasoning;
    if (reasoning) callbacks.reasoning(reasoning);
    if (typeof delta.content === 'string') {
      for (const segment of splitter.push(delta.content)) {
        if (segment.kind === 'reasoning') callbacks.reasoning(segment.text);
        else { answer += segment.text; callbacks.answer(segment.text); }
      }
    }
    for (const part of delta.tool_calls ?? []) {
      const index = part.index ?? 0;
      const current = toolCalls.get(index) ?? { id: '', type: 'function' as const, function: { name: '', arguments: '' } };
      if (part.id) current.id += part.id;
      if (part.function?.name) current.function.name += part.function.name;
      if (part.function?.arguments) current.function.arguments += part.function.arguments;
      toolCalls.set(index, current);
    }
  }
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      for (const item of sse.push(utf8.decode(value, { stream: true }))) parseEvent(item);
    }
    for (const item of sse.push(utf8.decode())) parseEvent(item);
    for (const item of sse.flush()) parseEvent(item);
    for (const segment of splitter.finish()) {
      if (segment.kind === 'reasoning') callbacks.reasoning(segment.text);
      else { answer += segment.text; callbacks.answer(segment.text); }
    }
  } finally { reader.releaseLock(); }
  return { answer, calls: [...toolCalls.entries()].sort(([a], [b]) => a - b).map(([, value]) => value),
    ...(completionTokens === undefined ? {} : { usage: { completionTokens } }),
  };
}
