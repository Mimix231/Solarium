import type { AgentToolDefinition } from '../engine/tools';
import type { CreatorProject } from '../domain/types';
import type { CommandResult } from '../engine/intelligence/commands';
import { inspectProjectEnvironment } from '../engine/creator';
import { SpicaRepository, type SpicaRecord } from './repository';
import { changeGraph, collectionUpgrade, GraphEditError, stableGraphJson, type Graph, type GraphEdit } from './graph';
import { styleChanges, styleProperties, styleStates, styleTargets, styleValues, supportedProperties, supportedStates } from './appearance';
import { capabilities, recipeCatalog } from './program';
import { inspectSpicaComponent, searchSpicaWarehouse } from './warehouse';

const define = (name: string, description: string, properties: Record<string, unknown> = {},
  required: string[] = []): AgentToolDefinition => ({
  type: 'function', function: { name, description, parameters: { type: 'object', properties, required, additionalProperties: false } },
});
const revision = { type: 'integer', minimum: 1 };
const short = { type: 'string', minLength: 1, maxLength: 80 };
const warehouseId = { type: 'string', minLength: 1, maxLength: 120 };
export const spicaTools = [
  define('create_spica_app', 'Create an empty SPICA graph for the current linked empty project folder. The result supplies revision 1. Then compose the requested app using registered blocks.', { name: short }, ['name']),
  define('search_spica_warehouse', 'Search the bounded local index of implemented SPICA primitives and recipes. Results come from registered adapters only; draft documentation is never executable.', {
    query: { type: 'string', minLength: 1, maxLength: 200 },
    target: { type: 'string', enum: ['desktop', 'web'] },
    executableOnly: { type: 'boolean' },
    limit: { type: 'integer', minimum: 1, maximum: 12 },
  }, ['query']),
  define('inspect_spica_component', 'Inspect one exact ID and version returned by search_spica_warehouse, including real implementation, target, permission and graph-installation status.', {
    id: warehouseId,
    version: { type: 'string', minLength: 1, maxLength: 20 },
    target: { type: 'string', enum: ['desktop', 'web'] },
  }, ['id', 'version']),
  define('read_spica_graph', 'Read the authoritative graph revision and stable IDs. For appearance, use an optional target ID to read that block’s supported properties and saved styles.', { target: short }),
  define('edit_spica_graph', 'Apply an atomic graph edit at the current revision. set_style needs target, property and value. Use target app for theme or a block ID from the graph. add_record_toggle uses key, label, Boolean initial and optional filter:true. add_setting needs page, key, label and initial.', {
    revision,
    edits: { type: 'array', minItems: 1, maxItems: 12, items: {
      type: 'object', additionalProperties: false,
      properties: {
        op: { type: 'string', enum: ['set_style', 'add_record_toggle', 'add_setting', 'label_setting', 'remove_setting', 'add_page', 'rename'] },
        target: short,
        property: { type: 'string', enum: Object.keys(styleProperties) },
        state: { type: 'string', enum: styleStates, description: 'Optional. Defaults to base.' },
        value: { type: ['string', 'integer', 'null'], maxLength: 24, description: 'Use #rrggbb colors, integer pixels, a supported option, or null to inherit.' },
        page: short, id: short, key: { ...short, maxLength: 40 }, label: short, name: short,
        type: { type: 'string', enum: ['boolean', 'text', 'choice'] },
        initial: { type: ['string', 'boolean'], maxLength: 16000, description: 'Required for add_setting. Use false or true for a toggle.' },
        choices: { type: 'array', maxItems: 24, items: short },
        multiline: { type: 'boolean' },
        filter: { type: 'boolean', description: 'Show a list filter for this record toggle.' },
      },
      required: ['op'],
    } },
  }, ['revision', 'edits']),
  define('export_spica_app', 'Compile this graph revision and apply its managed files to the linked folder. Stops on drift and preserves custom source.', { revision }, ['revision']),
  define('prepare_spica_app', 'Prepare the current exported app from the local dependency cache and write its native lockfile using registered setup commands.', { revision }, ['revision']),
  define('verify_spica_app', 'Run the frontend build, native SQLite tests and standalone Tauri executable build for this exported revision. Check the actual result and report any blocker.', { revision }, ['revision']),
];
export const spicaToolNames = new Set(spicaTools.map(tool => tool.function.name));

const objectSchema = (properties: Record<string, unknown>, required: string[]) => ({
  type: 'object', properties, required, additionalProperties: false,
});
const flag = { type: 'boolean' };
const ids = { type: 'array', items: short };
const fieldSchema = objectSchema({
  key: short, label: short, type: { type: 'string', enum: ['text', 'boolean', 'reference', 'number', 'choice'] },
  initial: { type: ['string', 'boolean', 'number', 'null'], description: 'Omit to use the default for the field type.' },
  required: flag, multiline: flag, filter: flag, collection: short, choices: ids,
  min: { type: 'number' }, max: { type: 'number' },
}, ['key', 'label', 'type']);
const screenSchema = objectSchema({
  id: short, label: short, view: { type: 'string', enum: ['list', 'form', 'review', 'table', 'models', 'game'] },
  collection: short, intro: { type: 'string' }, buttons: { type: 'array', items: objectSchema({ id: short, label: short, screen: short }, ['id', 'label', 'screen']) },
  fields: ids, submit: short, submitLabel: short, filter: short, export: flag, mapping: flag,
  layout: { type: 'string', enum: ['stack', 'grid', 'split'] }, scene: { type: 'object' }, table: { type: 'object' },
}, ['id', 'label', 'view']);
const programEdit = define('edit_spica_graph', 'Save an atomic typed batch at revision. Put each payload inside its named object. put_screen uses screen:{id,label,view,collection}; the collection inside screen is a string ID. add_collection uses collection:{id,label,singular,fields:[{key,label,type}]}. Keep id and label inside the payload. Omit field initial unless a custom default is needed. set_start_screen takes screen as an ID. grant_capability takes capability as an ID.', {
  revision,
  edits: { type: 'array', minItems: 1, maxItems: 12, items: { type: 'object', additionalProperties: false,
    properties: {
      op: { type: 'string', enum: ['install_recipe', 'add_collection', 'put_screen', 'put_flow', 'put_scenario', 'set_start_screen', 'grant_capability', 'revoke_capability', 'set_style'] },
      recipe: { type: 'string', enum: recipeCatalog.map(recipe => recipe.id) },
      collection: objectSchema({ id: short, label: short, singular: short, fields: { type: 'array', minItems: 1, maxItems: 32, items: fieldSchema } }, ['id', 'label', 'singular', 'fields']),
      screen: { ...screenSchema, type: ['object', 'string'] },
      flow: objectSchema({ id: short, collection: short, steps: { type: 'array', items: { type: 'object' } } }, ['id', 'collection', 'steps']),
      scenario: objectSchema({ id: short, label: short, steps: { type: 'array', items: { type: 'object' } }, reopened: { type: 'array', items: { type: 'object' } } }, ['id', 'label', 'steps']),
      capability: { type: 'string', enum: capabilities },
      target: short, property: short, state: { type: 'string', enum: styleStates },
      value: { type: ['string', 'integer', 'null'], maxLength: 24 },
    }, required: ['op'] } },
}, ['revision', 'edits']);

/** Resolve the same operation contract at exposure and execution. */
export function spicaToolContract(tool: AgentToolDefinition, program: boolean): AgentToolDefinition {
  return program && tool.function.name === 'edit_spica_graph' ? programEdit : tool;
}

/** Accept equivalent flat collection/screen parameters before schema and permission checks. */
export function normalizeSpicaProposal(input: unknown): unknown {
  let args = input;
  if (typeof args === 'string') {
    try { args = JSON.parse(args); } catch { return input; }
  }
  if (!args || typeof args !== 'object' || !('edits' in args) || !Array.isArray(args.edits)) return args;
  const edits = args.edits.map((edit: unknown) => {
    if (!edit || typeof edit !== 'object' || Array.isArray(edit)) return edit;
    const values = edit as Record<string, unknown>;
    if (values.op === 'add_collection' && values.collection === undefined && values.id !== undefined) {
      const { id, label, singular, fields, ...operation } = values;
      return { ...operation, collection: { id, label, singular, fields } };
    }
    if (values.op === 'put_screen' && values.id !== undefined && values.label !== undefined) {
      const { id, label, view, collection, screen, ...operation } = values;
      const nested = screen && typeof screen === 'object' && !Array.isArray(screen) ? screen : typeof screen === 'string' ? { view: screen } : {};
      const flat = Object.fromEntries(Object.entries({ id, label, view, collection }).filter(([, value]) => value !== undefined));
      if (Object.entries(nested).some(([key, value]) => Object.hasOwn(flat, key) && flat[key] !== value)) return edit;
      return { ...operation, screen: { ...flat, ...nested } };
    }
    return edit;
  });
  return { ...args, edits };
}

export function spicaEditHint(edits: unknown): string {
  const operations = Array.isArray(edits) ? new Set(edits.map(edit => edit?.op)) : new Set();
  return [
    operations.has('add_collection') ? 'add_collection: put id, label, singular and fields inside collection. Omit initial for typed defaults.' : '',
    operations.has('put_screen') ? 'put_screen: use {op:"put_screen",screen:{id:"review",label:"Review",view:"review",collection:"entries"}}. Replace the IDs with your graph IDs.' : '',
    operations.has('grant_capability') || operations.has('set_capability') ? 'Use grant_capability with capability as an exact ID.' : '',
  ].filter(Boolean).join(' ');
}

export function isSpicaProgramRequest(message: string) {
  return /^(?:please\s+)?(?:add|build|connect|create|develop|edit|fix|install|make|repair|restore|run|test|verify|change)\b/i.test(message.trim()) &&
    /\b(?:quick capture|notebooks?|model organizer|csv (?:review|validation|import|export)|spica (?:app|flow|screen|scenario|recipe)|save (?:connection|flow)|runtime scenario|reusable (?:spica )?(?:blocks?|components?)|(?:build|create|make|develop) (?:a|an) (?:records?|notes?|tasks?|model|stl) app)\b/i.test(message);
}

export function isSpicaCreationRequest(message: string) {
  const text = message.trim().replace(/^(?:(?:can|could|would) you\s+)?(?:please[, ]+)?/i, '');
  if (/^use spica to (?:build|create|make|develop|implement)\b/i.test(text)) return true;
  if (/^build\s+(?:the\s+)?(?:current|existing|exported)\b/i.test(text)) return false;
  return /^(?:build|create|make|develop|implement)\b/i.test(text) &&
    (/\bspica\b/i.test(text) || /\bcsv\s+(?:review|validation)\b/i.test(text));
}

export function spicaAllowsEdit(message: string) {
  return !/^\s*(?:please\s+)?(?:run|check|test|verify|inspect|read|export|rebuild)\b/i.test(message) ||
    /\b(?:and|then)\s+(?:fix|repair)\b/i.test(message);
}

export function isSpicaVerificationOnly(message: string) {
  return !spicaAllowsEdit(message) && !/^\s*(?:please\s+)?export\b/i.test(message);
}

export function isSpicaStyleRequest(message: string): boolean {
  const request = message.trim().replace(/^(?:(?:can|could|would) you\s+)?(?:please[, ]+)?/i, '');
  if (/^(?:give|show) me\b.*\b(?:ideas|suggestions|examples|recommendations)\b/i.test(request)) return false;
  if (/^(?:style|restyle|recolou?r|theme)\b/i.test(request)) return true;
  return /^(?:give|make|set|use|apply|change|edit|update|adjust|tweak|round|colou?r)\b/i.test(request) &&
    (/\b(?:theme|palette|accent|typography|font|radius|padding|border|spacing|hover|keyboard focus|style|styling)\b/i.test(request) ||
    (/\b(?:app|notes|tasks|button|sidebar|field|input|panel|editor)\b/i.test(request) && /\b(?:background|colou?r|charcoal|dark|light|round(?:ed)?|red|green|blue|amber|gold|purple|pink|teal|black|white)\b/i.test(request)));
}

function appearanceSummary(graph: Graph, id?: string) {
  const targets = styleTargets(graph);
  const selected = id ? targets.find(part => part.id === id) : undefined;
  if (id && !selected) return { diagnostic: `Unknown style target ${id}. Call read_spica_graph without target for the IDs.` };
  if (selected) return { target: selected.id, label: selected.label, states: Object.fromEntries(supportedStates(selected).map(state => [state, {
    values: styleValues(graph.appearance, selected.id, state),
    properties: Object.fromEntries(supportedProperties(selected, state).map(key => [key, styleProperties[key]])),
  }])) };
  return {
    theme: graph.appearance?.theme ?? {},
    themeProperties: supportedProperties(targets[0]!, 'base').join(', '),
    targets: targets.filter(part => !/^(?:record-(?:field|input)-|setting-(?:field|input)-|settings-tab-)/.test(part.id)).map(part => part.id).join(', '),
    ...(graph.collection ? { fields: 'Use record-field-KEY for a label/group and record-input-KEY for its control.' } : {}),
    ...(!graph.collection || graph.controls.length ? { settings: 'Use settings-tab-PAGE, setting-field-ID or setting-input-ID.' } : {}),
    guide: 'Use set_style, target, property and value. For app: scheme=system/light/dark, layout=responsive/stacked. Colors are #rrggbb. Use font=system/sans/serif/mono and integer pixel values for sizes. Block defaults use background, text, border, radius and padding. For interactive states use hover, focus or selected if supported. Read a target for details.',
  };
}

/** Stable across JSON field order. The revision is part of the precondition. */
export function spicaEditSignature(args: Record<string, unknown>): string {
  return stableGraphJson([args.revision, args.edits]);
}

export type SpicaEditResult =
  | { saved: true; revision: number; next: 'export_spica_app' }
  | { saved: false; revision: number; code: 'STALE_GRAPH' | 'INVALID_GRAPH_EDIT'; message: string };

export function reviewSpicaEdit(current: SpicaRecord | null, args: Record<string, unknown>):
  { ok: true; args: Record<string, unknown> } | { ok: false; result: Extract<SpicaEditResult, { saved: false }> } {
  const revision = current?.data.revision ?? 0;
  if (!current || revision !== args.revision) return { ok: false, result: {
    saved: false, revision, code: 'STALE_GRAPH', message: 'Graph revision changed. Call read_spica_graph before editing.',
  } };
  try {
    protectScenarios(current, args.edits as GraphEdit[]);
    const next = changeGraph(current.data.graph, args.edits as GraphEdit[]);
    const fields = collectionUpgrade(current.data.graph.collection, next.collection);
    const appearance = styleChanges(current.data.graph, next);
    const behavior = (args.edits as GraphEdit[]).some(edit => ['install_recipe', 'add_collection', 'put_screen', 'put_flow', 'put_scenario',
      'set_start_screen', 'set_capability', 'grant_capability', 'revoke_capability'].includes(edit.op));
    if (!fields.length && !appearance.length && !behavior) return { ok: true, args };
    return { ok: true, args: { ...args, review: {
      graph: { fromRevision: current.data.revision, toRevision: current.data.revision + 1, collection: next.collection?.id, addedFields: fields },
      ...(appearance.length ? { appearance } : {}),
      ...(behavior ? { behavior: {
        collections: [next.collection, ...(next.collections ?? [])].filter(Boolean),
        screens: next.program?.screens, flows: next.program?.flows, grants: next.program?.grants,
      } } : {}),
      ...(fields.length ? { database: 'On first launch of the new standalone build, backfill the listed defaults on existing records in one SQLite transaction.' } : {}),
    } } };
  } catch (error) {
    return { ok: false, result: { saved: false, revision, code: 'INVALID_GRAPH_EDIT', message: error instanceof Error ? error.message : String(error) } };
  }
}

function protectScenarios(current: SpicaRecord, edits: readonly GraphEdit[]) {
  for (const edit of edits) {
    if (edit.op === 'put_scenario' && current.data.graph.program?.scenarios.some(scenario => scenario.id === edit.scenario?.id)) {
      throw new GraphEditError('Existing behavioral scenarios are protected during repair. Change the graph behavior or add a new scenario ID.');
    }
  }
}

export function selectSpicaTools(allowed: readonly AgentToolDefinition[], last: string | null, needsEdit: boolean, verified: boolean, appearance = false, program = false,
  state: { hasGraph?: boolean; needsSetup?: boolean; failed?: boolean; verifyOnly?: boolean; refreshGraph?: boolean; canEdit?: boolean } = {}) {
  const names = verified ? [] : state.hasGraph === false ? ['create_spica_app'] :
    state.refreshGraph ? ['read_spica_graph'] :
    !last || last === 'create_spica_app' ? program ? ['search_spica_warehouse'] : ['read_spica_graph'] :
    last === 'search_spica_warehouse' ? ['inspect_spica_component', 'read_spica_graph'] :
    last === 'inspect_spica_component' ? ['read_spica_graph'] :
    last === 'read_spica_graph' ? (needsEdit ? state.failed ? ['edit_spica_graph'] : appearance || program ? ['edit_spica_graph', 'read_spica_graph'] : ['edit_spica_graph'] :
      state.failed ? ['read_command_output', 'report_project_blocker'] : state.verifyOnly ? ['verify_spica_app'] :
      state.canEdit ? ['export_spica_app', 'edit_spica_graph', 'verify_spica_app'] : ['export_spica_app', 'verify_spica_app']) :
    last === 'edit_spica_graph' ? ['export_spica_app', 'read_spica_graph', ...(state.canEdit ? ['edit_spica_graph'] : [])] :
    last === 'export_spica_app' ? state.needsSetup ? ['prepare_spica_app'] : ['verify_spica_app', 'read_spica_graph'] :
    last === 'prepare_spica_app' ? state.failed ? ['read_command_output', 'report_project_blocker'] : ['verify_spica_app'] :
    last === 'verify_spica_app' && state.failed && needsEdit ? ['read_spica_graph'] :
    last === 'read_command_output' && state.failed ? ['report_project_blocker'] :
    ['read_command_output', 'read_spica_graph', 'report_project_blocker'];
  return names.flatMap(name => allowed.filter(tool => tool.function.name === name)
    .map(tool => spicaToolContract(tool, program && !appearance)));
}

export async function executeSpicaTool(name: string, args: Record<string, unknown>, project: CreatorProject,
  execution: {
    signal?: AbortSignal; webEnabled: boolean; spicaNeedsEdit?: boolean; spicaStyle?: boolean; spicaProgram?: boolean;
    onCommandResult?: (result: CommandResult) => void;
  },
  onOutput?: (stream: 'stdout' | 'stderr', chunk: string) => void): Promise<string> {
  if (execution.signal?.aborted) throw new DOMException('Stopped', 'AbortError');
  const repo = new SpicaRepository(project.id);
  const current = await repo.read();
  if (name === 'create_spica_app') {
    if (current) throw Error('This project already has a SPICA graph. Read its current revision.');
    if (!project.folder || (await inspectProjectEnvironment(project.folder)).rootEntryCount !== 0) {
      throw Error('Choose an empty linked folder for a new SPICA app.');
    }
    if (execution.signal?.aborted) throw new DOMException('Stopped', 'AbortError');
    const created = await repo.create(String(args.name ?? '').trim(), 'blank');
    return JSON.stringify({ saved: true, name: created.title, revision: created.data.revision });
  }
  if (!current) throw Error('This project has no saved SPICA graph.');
  if (name === 'search_spica_warehouse') {
    if (typeof args.query !== 'string') throw Error('Warehouse search query must be text.');
    if (args.target !== undefined && args.target !== 'desktop' && args.target !== 'web') throw Error('Warehouse target must be desktop or web.');
    if (args.executableOnly !== undefined && typeof args.executableOnly !== 'boolean') throw Error('executableOnly must be a Boolean.');
    if (args.limit !== undefined && typeof args.limit !== 'number') throw Error('Warehouse limit must be a number.');
    return JSON.stringify(searchSpicaWarehouse(current.data.graph, {
      query: args.query,
      ...(args.target ? { target: args.target } : {}),
      ...(args.executableOnly !== undefined ? { executableOnly: args.executableOnly } : {}),
      ...(args.limit !== undefined ? { limit: args.limit } : {}),
    }));
  }
  if (name === 'inspect_spica_component') {
    if (typeof args.id !== 'string' || typeof args.version !== 'string') throw Error('Provide an exact component ID and version from warehouse search.');
    if (args.target !== undefined && args.target !== 'desktop' && args.target !== 'web') throw Error('Warehouse target must be desktop or web.');
    return JSON.stringify(inspectSpicaComponent(current.data.graph, args.id, args.version, args.target));
  }
  if (name === 'read_spica_graph') {
    const graph = current.data.graph;
    const latest = execution.spicaProgram ? await (await import('./export')).latestSpicaBuild(project.id) : null;
    const failed = latest?.revision === current.data.revision && latest.root === project.folder
      ? latest.runtime?.flatMap(run => run.reports).find(report => report.state === 'failed') : undefined;
    return JSON.stringify({
    revision: current.data.revision, name: current.title, pages: current.data.graph.pages,
    collection: current.data.graph.collection,
    settings: current.data.graph.controls.map(c => ({ id: c.id, label: c.label, page: c.page, key: c.preference, widget: c.widget })),
    ...(execution.spicaStyle ? { appearance: appearanceSummary(graph, args.target as string | undefined) } : {}),
    ...(execution.spicaProgram ? { behavior: {
      recipes: graph.program?.recipes ?? {}, availableRecipes: recipeCatalog.map(recipe => recipe.id),
      screens: graph.program?.screens.slice(0, 12), flows: args.target ? graph.program?.flows.filter(flow => flow.id === args.target) : graph.program?.flows.slice(0, 3),
      collections: graph.collections, grants: graph.program?.grants ?? ['records.write'], startScreen: graph.program?.startScreen,
      scenarios: graph.program?.scenarios.map(scenario => ({ id: scenario.id, label: scenario.label })),
      failed: failed ? { id: failed.id, phase: failed.phase, step: failed.completed + 1,
        failedStep: failed.failedStep?.action === 'load_csv' ? { action: 'load_csv', fixtureLength: failed.failedStep.text.length } : failed.failedStep,
        diagnostic: failed.diagnostic } : undefined,
    } } : {}),
  }); }
  if (name === 'edit_spica_graph') {
    const revision = current.data.revision;
    if (args.revision !== revision) return JSON.stringify({
      saved: false, revision, code: 'STALE_GRAPH', message: 'Graph revision changed. Call read_spica_graph before editing.',
    } satisfies SpicaEditResult);
    try {
      protectScenarios(current, args.edits as GraphEdit[]);
      const saved = await repo.update(revision, args.edits as GraphEdit[]);
      return JSON.stringify({ saved: true, revision: saved.data.revision, next: 'export_spica_app' } satisfies SpicaEditResult);
    } catch (error) {
      if (!(error instanceof GraphEditError)) throw error;
      return JSON.stringify({ saved: false, revision, code: 'INVALID_GRAPH_EDIT', message: error.message } satisfies SpicaEditResult);
    }
  }
  if (args.revision !== current.data.revision) throw Error('Graph revision changed. Read the current graph.');
  if (!project.folder) throw Error('Link a standalone output folder first.');
  if (execution.spicaNeedsEdit) throw Error('Apply the requested graph edit first.');
  const { exportSpica, prepareSpica, spicaDependenciesReady, verifySpica } = await import('./export');
  if (name === 'export_spica_app') {
    const files = await exportSpica(project.folder, current);
    return JSON.stringify({ revision: current.data.revision, files,
      next: await spicaDependenciesReady(project.folder) ? 'verify_spica_app' : 'prepare_spica_app' });
  }
  const signal = execution.signal ?? new AbortController().signal;
  const output = ({ stream, chunk }: Parameters<NonNullable<Parameters<typeof verifySpica>[4]>>[0]) => onOutput?.(stream, chunk);
  if (name === 'prepare_spica_app') {
    const result = await prepareSpica(project.folder, current, false, signal, output, execution.onCommandResult);
    return JSON.stringify({ ok: result.ok, revision: current.data.revision, checks: result.results.map(command => ({
      id: command.command_id, exitCode: command.exit_code, runId: command.run_id, diagnostic: command.exit_code === 0 ? undefined : command.stderr.slice(-800),
    })) });
  }
  if (name !== 'verify_spica_app') throw Error('Unknown SPICA operation.');
  const evidence = await verifySpica(project.folder, current, execution.webEnabled, signal, output, execution.onCommandResult);
  const repairable = evidence.runtime?.some(run => run.reports.some(report => report.state === 'failed')) ?? false;
  return JSON.stringify({
    ok: evidence.state === 'passed', state: evidence.state, revision: evidence.revision, source: evidence.source,
    diagnostic: evidence.diagnostic, repairable, runtime: evidence.runtime?.map(run => ({
      id: run.id, reports: run.reports.map(report => ({ phase: report.phase, state: report.state, completed: report.completed, diagnostic: report.diagnostic })),
    })), checks: evidence.checks.map(result => ({
      id: result.command_id, exitCode: result.exit_code, runId: result.run_id,
      ...(result.exit_code === 0 ? {} : { diagnostic: (result.stderr.slice(-500) + '\n' + result.stdout.slice(-1000)).trim() }),
    })),
  });
}
