import { invokeProject } from '../../engine/intelligence/commands';

export interface CatalogEntry {
  id: string; version: string; category: number; kind: 'primitive' | 'profile'; maturity: 'draft';
  title: string; summary: string; tags: string; reference: string;
}
export interface CatalogCounts { revision: string; entries: number; profiles: number }
export interface CatalogPage { candidates: CatalogEntry[]; total: number }

let ready: Promise<CatalogCounts> | undefined;
export function ensureCatalog(): Promise<CatalogCounts> {
  ready ??= import('./manifests').then(({ catalogManifests }) => invokeProject<CatalogCounts>('spica_catalog_prepare', { seed: catalogManifests() }))
    .catch(error => { ready = undefined; throw error; });
  return ready;
}

export async function searchCatalog(query: string, category: number | null, offset = 0, limit = 8, kind: CatalogEntry['kind'] | null = null) {
  await ensureCatalog();
  return invokeProject<CatalogPage>('spica_catalog_search', { query, category, offset, limit, kind });
}

export async function inspectCatalog(id: string, version: string) {
  await ensureCatalog();
  return invokeProject<CatalogEntry>('spica_catalog_inspect', { id, version });
}
