//! Creator workspace: explicit local file access and opt-in public web retrieval.
use std::fs;
use std::io::Read;
use std::net::{IpAddr, ToSocketAddrs};
use std::path::{Path, PathBuf};
use std::time::Duration;
use serde::Serialize;

fn safe_root(root: &str) -> Result<PathBuf, String> {
    let dir = Path::new(root).canonicalize().map_err(|e| format!("Project directory unavailable: {e}"))?;
    if !dir.is_dir() { return Err("The project folder is not a directory.".into()); }
    Ok(dir)
}
fn safe_file(root: &str, relative: &str) -> Result<PathBuf, String> {
    if relative.is_empty() || relative.len() > 1024 { return Err("Invalid file path.".into()); }
    let base = safe_root(root)?;
    let proposed = Path::new(relative);
    if proposed.is_absolute() || proposed.components().any(|c| !matches!(c, std::path::Component::Normal(_))) {
        return Err("Only project-relative paths are accepted.".into());
    }
    let path = base.join(proposed).canonicalize().map_err(|e| e.to_string())?;
    if !path.starts_with(&base) || !path.is_file() { return Err("File is outside the project or not a regular file.".into()); }
    let allowed = ["rs", "ts", "tsx", "js", "jsx", "json", "md", "txt", "css", "html", "py", "toml", "yml", "yaml", "xml", "svg", "c", "h", "cpp", "hpp", "java", "go", "sh", "ps1", "sql", "vue", "svelte", "gitignore"];
    let ext = path.extension().and_then(|x| x.to_str()).unwrap_or("").to_lowercase();
    if !allowed.contains(&ext.as_str()) && path.file_name().and_then(|x| x.to_str()) != Some(".gitignore") { return Err("This file format is not editable in Solarium.".into()); }
    Ok(path)
}
#[tauri::command]
pub fn list_project_files(root: String) -> Result<Vec<String>, String> {
    let base = safe_root(&root)?;
    let mut found = Vec::new();
    fn walk(base: &Path, path: &Path, depth: usize, out: &mut Vec<String>) {
        if depth > 6 || out.len() >= 500 { return; }
        let Ok(items) = fs::read_dir(path) else { return; };
        for entry in items.flatten() {
            if out.len() >= 500 { break; }
            let Ok(ft) = entry.file_type() else { continue; };
            if ft.is_symlink() { continue; }
            let name = entry.file_name().to_string_lossy().to_string();
            if ft.is_dir() {
                if ["node_modules", ".git", "target", "dist", "build", ".venv", ".next", "runtime"].contains(&name.as_str()) { continue; }
                walk(base, &entry.path(), depth + 1, out);
            } else if ft.is_file() {
                if let Ok(rel) = entry.path().strip_prefix(base) {
                    if let Some(s) = rel.to_str() {
                        if safe_file(base.to_string_lossy().as_ref(), s).is_ok() { out.push(s.replace('\\', "/")); }
                    }
                }
            }
        }
    }
    walk(&base, &base, 0, &mut found);
    found.sort();
    Ok(found)
}
#[tauri::command]
pub fn read_project_file(root: String, relative: String) -> Result<String, String> {
    let path = safe_file(&root, &relative)?;
    if path.metadata().map_err(|e| e.to_string())?.len() > 1_000_000 { return Err("File is larger than the 1 MB editor limit.".into()); }
    fs::read_to_string(path).map_err(|e| format!("Cannot read UTF-8 text file: {e}"))
}
#[tauri::command]
pub fn write_project_file(root: String, relative: String, content: String, expected: String) -> Result<(), String> {
    let path = safe_file(&root, &relative)?;
    if content.len() > 1_000_000 || expected.len() > 1_000_000 { return Err("Editor limit is 1 MB.".into()); }
    let original = fs::read_to_string(&path).map_err(|e| e.to_string())?;
    if original != expected { return Err("File changed on disk. Reload it before saving.".into()); }
    // A .solarium.bak file is created on every save; never use raw model edits here.
    let backup = path.with_extension(format!("{}.solarium.bak", path.extension().and_then(|x| x.to_str()).unwrap_or("txt")));
    fs::copy(&path, &backup).map_err(|e| format!("Could not create backup: {e}"))?;
    fs::write(path, content).map_err(|e| e.to_string())
}

#[derive(Serialize)]
pub struct WebResult { pub title: String, pub url: String, pub excerpt: String }
fn public_https(input: &str) -> Result<(reqwest::Url, Vec<IpAddr>), String> {
    let url = reqwest::Url::parse(input).map_err(|e| e.to_string())?;
    if url.scheme() != "https" || url.username() != "" || url.password().is_some() || url.port_or_known_default() != Some(443) {
        return Err("Only public HTTPS URLs on port 443 can be opened.".into());
    }
    let host = url.host_str().ok_or("URL has no hostname")?;
    if host.eq_ignore_ascii_case("localhost") || host.ends_with(".localhost") || host.ends_with(".local") || host.ends_with(".internal") { return Err("Local network hosts are blocked.".into()); }
    let addresses: Vec<IpAddr> = (host, 443).to_socket_addrs().map_err(|e| format!("Cannot resolve host: {e}"))?.map(|s| s.ip()).collect();
    if addresses.is_empty() || addresses.iter().any(|ip| match ip {
        IpAddr::V4(v) => v.is_private() || v.is_loopback() || v.is_link_local() || v.is_multicast() || v.is_unspecified() || v.octets() == [255, 255, 255, 255] || v.octets()[0] == 0 || v.octets()[0] >= 240 || (v.octets()[0] == 100 && (64..128).contains(&v.octets()[1])),
        IpAddr::V6(v) => v.is_loopback() || v.is_unspecified() || v.is_multicast() || v.is_unique_local() || v.is_unicast_link_local() || v.to_ipv4_mapped().is_some_and(|v| v.is_private() || v.is_loopback() || v.is_link_local()),
    }) { return Err("Website resolves to a non-public address.".into()); }
    Ok((url, addresses))
}
fn client_for(url: &reqwest::Url, ips: &[IpAddr]) -> Result<reqwest::blocking::Client, String> {
    let mut builder = reqwest::blocking::Client::builder()
        .timeout(Duration::from_secs(18)).connect_timeout(Duration::from_secs(8))
        .redirect(reqwest::redirect::Policy::none()).user_agent("Solarium/0.1 (+local research)");
    if let Some(host) = url.host_str() { for ip in ips { builder = builder.resolve(host, std::net::SocketAddr::new(*ip, 443)); } }
    builder.build().map_err(|e| e.to_string())
}
fn decode_entities(input: &str) -> String {
    input.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&#39;", "'").replace("&nbsp;", " ")
}
fn element(fragment: &str, tag: &str) -> String {
    let open = format!("<{tag}>"); let close = format!("</{tag}>");
    fragment.split_once(&open).and_then(|(_, tail)| tail.split_once(&close).map(|(text, _)| decode_entities(text))).unwrap_or_default()
}
#[tauri::command]
fn search_web_inner(query: String) -> Result<Vec<WebResult>, String> {
    let q = query.trim();
    if q.is_empty() || q.len() > 300 { return Err("Search query must contain 1–300 characters.".into()); }
    let mut url = reqwest::Url::parse("https://www.bing.com/search").map_err(|e| e.to_string())?;
    url.query_pairs_mut().append_pair("format", "rss").append_pair("q", q);
    let (url, ips) = public_https(url.as_str())?;
    let mut response = client_for(&url, &ips)?.get(url).send().map_err(|e| format!("Search unavailable: {e}"))?.error_for_status().map_err(|e| e.to_string())?;
    let mut raw = Vec::new(); response.by_ref().take(250_000).read_to_end(&mut raw).map_err(|e| e.to_string())?;
    let feed = String::from_utf8_lossy(&raw);
    let mut results = Vec::new();
    for item in feed.split("<item>").skip(1).take(12) {
        let link = element(item, "link");
        if public_https(&link).is_err() { continue; }
        results.push(WebResult { title: element(item, "title"), url: link, excerpt: element(item, "description") });
    }
    if results.is_empty() { return Err("The search provider returned no usable public results. Try a different query or URL.".to_string()); }
    Ok(results)
}
#[tauri::command]
fn read_web_inner(url: String) -> Result<String, String> {
    let (url, ips) = public_https(&url)?;
    let mut response = client_for(&url, &ips)?.get(url).send().map_err(|e| e.to_string())?.error_for_status().map_err(|e| e.to_string())?;
    let mime = response.headers().get(reqwest::header::CONTENT_TYPE).and_then(|x| x.to_str().ok()).unwrap_or("").to_string();
    if !mime.contains("text/html") && !mime.contains("text/plain") && !mime.contains("application/xhtml+xml") { return Err("Only HTML and text pages are supported in website reader.".into()); }
    let mut data = Vec::new(); response.by_ref().take(500_000).read_to_end(&mut data).map_err(|e| e.to_string())?;
    let page = String::from_utf8_lossy(&data);
    if mime.contains("text/plain") { return Ok(page.chars().take(24_000).collect()); }
    let mut result = String::new(); let mut tag = String::new(); let mut inside = false; let mut skip = false;
    for ch in page.chars() {
        if ch == '<' { inside = true; tag.clear(); continue; }
        if ch == '>' && inside {
            let t = tag.trim().to_lowercase();
            if t.starts_with("script") || t.starts_with("style") || t.starts_with("nav") { skip = true; }
            if t.starts_with("/script") || t.starts_with("/style") || t.starts_with("/nav") { skip = false; }
            if t.starts_with("p") || t.starts_with("/p") || t.starts_with("h1") || t.starts_with("h2") || t.starts_with("/li") || t.starts_with("br") { result.push('\n'); }
            inside = false; continue;
        }
        if inside { if tag.len() < 100 { tag.push(ch); } } else if !skip { result.push(ch); }
        if result.len() > 100_000 { break; }
    }
    Ok(decode_entities(&result).split_whitespace().collect::<Vec<_>>().join(" ").chars().take(24_000).collect())
}

#[tauri::command]
pub async fn search_public_web(query: String) -> Result<Vec<WebResult>, String> {
    tauri::async_runtime::spawn_blocking(move || search_web_inner(query))
        .await.map_err(|e| format!("Search worker failed: {e}"))?
}
#[tauri::command]
pub async fn read_public_webpage(url: String) -> Result<String, String> {
    tauri::async_runtime::spawn_blocking(move || read_web_inner(url))
        .await.map_err(|e| format!("Website worker failed: {e}"))?
}
