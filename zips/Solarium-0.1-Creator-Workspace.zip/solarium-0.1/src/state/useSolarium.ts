import { create } from 'zustand';
import { defaultWorkspace, newSpark } from '../domain/defaults';
import type { ActivityEvent, ChatMessage, ChatSession, CreatorProject, LocalModel, MemoryItem, Preferences, Spark, SparkMode, Workspace } from '../domain/types';
import { now, uid } from '../domain/types';
import { loadWorkspace, saveWorkspace } from '../data/repository';
import { mergeCatalog } from '../engine/catalog';
import { forkChatSession } from '../domain/conversations';

export type View = 'chat' | 'projects' | 'code' | 'sparks' | 'models' | 'runtime' | 'worlds' | 'laboratory' | 'teams' | 'memories' | 'settings';
interface SolariumState {
  workspace: Workspace; ready: boolean; error: string | null;
  view: View; editingSparkId: string | null;
  events: ActivityEvent[];
  hydrate: () => Promise<void>;
  setView: (view: View) => void;
  setEditingSparkId: (id: string | null) => void;
  mutate: (fn: (draft: Workspace) => void) => void;
  addSpark: () => void; updateSpark: (id: string, patch: Partial<Spark>) => void;
  deleteSpark: (id: string) => void; selectSpark: (id: string) => void;
  createSession: (sparkId?: string, projectId?: string | null) => string;
  addProject: (name: string) => string; updateProject: (id: string, patch: Partial<CreatorProject>) => void; deleteProject: (id: string) => void; selectProject: (id: string | null) => void;
  branchSession: (id: string, messageId: string) => string | null;
  openSession: (id: string) => void;
  setSessionMode: (id: string, mode: SparkMode) => void;
  updateSession: (id: string, patch: Partial<ChatSession>) => void;
  deleteSession: (id: string) => void;
  appendMessage: (id: string, message: ChatMessage) => void;
  updatePreferences: (patch: Partial<Preferences>) => void;
  addMemory: (item: MemoryItem) => void;
  updateMemory: (id: string, patch: Partial<MemoryItem>) => void;
  removeMemory: (id: string) => void;
  upsertModel: (model: LocalModel) => void;
  syncCatalog: (models: LocalModel[], folder: string) => void;
  removeModel: (id: string) => void;
  pushEvent: (event: ActivityEvent) => void;
  clearEvents: () => void;
  restore: (workspace: Workspace) => void;
}
const initial = defaultWorkspace();
export const useSolarium = create<SolariumState>((set, get) => ({
  workspace: initial, ready: false, error: null, view: 'chat', editingSparkId: null, events: [],
  hydrate: async () => {
    try { const workspace = await loadWorkspace(); set({ workspace, ready: true, error: null }); }
    catch (error) { set({ ready: true, error: `Storage could not be loaded: ${String(error)}` }); }
  },
  setView: (view) => set({ view }),
  setEditingSparkId: (editingSparkId) => set({ editingSparkId }),
  mutate: (fn) => set((state) => {
    const draft = structuredClone(state.workspace);
    fn(draft);
    return { workspace: draft };
  }),
  addSpark: () => {
    const spark = newSpark();
    get().mutate((w) => { w.sparks.push(spark); w.selectedSparkId = spark.id; });
    set({ view: 'sparks', editingSparkId: spark.id });
  },
  updateSpark: (id, patch) => get().mutate((w) => {
    const spark = w.sparks.find((s) => s.id === id);
    if (spark) Object.assign(spark, patch, { updatedAt: now() });
  }),
  deleteSpark: (id) => get().mutate((w) => {
    if (w.sparks.length <= 1) return;
    w.sparks = w.sparks.filter((s) => s.id !== id);
    w.sessions = w.sessions.filter((s) => s.sparkId !== id);
    w.memories = w.memories.filter((m) => m.sparkId !== id);
    w.worlds = (w.worlds ?? []).filter((m) => m.sparkId !== id);
    w.labCases = (w.labCases ?? []).filter((m) => m.sparkId !== id);
    if (w.selectedSparkId === id) w.selectedSparkId = w.sparks[0]!.id;
    if (w.activeSessionId && !w.sessions.some((s) => s.id === w.activeSessionId)) w.activeSessionId = null;
  }),
  selectSpark: (id) => get().mutate((w) => { if (w.sparks.some((s) => s.id === id)) { w.selectedSparkId = id; w.activeSessionId = null; } }),
  addProject: (name) => { const id = uid(); const project: CreatorProject = { id, name: name.trim().slice(0,120) || 'Untitled project', description: '', instructions: '', folder: '', sparkId: null, modelId: null, createdAt: now(), updatedAt: now() }; get().mutate((w) => { (w.projects ??= []).push(project); w.activeProjectId = id; w.activeSessionId = null; }); set({ view: 'projects' }); return id; },
  updateProject: (id, patch) => get().mutate((w) => { const item = (w.projects ?? []).find((p) => p.id === id); if (item) Object.assign(item, patch, { updatedAt: now() }); }),
  deleteProject: (id) => get().mutate((w) => { w.projects = (w.projects ?? []).filter((p) => p.id !== id); w.sessions = w.sessions.filter((s) => s.projectId !== id); if (w.activeProjectId === id) { w.activeProjectId = null; w.activeSessionId = null; } }),
  selectProject: (id) => { get().mutate((w) => { w.activeProjectId = id; w.activeSessionId = null; }); set({ view: id ? 'projects' : 'chat' }); },
  createSession: (sparkId, projectId) => {
    const w = get().workspace;
    const project = (w.projects ?? []).find((p) => p.id === (projectId === undefined ? w.activeProjectId : projectId));
    const chosen = sparkId && w.sparks.some((s) => s.id === sparkId) ? sparkId : (project?.sparkId ?? w.selectedSparkId);
    const id = uid();
    const session: ChatSession = { id, sparkId: chosen, modelId: project?.modelId ?? null, projectId: project?.id ?? null, mode: 'conversation', title: 'New conversation', messages: [], createdAt: now(), updatedAt: now() };
    get().mutate((draft) => { draft.sessions.unshift(session); draft.activeSessionId = id; draft.selectedSparkId = chosen; });
    set({ view: 'chat', events: [] });
    return id;
  },
  branchSession: (id, messageId) => {
    const source = get().workspace.sessions.find((session) => session.id === id);
    if (!source) return null;
    const branch = forkChatSession(source, messageId);
    if (!branch) return null;

    get().mutate((workspace) => {
      workspace.sessions.unshift(branch);
      workspace.activeSessionId = branch.id;
      workspace.selectedSparkId = branch.sparkId; workspace.activeProjectId = branch.projectId ?? null;
    });
    set({ view: 'chat', events: [] });
    return branch.id;
  },
  openSession: (id) => {
    get().mutate((w) => { const session = w.sessions.find((s) => s.id === id); if (session) { w.activeSessionId = id; w.selectedSparkId = session.sparkId; w.activeProjectId = session.projectId ?? null; } });
    set({ view: 'chat', events: [] });
  },
  setSessionMode: (id, mode) => get().updateSession(id, { mode }),
  updateSession: (id, patch) => get().mutate((w) => { const session = w.sessions.find((s) => s.id === id); if (session) Object.assign(session, patch, { updatedAt: now() }); }),
  deleteSession: (id) => get().mutate((w) => { w.sessions = w.sessions.filter((s) => s.id !== id); if (w.activeSessionId === id) w.activeSessionId = null; }),
  appendMessage: (id, message) => get().mutate((w) => {
    const s = w.sessions.find((s) => s.id === id);
    if (s) {
      s.messages.push(message); s.updatedAt = now();
      if (s.title === 'New conversation' && message.role === 'user') s.title = message.content.slice(0, 47).trim() || s.title;
    }
  }),
  updatePreferences: (patch) => get().mutate((w) => { w.preferences = { ...w.preferences, ...patch }; }),
  addMemory: (item) => get().mutate((w) => { w.memories.push(item); }),
  updateMemory: (id, patch) => get().mutate((w) => { const m = w.memories.find((m) => m.id === id); if (m) Object.assign(m, patch); }),
  removeMemory: (id) => get().mutate((w) => { w.memories = w.memories.filter((m) => m.id !== id); }),
  upsertModel: (model) => get().mutate((w) => { const i = w.models.findIndex((m) => m.id === model.id); if (i === -1) w.models.push(model); else w.models[i] = model; }),
  syncCatalog: (models, folder) => get().mutate((w) => {
    w.models = mergeCatalog(w.models, models, folder);
    const ids = new Set(w.models.map((m) => m.id));
    for (const session of w.sessions) if (session.modelId && !ids.has(session.modelId)) session.modelId = null;
    for (const spark of w.sparks) if (spark.preferredModelId && !ids.has(spark.preferredModelId)) spark.preferredModelId = null;
  }),
  removeModel: (id) => get().mutate((w) => { w.models = w.models.filter((m) => m.id !== id); w.sparks.forEach((s) => { if (s.preferredModelId === id) s.preferredModelId = null; }); w.sessions.forEach((s) => { if (s.modelId === id) s.modelId = null; }); }),
  pushEvent: (event) => set((s) => {
    const last = s.events[s.events.length - 1];
    // Render long reasoning streams as one live item instead of thousands of React nodes.
    if (event.kind === 'reasoning' && last?.kind === 'reasoning' && last.runId === event.runId) {
      return { events: [...s.events.slice(0, -1), {
        ...last, sequence: event.sequence, at: event.at,
        text: `${last.text ?? ''}${event.text ?? ''}`.slice(-20_000),
      }] };
    }
    return { events: [...s.events, event].slice(-200) };
  }),
  clearEvents: () => set({ events: [] }),
  restore: (workspace) => set({ workspace, view: 'chat', editingSparkId: null, events: [] }),
}));
let timer: ReturnType<typeof setTimeout> | undefined;
useSolarium.subscribe((state, prev) => {
  if (state.ready && state.workspace !== prev.workspace) {
    clearTimeout(timer);
    timer = setTimeout(() => {
      void saveWorkspace(useSolarium.getState().workspace).catch((error: unknown) => {
        useSolarium.setState({ error: `Changes could not be saved: ${String(error)}` });
      });
    }, 250);
  }
});
